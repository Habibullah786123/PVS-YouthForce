const mongoose = require("mongoose");
const dotenv = require("dotenv");
const colors = require("colors");

// Load env vars
dotenv.config();

const clearData = async () => {
  try {
    const conn = await mongoose.connect(
      process.env.MONGO_URI || "mongodb://localhost:27017/pvs_db"
    );

    console.log(
      `MongoDB Connected: ${conn.connection.host}`.cyan.underline.bold
    );

    // Drop collections
    try {
      await mongoose.connection.db.dropCollection("volunteers");
      console.log("Volunteers collection dropped".red);
    } catch (e) {
      /* ignore if not exists */
    }

    try {
      await mongoose.connection.db.dropCollection("organizations");
      console.log("Organizations collection dropped".red);
    } catch (e) {
      /* ignore if not exists */
    }

    try {
      await mongoose.connection.db.dropCollection("opportunities");
      console.log("Opportunities collection dropped".red);
    } catch (e) {
      /* ignore if not exists */
    }

    try {
      await mongoose.connection.db.dropCollection("applications");
      console.log("Applications collection dropped".red);
    } catch (e) {
      /* ignore if not exists */
    }

    try {
      await mongoose.connection.db.dropCollection("admins");
      console.log("Admins collection dropped".red);
    } catch (e) {
      /* ignore if not exists */
    }

    try {
      await mongoose.connection.db.dropCollection("contacts");
      console.log("Contacts collection dropped".red);
    } catch (e) {
      /* ignore if not exists */
    }

    console.log("Data Destroyed...".red.inverse);
    process.exit();
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
};

clearData();
