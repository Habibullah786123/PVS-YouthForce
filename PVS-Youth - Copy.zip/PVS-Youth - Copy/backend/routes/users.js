const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");
const upload = require("../middleware/upload");
const {
  getProfile,
  updateProfile,
  getUserById,
  getVolunteerFullProfile,
  getOrganizationProfile,
  addSkill,
  removeSkill,
  uploadDocuments,
  updateVerificationStatus,
  addAdminComment,
  getAllUsersForAdmin,
  getUserDetailsForAdmin,
  deleteDocument,
  addQualification,
  deleteQualification,
  updateQualification,
} = require("../controllers/userController");

// Profile management (protected routes)
router.get("/profile", auth, getProfile);
router.put("/profile", auth, updateProfile);
router.post(
  "/upload-documents",
  auth,
  upload.fields([
    { name: "documents", maxCount: 10 },
    { name: "profilePicture", maxCount: 1 },
  ]),
  uploadDocuments
);
router.delete("/documents/:docId", auth, deleteDocument);

// Skills management
router.post("/skills", auth, addSkill);
router.delete("/skills", auth, removeSkill);

// Qualifications management
router.post(
  "/qualifications",
  auth,
  upload.single("document"),
  addQualification
);

// Update Qualification
router.put(
  "/qualifications/:id",
  auth,
  upload.single("document"),
  updateQualification
);

// Delete Qualification
router.delete("/qualifications/:id", auth, deleteQualification);

// Admin Routes
router.get("/admin/users", auth, getAllUsersForAdmin);
router.get("/admin/users/:id", auth, getUserDetailsForAdmin);
router.put("/admin/verify", auth, updateVerificationStatus);
router.post("/admin/comment", auth, addAdminComment);

// Full volunteer profile for organizations (protected)
router.get("/volunteer/:id/full", auth, getVolunteerFullProfile);

// Public profile access
router.get("/:id", getUserById);

// Organization profile
router.get("/organization/:orgId", getOrganizationProfile);

module.exports = router;
