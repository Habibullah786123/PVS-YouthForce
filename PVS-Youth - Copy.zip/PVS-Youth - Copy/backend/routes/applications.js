const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");
const {
  applyForOpportunity,
  getVolunteerApplications,
  getOpportunityApplications,
  updateApplicationStatus,
  withdrawApplication,
  getOrganizationApplications,
  getAllApplicationsForAdmin,
} = require("../controllers/applicationController");

// Apply for opportunity
router.post("/", auth, applyForOpportunity);

// Get volunteer's applications
router.get("/volunteer", auth, getVolunteerApplications);
router.get("/volunteer/:userId", auth, getVolunteerApplications);

// Get accepted applications count for an organization (public)
router.get("/organization/:orgId/count", async (req, res) => {
  try {
    const Application = require("../models/Application");
    const count = await Application.countDocuments({
      organizationId: req.params.orgId,
      status: "accepted",
    });
    res.json({ count });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

// Get organization's applications
router.get("/organization", auth, getOrganizationApplications);

// Get applications for an opportunity
router.get("/opportunity/:oppId", auth, getOpportunityApplications);

// Update application status
router.put("/:id/status", auth, updateApplicationStatus);

// Withdraw application
router.delete("/:id", auth, withdrawApplication);

// Admin Routes
router.get("/admin/all", auth, getAllApplicationsForAdmin);

module.exports = router;
