const express = require("express");
const {
  register,
  login,
  requestOTP,
  verifyOTP,
  registerAdmin,
  loginAdmin,
  getAllAdmins,
  updateAdmin,
  deleteAdmin,
} = require("../controllers/authController");
const router = express.Router();
const auth = require("../middleware/auth"); // Assuming auth middleware exists

router.post("/register", register);
router.post("/login", login);
router.post("/request-otp", requestOTP);
router.post("/verify-otp", verifyOTP);

// Admin Routes
router.post("/admin/register", registerAdmin);
router.post("/admin/login", loginAdmin);
router.get("/admin/all", auth, getAllAdmins); // Protected route
router.put("/admin/:id", auth, updateAdmin); // Update admin
router.delete("/admin/:id", auth, deleteAdmin); // Delete admin

module.exports = router;
