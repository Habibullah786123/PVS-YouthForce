const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");
const {
  getOpportunities,
  getOpportunityById,
  createOpportunity,
  updateOpportunity,
  deleteOpportunity,
  getOrganizationOpportunities,
  saveOpportunity,
  unsaveOpportunity,
  getSavedOpportunities,
  getAllOpportunitiesForAdmin,
  updateOpportunityStatusByAdmin,
} = require("../controllers/opportunityController");

// Public routes
router.get("/", getOpportunities);
router.get("/:id", getOpportunityById);

// Protected routes (require authentication)
router.post("/", auth, createOpportunity);
router.put("/:id", auth, updateOpportunity);
router.delete("/:id", auth, deleteOpportunity);

// Organization-specific routes
router.get("/organization/:orgId", auth, getOrganizationOpportunities);

// Volunteer save for later routes
router.get("/user/saved", auth, getSavedOpportunities);
router.post("/:id/save", auth, saveOpportunity);
router.delete("/:id/save", auth, unsaveOpportunity);

// Admin Routes
router.get("/admin/all", auth, getAllOpportunitiesForAdmin);
router.put("/admin/:id/status", auth, updateOpportunityStatusByAdmin);

module.exports = router;
