const express = require("express");
const router = express.Router();
const {
  submitContactForm,
  getAllMessages,
  updateMessageStatus,
  deleteMessage,
} = require("../controllers/contactController");

// Middleware to protect routes
const auth = require("../middleware/auth");

router.post("/", submitContactForm);
router.get("/", auth, getAllMessages); // Protected: Authenticated users only (Admin check typically handled in controller or separate middleware)
router.put("/:id", auth, updateMessageStatus); // Protected
router.delete("/:id", auth, deleteMessage); // Protected

module.exports = router;
