const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

const volunteerSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, "Name is required"],
    trim: true,
  },
  email: {
    type: String,
    required: [true, "Email is required"],
    unique: true,
    lowercase: true,
    match: [
      /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/,
      "Please enter a valid email",
    ],
  },
  phone: {
    type: String,
    required: [true, "Phone number is required"],
  },
  password: {
    type: String,
    required: [true, "Password is required"],
    minlength: [6, "Password must be at least 6 characters"],
  },
  profilePicture: {
    type: String,
  },
  role: {
    type: String,
    default: "volunteer",
    immutable: true,
  },

  // Profile Information
  bio: {
    type: String,
    trim: true,
    maxlength: 500,
  },
  detailedBio: {
    type: String,
    trim: true,
    maxlength: 2000,
  },
  skills: [
    {
      type: String,
      trim: true,
    },
  ],
  location: {
    type: String,
    trim: true,
  },
  cnicNumber: {
    type: String,
    trim: true,
  },
  gender: {
    type: String,
    enum: ["Male", "Female", "Other", "Prefer not to say"],
    trim: true,
  },
  dateOfBirth: {
    type: Date,
  },

  // Saved opportunities
  savedOpportunities: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Opportunity",
    },
  ],

  // Verification
  isVerified: {
    type: Boolean,
    default: false,
  },
  verificationStatus: {
    type: String,
    enum: ["pending", "approved", "rejected", "changes_requested"],
    default: "pending",
  },
  documents: [
    {
      name: String,
      url: String,
      uploadedAt: { type: Date, default: Date.now },
    },
  ],
  adminComments: [
    {
      comment: String,
      date: { type: Date, default: Date.now },
      adminId: { type: mongoose.Schema.Types.ObjectId, ref: "Admin" },
    },
  ],

  // Qualifications
  qualifications: [
    {
      type: { type: String, required: true },
      university: { type: String, required: true },
      marks: { type: String, required: true },
      grade: String,
      completionYear: { type: String, required: true },
      documentUrl: String,
      documentName: String,
      createdAt: { type: Date, default: Date.now },
    },
  ],

  // OTP for phone verification
  otp: {
    type: String,
  },
  otpExpires: {
    type: Date,
  },

  createdAt: {
    type: Date,
    default: Date.now,
  },
});

// Hash password before saving
volunteerSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next();
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

// Compare password method
volunteerSchema.methods.comparePassword = async function (candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

module.exports = mongoose.model("Volunteer", volunteerSchema);
