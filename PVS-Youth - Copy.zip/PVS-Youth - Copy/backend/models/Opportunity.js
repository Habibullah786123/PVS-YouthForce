const mongoose = require("mongoose");

const opportunitySchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, "Title is required"],
    trim: true,
  },
  description: {
    type: String,
    required: [true, "Description is required"],
    trim: true,
  },
  detailedDescription: {
    type: String,
    trim: true,
  },
  organizationId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Organization",
    required: true,
  },
  requiredSkills: [
    {
      type: String,
      trim: true,
    },
  ],
  impact: [{ type: String, trim: true }], // What you'll make happen
  programTimeline: [
    {
      title: { type: String, trim: true },
      description: { type: String, trim: true },
    },
  ],
  location: {
    type: String,
    required: [true, "Location is required"],
    trim: true,
  },
  startDate: {
    type: Date,
    required: [true, "Start date is required"],
  },
  endDate: {
    type: Date,
    required: [true, "End date is required"],
  },
  responsibilities: [{ type: String, trim: true }],
  requirements: [{ type: String, trim: true }],
  duration: { type: String, trim: true },
  timeCommitment: { type: String, trim: true },
  volunteersNeeded: {
    type: Number,
    required: [true, "Number of volunteers needed is required"],
    min: 1,
  },
  status: {
    type: String,
    enum: ["active", "inactive", "completed", "draft", "pending", "rejected"],
    default: "active",
  },
  adminComments: {
    type: String,
    trim: true,
  },
  isLockedByAdmin: {
    type: Boolean,
    default: false,
  },
  category: {
    type: String,
    enum: [
      "education",
      "environment",
      "health",
      "community",
      "animals",
      "disaster-relief",
      "other",
    ],
    default: "other",
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
  views: {
    type: Number,
    default: 0,
  },
});

// Update the updatedAt field before saving
opportunitySchema.pre("save", function (next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model("Opportunity", opportunitySchema);
