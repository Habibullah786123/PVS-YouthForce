const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

const organizationSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, "Organization name is required"],
    trim: true,
  },
  email: {
    type: String,
    required: [true, "Email is required"],
    unique: true,
    lowercase: true,
    match: [
      /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/,
      "Please enter a valid email",
    ],
  },
  phone: {
    type: String,
    required: [true, "Phone number is required"],
  },
  password: {
    type: String,
    required: [true, "Password is required"],
    minlength: [6, "Password must be at least 6 characters"],
  },
  profilePicture: {
    type: String,
  },
  role: {
    type: String,
    default: "organization",
    immutable: true,
  },

  // Profile Information
  description: {
    type: String,
    trim: true,
    maxlength: 1000,
  },
  detailedDescription: {
    type: String,
    trim: true,
    maxlength: 5000,
  },
  missionStatement: {
    type: String,
    trim: true,
    maxlength: 2000,
  },
  website: {
    type: String,
    trim: true,
  },
  location: {
    type: String,
    trim: true,
  },
  registrationNumber: {
    type: String,
    trim: true,
  },
  established: {
    type: Number,
    min: 1800,
    max: new Date().getFullYear(),
  },
  focusAreas: [
    {
      type: String,
      trim: true,
    },
  ],

  // Verification
  isVerified: {
    type: Boolean,
    default: false,
  },
  verificationStatus: {
    type: String,
    enum: ["pending", "approved", "rejected", "changes_requested"],
    default: "pending",
  },
  documents: [
    {
      name: String,
      url: String,
      uploadedAt: { type: Date, default: Date.now },
    },
  ],
  adminComments: [
    {
      comment: String,
      date: { type: Date, default: Date.now },
      adminId: { type: mongoose.Schema.Types.ObjectId, ref: "Admin" },
    },
  ],

  // OTP for phone verification
  otp: {
    type: String,
  },
  otpExpires: {
    type: Date,
  },

  createdAt: {
    type: Date,
    default: Date.now,
  },
});

// Hash password before saving
organizationSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next();
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

// Compare password method
organizationSchema.methods.comparePassword = async function (
  candidatePassword
) {
  return await bcrypt.compare(candidatePassword, this.password);
};

module.exports = mongoose.model("Organization", organizationSchema);
