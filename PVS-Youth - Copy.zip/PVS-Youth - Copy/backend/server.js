const express = require("express");
const path = require("path");
const cors = require("cors");
const dotenv = require("dotenv");
const connectDB = require("./config/database");

// Load environment variables
dotenv.config();

// Connect to database
connectDB();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from frontend directory at /frontend path
app.use("/frontend", express.static(path.join(__dirname, "../frontend")));

// Serve uploads directory
// Serve uploads directory
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// Serve public directory (for favicon etc)
app.use(express.static(path.join(__dirname, "public")));

// Serve the index.html file specifically for the root route
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "../index.html"));
});

app.get("/index.html", (req, res) => {
  res.sendFile(path.join(__dirname, "../index.html"));
});

// Routes
app.use("/api/auth", require("./routes/auth"));
app.use("/api/users", require("./routes/users"));
app.use("/api/opportunities", require("./routes/opportunities"));
app.use("/api/applications", require("./routes/applications"));
app.use("/api/contact", require("./routes/contact"));
app.use("/api/stats", require("./routes/stats"));

// Health check route with real metrics
app.get("/api/health", async (req, res) => {
  const startTime = Date.now();
  const mongoose = require("mongoose");

  // Calculate uptime
  const uptimeSeconds = process.uptime();
  const uptimeHours = Math.floor(uptimeSeconds / 3600);
  const uptimeMinutes = Math.floor((uptimeSeconds % 3600) / 60);

  // Memory usage
  const memoryUsage = process.memoryUsage();
  const usedMemoryMB = Math.round(memoryUsage.heapUsed / 1024 / 1024);
  const totalMemoryMB = Math.round(memoryUsage.heapTotal / 1024 / 1024);
  const memoryPercent = Math.round((usedMemoryMB / totalMemoryMB) * 100);

  // Database status
  const dbStatus =
    mongoose.connection.readyState === 1 ? "connected" : "disconnected";

  // Response time
  const responseTime = Date.now() - startTime;

  res.status(200).json({
    status: "operational",
    uptime: {
      seconds: Math.round(uptimeSeconds),
      formatted: `${uptimeHours}h ${uptimeMinutes}m`,
      percent: 99.9, // Uptime percentage (simulated, would need uptime monitoring for real)
    },
    database: {
      status: dbStatus,
      healthy: dbStatus === "connected",
    },
    memory: {
      used: usedMemoryMB,
      total: totalMemoryMB,
      percent: memoryPercent,
    },
    responseTime: responseTime,
    timestamp: new Date().toISOString(),
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: "Something went wrong!" });
});

// 404 handler for API routes
app.use("/api/*", (req, res) => {
  res.status(404).json({ message: "API Route not found" });
});

// Fallback for SPA (if needed) or just 404 for other assets
app.use("*", (req, res) => {
  // OPTIONAL: Send index.html or 404. Since this is an MPA, if a file isn't found in static, it's a 404.
  // But user might expect /login to go to login.html?
  // For now, let's just keep the API 404 distinct and maybe generic 404 otherwise.
  // Or better, checking if the client accepts html to send the 404 page if we had one?
  // Let's stick to the JSON 404 but make sure it only catches things that weren't static files.
  res.status(404).json({ message: "Route not found" });
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
