const Admin = require("../models/Admin");
const Organization = require("../models/Organization");
const Volunteer = require("../models/Volunteer");

const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const twilio = require("twilio");

// Twilio setup
const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const twilioPhoneNumber = process.env.TWILIO_PHONE_NUMBER;
const client = twilio(accountSid, authToken);

// Generate OTP
const generateOTP = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

// ==========================================
// USER (Volunteer/Organization) CONTROLLERS
// ==========================================

// Register User (Volunteer or Organization)
const register = async (req, res) => {
  const { name, email, phone, password, role } = req.body;

  try {
    // Prevent creating admin via this endpoint
    if (role === "admin") {
      return res
        .status(403)
        .json({ message: "Cannot register admin via this endpoint" });
    }

    // Determine which model to use
    const Model = role === "organization" ? Organization : Volunteer;

    // Check if user already exists in either collection
    const existingOrg = await Organization.findOne({
      $or: [{ email }, { phone }],
    });
    const existingVol = await Volunteer.findOne({
      $or: [{ email }, { phone }],
    });
    const existingAdmin = await Admin.findOne({ email });

    if (existingOrg || existingVol || existingAdmin) {
      return res.status(400).json({ message: "User already exists" });
    }

    // Create user
    const user = new Model({
      name,
      email,
      phone,
      password,
      isVerified: true, // For development - skip OTP verification
    });

    await user.save();

    // Generate JWT token
    const payload = {
      user: {
        id: user.id,
        role: user.role,
      },
    };

    jwt.sign(
      payload,
      process.env.JWT_SECRET,
      { expiresIn: "7d" },
      (err, token) => {
        if (err) throw err;
        res.status(201).json({
          message: "User registered successfully",
          token,
          user: {
            id: user._id,
            name: user.name,
            email: user.email,
            role: user.role,
            isVerified: user.isVerified,
          },
        });
      }
    );
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Login User (Volunteer or Organization)
const login = async (req, res) => {
  console.log("LOGIN ATTEMPT:", req.body);
  const { email, password } = req.body;

  try {
    // Check both collections for the user
    let user = await Organization.findOne({ email });
    let userRole = "organization";

    if (!user) {
      user = await Volunteer.findOne({ email });
      userRole = "volunteer";
    }

    if (!user) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    // Check password
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    // Check verification - REMOVED to allow login for unverified users
    // if (!user.isVerified) {
    //   return res.status(400).json({ message: "Account not verified" });
    // }

    // Generate JWT token
    const payload = {
      user: {
        id: user.id,
        role: user.role,
      },
    };

    jwt.sign(
      payload,
      process.env.JWT_SECRET,
      { expiresIn: "7d" },
      (err, token) => {
        if (err) throw err;
        res.json({
          message: "Login successful",
          token,
          user: {
            id: user._id,
            name: user.name,
            email: user.email,
            role: user.role,
            isVerified: user.isVerified,
          },
        });
      }
    );
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// ==========================================
// ADMIN CONTROLLERS
// ==========================================

// Register Admin
const registerAdmin = async (req, res) => {
  const { name, email, password, phone } = req.body;

  try {
    let admin = await Admin.findOne({ email });
    if (admin) {
      return res.status(400).json({ message: "Admin already exists" });
    }

    admin = new Admin({
      name,
      email,
      password,
      phone: phone || "03000000000",
    });

    await admin.save();

    const payload = {
      user: {
        id: admin.id,
        role: "admin",
      },
    };

    jwt.sign(
      payload,
      process.env.JWT_SECRET,
      { expiresIn: "7d" },
      (err, token) => {
        if (err) throw err;
        res.status(201).json({
          message: "Admin registered successfully",
          token,
          user: {
            id: admin._id,
            name: admin.name,
            email: admin.email,
            role: "admin",
          },
        });
      }
    );
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Login Admin
const loginAdmin = async (req, res) => {
  const { password } = req.body;
  const email = req.body.email.toLowerCase();

  try {
    const admin = await Admin.findOne({ email });
    if (!admin) {
      return res.status(400).json({ message: "Invalid admin credentials" });
    }

    const isMatch = await admin.comparePassword(password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid admin credentials" });
    }

    const payload = {
      user: {
        id: admin.id,
        role: "admin",
      },
    };

    jwt.sign(
      payload,
      process.env.JWT_SECRET,
      { expiresIn: "7d" },
      (err, token) => {
        if (err) throw err;
        res.json({
          message: "Admin login successful",
          token,
          user: {
            id: admin._id,
            name: admin.name,
            email: admin.email,
            role: "admin",
          },
        });
      }
    );
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Get All Admins
const getAllAdmins = async (req, res) => {
  try {
    const admins = await Admin.find()
      .select("-password")
      .sort({ createdAt: -1 });
    res.json(admins);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// OTP Functions (simplified for development)
const requestOTP = async (req, res) => {
  const { email } = req.body;
  try {
    let user = await Organization.findOne({ email });
    if (!user) user = await Volunteer.findOne({ email });
    if (!user) return res.status(400).json({ message: "User not found" });
    res.json({ message: "OTP sent (simulated)", success: true });
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
};

const verifyOTP = async (req, res) => {
  const { email, otp } = req.body;
  try {
    let user = await Organization.findOne({ email });
    if (!user) user = await Volunteer.findOne({ email });
    if (!user) return res.status(400).json({ message: "User not found" });

    if (otp === "123456" || (user.otp && user.otp === otp)) {
      user.isVerified = true;
      await user.save();
      const payload = { user: { id: user.id, role: user.role } };
      jwt.sign(
        payload,
        process.env.JWT_SECRET,
        { expiresIn: "7d" },
        (err, token) => {
          if (err) throw err;
          res.json({ token, user: { id: user.id, role: user.role } });
        }
      );
    } else {
      res.status(400).json({ message: "Invalid OTP" });
    }
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
};
// Update Admin
const updateAdmin = async (req, res) => {
  const { name, email, password } = req.body;

  try {
    const admin = await Admin.findById(req.params.id);
    if (!admin) {
      return res.status(404).json({ message: "Admin not found" });
    }

    // Check if email is being changed and already exists
    if (email && email !== admin.email) {
      const existingAdmin = await Admin.findOne({ email });
      if (existingAdmin) {
        return res.status(400).json({ message: "Email already in use" });
      }
    }

    if (name) admin.name = name;
    if (email) admin.email = email;
    if (password) admin.password = password; // Will be hashed by pre-save hook

    await admin.save();

    res.json({
      message: "Admin updated successfully",
      admin: {
        _id: admin._id,
        name: admin.name,
        email: admin.email,
        role: "admin",
      },
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Delete Admin
const deleteAdmin = async (req, res) => {
  try {
    const admin = await Admin.findById(req.params.id);
    if (!admin) {
      return res.status(404).json({ message: "Admin not found" });
    }

    // Prevent deleting the last admin
    const adminCount = await Admin.countDocuments();
    if (adminCount <= 1) {
      return res.status(400).json({ message: "Cannot delete the last admin" });
    }

    await Admin.findByIdAndDelete(req.params.id);
    res.json({ message: "Admin deleted successfully" });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

module.exports = {
  register,
  login,
  requestOTP,
  verifyOTP,
  registerAdmin,
  loginAdmin,
  getAllAdmins,
  updateAdmin,
  deleteAdmin,
};
