const Opportunity = require("../models/Opportunity");
const Organization = require("../models/Organization");
const Volunteer = require("../models/Volunteer");

// Get all opportunities with optional filters
const getOpportunities = async (req, res) => {
  try {
    const {
      page = 1,
      limit = 10,
      category,
      location,
      skills,
      status = "active",
      search,
    } = req.query;

    // Build filter object
    let filter = { status };

    if (category && category !== "all") {
      filter.category = category;
    }

    if (location) {
      filter.location = { $regex: location, $options: "i" };
    }

    if (skills) {
      const skillsArray = skills.split(",").map((skill) => skill.trim());
      filter.requiredSkills = { $in: skillsArray };
    }

    if (search) {
      filter.$or = [
        { title: { $regex: search, $options: "i" } },
        { description: { $regex: search, $options: "i" } },
      ];
    }

    // FILTER: Only show opportunities from APPROVED organizations
    const approvedOrgIds = await Organization.find({
      verificationStatus: "approved",
    }).distinct("_id");

    // If filtering by organization (e.g. from query), ensure it's in approved list
    if (filter.organizationId) {
      // If specific org requested, check if it's approved
      if (
        !approvedOrgIds
          .map((id) => id.toString())
          .includes(filter.organizationId)
      ) {
        return res.json({
          opportunities: [],
          totalPages: 0,
          currentPage: page,
          total: 0,
        });
      }
    } else {
      // Otherwise, restrict to valid orgs
      filter.organizationId = { $in: approvedOrgIds };
    }

    const opportunities = await Opportunity.find(filter)
      .populate("organizationId", "name organizationInfo")
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .exec();

    const total = await Opportunity.countDocuments(filter);

    res.json({
      opportunities,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total,
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Get single opportunity by ID with enhanced data
const getOpportunityById = async (req, res) => {
  try {
    // Find and increment views
    const opportunity = await Opportunity.findByIdAndUpdate(
      req.params.id,
      { $inc: { views: 1 } },
      { new: true }
    ).populate(
      "organizationId",
      "name email phone description detailedDescription missionStatement location website established profilePicture"
    );

    if (!opportunity) {
      return res.status(404).json({ message: "Opportunity not found" });
    }

    // Count approved applications for this opportunity
    const Application = require("../models/Application");
    const approvedApplications = await Application.countDocuments({
      opportunityId: opportunity._id,
      status: "accepted",
    });

    // Calculate remaining seats
    const remainingSeats = Math.max(
      0,
      opportunity.volunteersNeeded - approvedApplications
    );
    const isFull = remainingSeats === 0;

    // Fetch similar opportunities (same category, exclude current, limit 3)
    const similarOpportunities = await Opportunity.find({
      _id: { $ne: opportunity._id },
      category: opportunity.category,
      status: "active",
    })
      .populate("organizationId", "name location")
      .select("title location category organizationId")
      .limit(3);

    // Build response
    res.json({
      ...opportunity.toObject(),
      stats: {
        views: opportunity.views,
        approvedApplications,
        remainingSeats,
        isFull,
        totalNeeded: opportunity.volunteersNeeded,
      },
      similarOpportunities,
    });
  } catch (err) {
    console.error(err.message);
    if (err.kind === "ObjectId") {
      return res.status(404).json({ message: "Opportunity not found" });
    }
    res.status(500).json({ message: "Server error" });
  }
};

// Create new opportunity
const createOpportunity = async (req, res) => {
  try {
    const {
      title,
      description,
      requiredSkills,
      responsibilities,
      requirements,
      location,
      startDate,
      endDate,
      duration,
      timeCommitment,
      volunteersNeeded,
      category,
      status,
    } = req.body;

    // Get organization ID from authenticated user
    const organizationId = req.user.id;

    // Verify user is an organization
    const organization = await Organization.findById(organizationId);
    if (!organization) {
      return res
        .status(403)
        .json({ message: "Only organizations can create opportunities" });
    }

    if (organization.verificationStatus !== "approved") {
      return res.status(403).json({
        message:
          "Account verification required to post opportunities. Please verify your account.",
      });
    }

    const opportunity = new Opportunity({
      title,
      description,
      detailedDescription,
      organizationId,
      requiredSkills: requiredSkills
        ? typeof requiredSkills === "string"
          ? requiredSkills.split(",").map((s) => s.trim())
          : requiredSkills
        : [],
      responsibilities: responsibilities
        ? typeof responsibilities === "string"
          ? responsibilities.split("\n").filter((s) => s.trim())
          : responsibilities
        : [],
      requirements: requirements
        ? typeof requirements === "string"
          ? requirements.split("\n").filter((s) => s.trim())
          : requirements
        : [],
      location,
      startDate,
      endDate,
      duration,
      timeCommitment,
      volunteersNeeded,
      category: category || "other",
      status: status || "active",
    });

    await opportunity.save();

    res.status(201).json({
      message: "Opportunity created successfully",
      opportunity,
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Update opportunity
const updateOpportunity = async (req, res) => {
  try {
    const opportunity = await Opportunity.findById(req.params.id);

    if (!opportunity) {
      return res.status(404).json({ message: "Opportunity not found" });
    }

    // Check if user owns this opportunity
    if (opportunity.organizationId.toString() !== req.user.id) {
      return res
        .status(403)
        .json({ message: "Not authorized to update this opportunity" });
    }

    const {
      title,
      description,
      requiredSkills,
      responsibilities,
      requirements,
      impact,
      programTimeline,
      location,
      startDate,
      endDate,
      duration,
      timeCommitment,
      volunteersNeeded,
      category,
      status,
      detailedDescription,
    } = req.body;

    // Check for Admin Lock
    if (
      opportunity.isLockedByAdmin &&
      status === "active" &&
      opportunity.status !== "active"
    ) {
      return res.status(403).json({
        message:
          "This post is locked by Admin. You cannot publish it without permission.",
      });
    }

    // Update fields
    if (title) opportunity.title = title;
    if (description) opportunity.description = description;
    if (detailedDescription)
      opportunity.detailedDescription = detailedDescription;
    if (requiredSkills) {
      opportunity.requiredSkills =
        typeof requiredSkills === "string"
          ? requiredSkills.split(",").map((s) => s.trim())
          : requiredSkills;
    }
    if (responsibilities !== undefined) {
      opportunity.responsibilities =
        typeof responsibilities === "string"
          ? responsibilities.split("\n").filter((s) => s.trim())
          : responsibilities;
    }
    if (requirements !== undefined) {
      opportunity.requirements =
        typeof requirements === "string"
          ? requirements.split("\n").filter((s) => s.trim())
          : requirements;
    }
    if (impact !== undefined) {
      opportunity.impact =
        typeof impact === "string"
          ? impact.split("\n").filter((s) => s.trim())
          : impact;
    }
    if (programTimeline !== undefined)
      opportunity.programTimeline = programTimeline;
    if (location) opportunity.location = location;
    if (startDate) opportunity.startDate = startDate;
    if (endDate) opportunity.endDate = endDate;
    if (duration !== undefined) opportunity.duration = duration;
    if (timeCommitment !== undefined)
      opportunity.timeCommitment = timeCommitment;
    if (volunteersNeeded) opportunity.volunteersNeeded = volunteersNeeded;
    if (category) opportunity.category = category;

    // Only allow status update if NOT locked or if changing to draft/inactive
    if (status) {
      if (opportunity.isLockedByAdmin && status === "active") {
        // Already handled above, but double check logic flow
      } else {
        opportunity.status = status;
      }
    }

    // Reset lock if admin didn't explicitly keep it? No, keep it simple. User said:
    // "if I keep in pending... wait until I give permission".
    // So Org can update CONTENT, but Status change to ACTIVE is blocked if locked.

    await opportunity.save();

    res.json({
      message: "Opportunity updated successfully",
      opportunity,
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Delete opportunity
const deleteOpportunity = async (req, res) => {
  try {
    const opportunity = await Opportunity.findById(req.params.id);

    if (!opportunity) {
      return res.status(404).json({ message: "Opportunity not found" });
    }

    // Check if user owns this opportunity
    if (opportunity.organizationId.toString() !== req.user.id) {
      return res
        .status(403)
        .json({ message: "Not authorized to delete this opportunity" });
    }

    await Opportunity.findByIdAndDelete(req.params.id);

    res.json({ message: "Opportunity deleted successfully" });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Get opportunities by organization
const getOrganizationOpportunities = async (req, res) => {
  try {
    const { orgId } = req.params;
    const { status } = req.query;

    let filter = { organizationId: orgId };
    if (status) {
      filter.status = status;
    }

    const opportunities = await Opportunity.find(filter).sort({
      createdAt: -1,
    });

    res.json(opportunities);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Save opportunity for later
const saveOpportunity = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    const volunteer = await Volunteer.findById(userId);
    if (!volunteer) {
      return res
        .status(403)
        .json({ message: "Only volunteers can save opportunities" });
    }

    // Check if already saved
    if (
      volunteer.savedOpportunities &&
      volunteer.savedOpportunities.includes(id)
    ) {
      return res.status(400).json({ message: "Opportunity already saved" });
    }

    if (!volunteer.savedOpportunities) volunteer.savedOpportunities = [];
    volunteer.savedOpportunities.push(id);
    await volunteer.save();

    res.json({ message: "Opportunity saved successfully" });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Unsave opportunity
const unsaveOpportunity = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    const volunteer = await Volunteer.findById(userId);
    if (!volunteer) {
      return res.status(404).json({ message: "Volunteer not found" });
    }

    if (volunteer.savedOpportunities) {
      volunteer.savedOpportunities = volunteer.savedOpportunities.filter(
        (oppId) => oppId.toString() !== id
      );
      await volunteer.save();
    }

    res.json({ message: "Opportunity unsaved successfully" });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Get saved opportunities
const getSavedOpportunities = async (req, res) => {
  try {
    const userId = req.user.id;

    const volunteer = await Volunteer.findById(userId).populate({
      path: "savedOpportunities",
      populate: { path: "organizationId", select: "name" },
    });

    if (!volunteer) {
      return res.status(404).json({ message: "Volunteer not found" });
    }

    res.json(volunteer.savedOpportunities || []);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Admin: Get All Opportunities
const getAllOpportunitiesForAdmin = async (req, res) => {
  try {
    const { status, search, orgId } = req.query;
    let filter = {};

    if (status) filter.status = status;
    if (orgId) filter.organizationId = orgId;
    if (search) {
      filter.$or = [
        { title: { $regex: search, $options: "i" } },
        { description: { $regex: search, $options: "i" } },
      ];
    }

    const opportunities = await Opportunity.find(filter)
      .populate("organizationId", "name email")
      .sort({ createdAt: -1 });

    res.json(opportunities);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Admin: Update Opportunity Status (Lock/Unlock)
const updateOpportunityStatusByAdmin = async (req, res) => {
  try {
    const { id } = req.params;
    const { status, adminComments, isLockedByAdmin } = req.body;

    const opportunity = await Opportunity.findById(id);
    if (!opportunity) {
      return res.status(404).json({ message: "Opportunity not found" });
    }

    if (status) opportunity.status = status;
    if (adminComments !== undefined) opportunity.adminComments = adminComments;
    if (isLockedByAdmin !== undefined)
      opportunity.isLockedByAdmin = isLockedByAdmin;

    await opportunity.save();

    res.json({ message: "Opportunity updated by admin", opportunity });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

module.exports = {
  getOpportunities,
  getOpportunityById,
  createOpportunity,
  updateOpportunity,
  deleteOpportunity,
  getOrganizationOpportunities,
  saveOpportunity,
  unsaveOpportunity,
  getSavedOpportunities,
  getAllOpportunitiesForAdmin,
  updateOpportunityStatusByAdmin,
};
