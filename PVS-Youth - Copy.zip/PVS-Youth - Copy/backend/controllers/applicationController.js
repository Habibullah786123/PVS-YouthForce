const Application = require("../models/Application");
const Opportunity = require("../models/Opportunity");
const Volunteer = require("../models/Volunteer");

// Apply for an opportunity
const applyForOpportunity = async (req, res) => {
  try {
    const { opportunityId, message, experience, skills } = req.body;
    const volunteerId = req.user.id;

    // Check if opportunity exists and is active
    const opportunity = await Opportunity.findById(opportunityId);
    if (!opportunity) {
      return res.status(404).json({ message: "Opportunity not found" });
    }

    if (opportunity.status !== "active") {
      return res
        .status(400)
        .json({ message: "This opportunity is not accepting applications" });
    }

    // Check if user is a volunteer
    const volunteer = await Volunteer.findById(volunteerId);
    if (!volunteer) {
      return res
        .status(403)
        .json({ message: "Only volunteers can apply for opportunities" });
    }

    if (volunteer.verificationStatus !== "approved") {
      return res.status(403).json({
        message:
          "Account verification required to apply. Please upload documents and wait for approval.",
      });
    }

    // Check if user already applied
    const existingApplication = await Application.findOne({
      volunteerId,
      opportunityId,
    });

    if (existingApplication) {
      return res
        .status(400)
        .json({ message: "You have already applied for this opportunity" });
    }

    // Create application
    const application = new Application({
      volunteerId,
      opportunityId,
      organizationId: opportunity.organizationId,
      message: message || "",
      experience: experience || "",
      skills: skills || "",
    });

    await application.save();

    res.status(201).json({
      message: "Application submitted successfully",
      application,
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Get volunteer's applications
const getVolunteerApplications = async (req, res) => {
  try {
    const volunteerId = req.params.userId || req.user.id;

    // If not admin, can only view own applications
    if (req.user.role !== "admin" && req.user.id !== volunteerId) {
      return res
        .status(403)
        .json({ message: "Not authorized to view these applications" });
    }

    const applications = await Application.find({ volunteerId })
      .populate(
        "opportunityId",
        "title description location startDate endDate status category"
      )
      .populate("organizationId", "name email")
      .sort({ appliedAt: -1 });

    res.json(applications);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Get applications for an opportunity
const getOpportunityApplications = async (req, res) => {
  try {
    const { oppId } = req.params;
    const organizationId = req.user.id;

    // Check if user owns this opportunity
    const opportunity = await Opportunity.findById(oppId);
    if (!opportunity) {
      return res.status(404).json({ message: "Opportunity not found" });
    }

    if (
      opportunity.organizationId.toString() !== organizationId &&
      req.user.role !== "admin"
    ) {
      return res
        .status(403)
        .json({ message: "Not authorized to view these applications" });
    }

    const applications = await Application.find({ opportunityId: oppId })
      .populate("volunteerId", "name email phone skills bio location")
      .sort({ appliedAt: -1 });

    res.json(applications);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Update application status
const updateApplicationStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const organizationId = req.user.id;

    const application = await Application.findById(id);
    if (!application) {
      return res.status(404).json({ message: "Application not found" });
    }

    // Check if user owns this application (organization)
    if (
      application.organizationId.toString() !== organizationId &&
      req.user.role !== "admin"
    ) {
      return res
        .status(403)
        .json({ message: "Not authorized to update this application" });
    }

    // Validate status
    if (!["pending", "accepted", "rejected"].includes(status)) {
      return res.status(400).json({ message: "Invalid status" });
    }

    application.status = status;
    application.reviewedAt = new Date();
    await application.save();

    res.json({
      message: "Application status updated successfully",
      application,
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Withdraw application
const withdrawApplication = async (req, res) => {
  try {
    const { id } = req.params;
    const volunteerId = req.user.id;

    const application = await Application.findById(id);
    if (!application) {
      return res.status(404).json({ message: "Application not found" });
    }

    // Check if user owns this application
    if (application.volunteerId.toString() !== volunteerId) {
      return res
        .status(403)
        .json({ message: "Not authorized to withdraw this application" });
    }

    // Only allow withdrawal if status is pending
    if (application.status !== "pending") {
      return res.status(400).json({
        message: "Cannot withdraw application that has been reviewed",
      });
    }

    await Application.findByIdAndDelete(id);

    res.json({ message: "Application withdrawn successfully" });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Get all applications for an organization
const getOrganizationApplications = async (req, res) => {
  try {
    const organizationId = req.user.id;

    // Verify user is organization
    if (req.user.role !== "organization" && req.user.role !== "admin") {
      return res.status(403).json({ message: "Not authorized" });
    }

    const applications = await Application.find({ organizationId })
      .populate("volunteerId", "name email phone skills bio location")
      .populate("opportunityId", "title")
      .sort({ appliedAt: -1 })
      .limit(20); // Limit to recent 20

    res.json(applications);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Admin: Get all applications
const getAllApplicationsForAdmin = async (req, res) => {
  try {
    const { status, opportunityId, volunteerId } = req.query;
    let filter = {};
    if (status) filter.status = status;
    if (opportunityId) filter.opportunityId = opportunityId;
    if (volunteerId) filter.volunteerId = volunteerId;

    const applications = await Application.find(filter)
      .populate("volunteerId", "name email phone")
      .populate("opportunityId", "title organizationId")
      .populate({
        path: "opportunityId",
        populate: { path: "organizationId", select: "name email" },
      })
      .sort({ appliedAt: -1 });

    res.json(applications);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

module.exports = {
  applyForOpportunity,
  getVolunteerApplications,
  getOpportunityApplications,
  updateApplicationStatus,
  withdrawApplication,
  getOrganizationApplications,
  getAllApplicationsForAdmin,
};
