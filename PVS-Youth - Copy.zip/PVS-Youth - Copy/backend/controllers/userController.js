const Admin = require("../models/Admin");
const Organization = require("../models/Organization");
const Volunteer = require("../models/Volunteer");
const Opportunity = require("../models/Opportunity");
const Application = require("../models/Application");
const path = require("path");
const fs = require("fs");

// Helper function to get user by ID and role
const getUserByIdAndRole = async (id, role) => {
  if (role === "admin") return await Admin.findById(id).select("-password");
  if (role === "organization")
    return await Organization.findById(id).select("-password -otp -otpExpires");
  if (role === "volunteer")
    return await Volunteer.findById(id).select("-password -otp -otpExpires");
  return null;
};

// Get user profile
const getProfile = async (req, res) => {
  try {
    const user = await getUserByIdAndRole(req.user.id, req.user.role);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json(user);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Update user profile
const updateProfile = async (req, res) => {
  try {
    const userId = req.user.id;
    const role = req.user.role;
    const updates = req.body;

    let Model;
    let allowedFields = ["name", "location", "profilePicture"];

    if (role === "organization") {
      Model = Organization;
      allowedFields.push(
        "description",
        "detailedDescription",
        "missionStatement",
        "website",
        "registrationNumber",
        "established",
        "focusAreas"
      );
    } else if (role === "volunteer") {
      Model = Volunteer;
      allowedFields.push(
        "bio",
        "detailedBio",
        "skills",
        "cnicNumber",
        "gender",
        "dateOfBirth"
      );
    } else {
      return res
        .status(400)
        .json({ message: "Invalid role for profile update" });
    }

    // Filter updates to only allowed fields
    const filteredUpdates = {};
    Object.keys(updates).forEach((key) => {
      if (allowedFields.includes(key)) {
        filteredUpdates[key] = updates[key];
      }
    });

    // Update user
    const updatedUser = await Model.findByIdAndUpdate(userId, filteredUpdates, {
      new: true,
      runValidators: true,
    }).select("-password -otp -otpExpires");

    res.json({
      message: "Profile updated successfully",
      user: updatedUser,
    });
  } catch (err) {
    console.error(err.message);
    if (err.name === "ValidationError") {
      return res
        .status(400)
        .json({ message: "Validation error", errors: err.errors });
    }
    res.status(500).json({ message: "Server error" });
  }
};

// Upload Documents & Update Profile - MAIN PROFILE UPDATE ENDPOINT
const uploadDocuments = async (req, res) => {
  try {
    const userId = req.user.id;
    const role = req.user.role;
    console.log("--- UPLOAD DEBUG ---");
    console.log("Role:", role);
    console.log("Files:", req.files);
    console.log("Body:", req.body);

    let Model = role === "organization" ? Organization : Volunteer;

    // Build update object using $set for atomic update
    const updateFields = {};

    // Common fields
    if (req.body.name) updateFields.name = req.body.name;
    if (req.body.location) updateFields.location = req.body.location;
    if (req.body.website) updateFields.website = req.body.website;
    if (req.body.phone) updateFields.phone = req.body.phone;

    // Organization-specific fields
    if (role === "organization") {
      if (req.body.description !== undefined)
        updateFields.description = req.body.description;
      if (req.body.detailedDescription !== undefined)
        updateFields.detailedDescription = req.body.detailedDescription;
      if (req.body.missionStatement !== undefined)
        updateFields.missionStatement = req.body.missionStatement;
      if (req.body.registrationNumber !== undefined)
        updateFields.registrationNumber = req.body.registrationNumber;
      if (req.body.established !== undefined)
        updateFields.established = req.body.established;
      console.log("Organization fields to update:", {
        description: req.body.description,
        detailedDescription: req.body.detailedDescription,
        missionStatement: req.body.missionStatement,
      });
    }

    // Volunteer-specific fields
    if (role === "volunteer") {
      if (req.body.bio !== undefined) updateFields.bio = req.body.bio;
      if (req.body.detailedBio !== undefined)
        updateFields.detailedBio = req.body.detailedBio;

      // Handle ID Number / CNIC
      if (req.body.cnicNumber !== undefined) {
        updateFields.cnicNumber = req.body.cnicNumber;
      } else if (req.body.idNumber !== undefined) {
        updateFields.cnicNumber = req.body.idNumber;
      }

      // New Fields
      if (req.body.gender !== undefined) updateFields.gender = req.body.gender;
      if (req.body.dateOfBirth !== undefined)
        updateFields.dateOfBirth = req.body.dateOfBirth;

      if (req.body.skills) {
        updateFields.skills = req.body.skills.split(",").map((s) => s.trim());
      }
    }

    // Handle Profile Picture
    if (req.files && req.files.profilePicture) {
      updateFields.profilePicture = `/uploads/documents/${req.files.profilePicture[0].filename}`;
    }

    console.log("Update fields:", updateFields);

    // Build update query
    const updateQuery = { $set: updateFields };

    // Handle Documents - need to push
    if (req.files && req.files.documents) {
      updateQuery.$push = {
        documents: {
          $each: req.files.documents.map((file) => ({
            name: file.originalname,
            url: `/uploads/documents/${file.filename}`,
          })),
        },
      };
    }

    // Get current user to check verification status
    const currentUser = await Model.findById(userId);

    // Check if verification status needs reset
    if (
      req.files &&
      Object.keys(req.files).length > 0 &&
      ["rejected", "changes_requested"].includes(currentUser.verificationStatus)
    ) {
      updateFields.verificationStatus = "pending";
    }

    // Perform the atomic update
    const savedUser = await Model.findByIdAndUpdate(userId, updateQuery, {
      new: true,
      runValidators: true,
    }).select("-password -otp -otpExpires");

    console.log("AFTER SAVE - User data:", savedUser);

    res.json({ message: "Profile updated successfully", user: savedUser });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Delete Document
const deleteDocument = async (req, res) => {
  try {
    const userId = req.user.id;
    const role = req.user.role;
    const docId = req.params.docId;

    const Model = role === "organization" ? Organization : Volunteer;
    const user = await Model.findById(userId);
    if (!user) return res.status(404).json({ message: "User not found" });

    // Find doc
    const docIndex = user.documents.findIndex(
      (d) => d._id.toString() === docId
    );
    if (docIndex === -1) {
      return res.status(404).json({ message: "Document not found" });
    }

    // Remove file from fs
    const doc = user.documents[docIndex];
    const filePath = path.join(__dirname, "../", doc.url);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }

    // Remove from array
    user.documents.splice(docIndex, 1);
    await user.save();

    res.json({ message: "Document deleted", documents: user.documents });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Admin: Update Verification Status
const updateVerificationStatus = async (req, res) => {
  try {
    const { userId, status, userType } = req.body;

    if (!["approved", "rejected", "changes_requested"].includes(status)) {
      return res.status(400).json({ message: "Invalid status" });
    }

    const Model = userType === "organization" ? Organization : Volunteer;
    const user = await Model.findById(userId);
    if (!user) return res.status(404).json({ message: "User not found" });

    user.verificationStatus = status;
    await user.save();

    res.json({ message: `User status updated to ${status}`, user });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Admin: Add Comment
const addAdminComment = async (req, res) => {
  try {
    const { userId, comment, userType } = req.body;

    const Model = userType === "organization" ? Organization : Volunteer;
    const user = await Model.findById(userId);
    if (!user) return res.status(404).json({ message: "User not found" });

    user.adminComments.push({
      comment,
      adminId: req.user.id,
      date: Date.now(),
    });

    await user.save();
    res.json({ message: "Comment added", comments: user.adminComments });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Admin: Get All Users (Organizations and Volunteers)
const getAllUsersForAdmin = async (req, res) => {
  try {
    const { role, status } = req.query;

    let results = [];

    // Get Organizations
    if (!role || role === "organization") {
      let orgFilter = {};
      if (status) orgFilter.verificationStatus = status;
      const orgs = await Organization.find(orgFilter)
        .select("-password -otp")
        .sort({ createdAt: -1 });
      results = results.concat(orgs);
    }

    // Get Volunteers
    if (!role || role === "volunteer") {
      let volFilter = {};
      if (status) volFilter.verificationStatus = status;
      const vols = await Volunteer.find(volFilter)
        .select("-password -otp")
        .sort({ createdAt: -1 });
      results = results.concat(vols);
    }

    res.json(results);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Admin: Get Single User Details
const getUserDetailsForAdmin = async (req, res) => {
  try {
    const userId = req.params.id;

    // Try to find in Organization first
    let user = await Organization.findById(userId).select("-password -otp");
    let stats = {};

    if (user) {
      // Organization stats
      const opportunityCount = await Opportunity.countDocuments({
        organizationId: userId,
      });
      const closedApplications = await Application.find({
        status: "accepted",
        organizationId: userId,
      });
      const uniqueVolunteers = new Set(
        closedApplications.map((app) => app.volunteerId.toString())
      );
      stats = {
        opportunitiesPosted: opportunityCount,
        volunteersWorkedWith: uniqueVolunteers.size,
      };
    } else {
      // Try Volunteer
      user = await Volunteer.findById(userId).select("-password -otp");
      if (user) {
        const applicationsCount = await Application.countDocuments({
          volunteerId: userId,
        });
        stats = { applicationsSubmitted: applicationsCount };
      }
    }

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const userObj = user.toObject();
    userObj.stats = stats;

    res.json(userObj);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Get user by ID (public profile)
const getUserById = async (req, res) => {
  try {
    const userId = req.params.id;

    // Try Organization first
    let user = await Organization.findById(userId).select(
      "-password -otp -otpExpires -email -phone"
    );
    if (!user) {
      user = await Volunteer.findById(userId).select(
        "-password -otp -otpExpires -email -phone"
      );
    }

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json(user);
  } catch (err) {
    console.error(err.message);
    if (err.kind === "ObjectId") {
      return res.status(404).json({ message: "User not found" });
    }
    res.status(500).json({ message: "Server error" });
  }
};

// Get full volunteer profile for organizations (includes all data)
const getVolunteerFullProfile = async (req, res) => {
  try {
    const volunteerId = req.params.id;

    const volunteer = await Volunteer.findById(volunteerId).select(
      "-password -otp -otpExpires"
    );

    if (!volunteer) {
      return res.status(404).json({ message: "Volunteer not found" });
    }

    // Get application stats
    const applicationsCount = await Application.countDocuments({
      volunteerId: volunteerId,
    });
    const acceptedCount = await Application.countDocuments({
      volunteerId: volunteerId,
      status: "accepted",
    });

    const volunteerObj = volunteer.toObject();
    volunteerObj.stats = {
      totalApplications: applicationsCount,
      acceptedApplications: acceptedCount,
    };

    res.json(volunteerObj);
  } catch (err) {
    console.error(err.message);
    if (err.kind === "ObjectId") {
      return res.status(404).json({ message: "Volunteer not found" });
    }
    res.status(500).json({ message: "Server error" });
  }
};

// Get organization profile (public)
const getOrganizationProfile = async (req, res) => {
  try {
    const { orgId } = req.params;

    const organization = await Organization.findById(orgId).select(
      "-password -otp -otpExpires"
    );

    if (!organization) {
      return res.status(404).json({ message: "Organization not found" });
    }

    res.json(organization);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Add skill to volunteer profile
const addSkill = async (req, res) => {
  try {
    const { skill } = req.body;
    const userId = req.user.id;

    if (!skill || typeof skill !== "string") {
      return res
        .status(400)
        .json({ message: "Skill is required and must be a string" });
    }

    const volunteer = await Volunteer.findById(userId);
    if (!volunteer) {
      return res.status(404).json({ message: "Volunteer not found" });
    }

    if (volunteer.skills && volunteer.skills.includes(skill.trim())) {
      return res.status(400).json({ message: "Skill already exists" });
    }

    if (!volunteer.skills) volunteer.skills = [];
    volunteer.skills.push(skill.trim());
    await volunteer.save();

    res.json({ message: "Skill added successfully", skills: volunteer.skills });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Remove skill from volunteer profile
const removeSkill = async (req, res) => {
  try {
    const { skill } = req.body;
    const userId = req.user.id;

    const volunteer = await Volunteer.findById(userId);
    if (!volunteer) {
      return res.status(404).json({ message: "Volunteer not found" });
    }

    if (volunteer.skills) {
      volunteer.skills = volunteer.skills.filter((s) => s !== skill);
      await volunteer.save();
    }

    res.json({
      message: "Skill removed successfully",
      skills: volunteer.skills,
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Add Qualification
const addQualification = async (req, res) => {
  try {
    const { type, university, marks, grade, completionYear } = req.body;
    const userId = req.user.id;

    if (!type || !university || !marks || !completionYear) {
      return res
        .status(400)
        .json({ message: "All required fields must be filled" });
    }

    const volunteer = await Volunteer.findById(userId);
    if (!volunteer) {
      return res.status(404).json({ message: "Volunteer not found" });
    }

    const newQualification = {
      type,
      university,
      marks,
      grade,
      completionYear,
    };

    if (req.file) {
      newQualification.documentUrl = `/uploads/documents/${req.file.filename}`;
      newQualification.documentName = req.file.originalname;
    }

    if (!volunteer.qualifications) volunteer.qualifications = [];
    volunteer.qualifications.push(newQualification); // Ensure the new qualification is added
    await volunteer.save();
    console.log("Qualification added for:", volunteer.name);

    res.status(201).json({
      message: "Qualification added successfully",
      qualifications: volunteer.qualifications,
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Delete Qualification
const deleteQualification = async (req, res) => {
  try {
    const volunteer = await Volunteer.findById(req.user.id);
    if (!volunteer) {
      return res.status(404).json({ message: "User not found" });
    }

    const qualId = req.params.id;

    // Filter out the qualification to delete
    volunteer.qualifications = volunteer.qualifications.filter(
      (q) => q._id.toString() !== qualId
    );

    await volunteer.save();
    res.json({
      message: "Qualification deleted successfully",
      qualifications: volunteer.qualifications,
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// Update Qualification (Replaces the old one or updates fields)
// Since we might upload a new file, we use the same upload middleware pattern
const updateQualification = async (req, res) => {
  try {
    const { type, university, marks, grade, completionYear } = req.body;
    const documentUrl = req.file
      ? `/uploads/documents/${req.file.filename}`
      : undefined;
    const documentName = req.file ? req.file.originalname : undefined;
    const qualId = req.params.id;

    const volunteer = await Volunteer.findById(req.user.id);
    if (!volunteer) {
      return res.status(404).json({ message: "User not found" });
    }

    const qualIndex = volunteer.qualifications.findIndex(
      (q) => q._id.toString() === qualId
    );
    if (qualIndex === -1) {
      return res.status(404).json({ message: "Qualification not found" });
    }

    // Update fields
    if (type) volunteer.qualifications[qualIndex].type = type;
    if (university) volunteer.qualifications[qualIndex].university = university;
    if (marks) volunteer.qualifications[qualIndex].marks = marks;
    if (grade) volunteer.qualifications[qualIndex].grade = grade;
    if (completionYear)
      volunteer.qualifications[qualIndex].completionYear = completionYear;
    if (documentUrl) {
      volunteer.qualifications[qualIndex].documentUrl = documentUrl;
      volunteer.qualifications[qualIndex].documentName = documentName;
    }

    await volunteer.save();

    res.json({
      message: "Qualification updated successfully",
      qualifications: volunteer.qualifications,
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error" });
  }
};

module.exports = {
  getProfile,
  updateProfile,
  getUserById,
  getVolunteerFullProfile,
  getOrganizationProfile,
  addSkill,
  removeSkill,
  uploadDocuments,
  updateVerificationStatus,
  addAdminComment,
  getAllUsersForAdmin,
  getUserDetailsForAdmin,
  deleteDocument,
  addQualification,
  deleteQualification,
  updateQualification,
};
