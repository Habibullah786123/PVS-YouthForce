const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const dotenv = require("dotenv");
const colors = require("colors");
const Admin = require("./models/Admin");
const Volunteer = require("./models/Volunteer");
const Organization = require("./models/Organization");
const Opportunity = require("./models/Opportunity");
const Application = require("./models/Application");

dotenv.config();

const createDummyData = async () => {
  try {
    const conn = await mongoose.connect(
      process.env.MONGO_URI || "mongodb://localhost:27017/pvs_db"
    );
    console.log(
      `MongoDB Connected: ${conn.connection.host}`.cyan.underline.bold
    );

    // --- 1. ADMINS ---
    const admins = [
      {
        name: "Super Admin",
        email: "admin@pvs.com",
        password: "password123",
        role: "admin",
        phone: "+923001234567",
      },
      {
        name: "Content Admin",
        email: "content@pvs.com",
        password: "password123",
        role: "admin",
        phone: "+923007654321",
      },
    ];

    // Hash passwords manually as insertMany might skip hooks depending on implementation,
    // but models usually use save(). Let's use loop for safety with hooks.
    for (const admin of admins) {
      await Admin.create(admin);
    }
    console.log(`2 Admins Created`.green);

    // --- 2. ORGANIZATIONS (25) ---
    const orgs = [];
    for (let i = 1; i <= 25; i++) {
      orgs.push({
        name: `Organization ${i}`,
        email: `org${i}@example.com`,
        password: "password123",
        phone: `+9230000000${i.toString().padStart(2, "0")}`,
        role: "organization",
        description: `This is a description for Organization ${i}. We focus on community development and youth empowerment.`,
        detailedDescription: `Detailed bio for Organization ${i}. We have been working since 2010 to improve lives in our local community through various initiatives including education, health, and environmental protection.`,
        missionStatement: "To create a better world for everyone.",
        website: `https://org${i}.com`,
        location: ["Karachi", "Lahore", "Islamabad", "Peshawar", "Quetta"][
          i % 5
        ],
        isVerified: i % 3 === 0, // Every 3rd is verified
        established: 2010 + (i % 10),
      });
    }
    const createdOrgs = [];
    for (const org of orgs) {
      const newOrg = await Organization.create(org);
      createdOrgs.push(newOrg);
      // console.log(`Created Org: ${newOrg.email}`);
    }
    console.log(`25 Organizations Created`.green);

    // --- 3. VOLUNTEERS (30) ---
    const volunteers = [];
    const skillsList = [
      "Teaching",
      "Medical",
      "Coding",
      "Event Management",
      "Writing",
      "Graphic Design",
      "Social Media",
      "Fundraising",
    ];
    for (let i = 1; i <= 30; i++) {
      volunteers.push({
        name: `Volunteer ${i}`,
        email: `volunteer${i}@example.com`,
        password: "password123",
        phone: `+9230011111${i.toString().padStart(2, "0")}`,
        role: "volunteer",
        bio: `I am Volunteer ${i}, passionate about making a difference.`,
        skills: [
          skillsList[i % skillsList.length],
          skillsList[(i + 1) % skillsList.length],
        ],
        location: ["Karachi", "Lahore", "Islamabad"][i % 3],
        cnicNumber: `42101-1234567-${i.toString().padStart(1, "0")}`,
        gender: i % 2 === 0 ? "Male" : "Female",
        isVerified: i % 4 === 0, // 25% verified
      });
    }
    const createdVols = [];
    for (const vol of volunteers) {
      const newVol = await Volunteer.create(vol);
      createdVols.push(newVol);
    }
    console.log(`30 Volunteers Created`.green);

    // --- 4. OPPORTUNITIES (~40) ---
    // Create 1-2 opportunities for each org
    const opportunities = [];
    for (let i = 0; i < createdOrgs.length; i++) {
      const org = createdOrgs[i];
      const count = i % 2 === 0 ? 2 : 1; // Alternating 2 and 1 opportunities

      for (let j = 0; j < count; j++) {
        opportunities.push({
          title: `Opportunity ${j + 1} at ${org.name}`,
          description: `Join us for this amazing opportunity to help the community. We need volunteers for ${
            j === 0 ? "event management" : "teaching"
          }.`,
          detailedDescription:
            "This role requires dedication and passion. You will be working directly with our team to ensure the success of the project.",
          organizationId: org._id,
          requiredSkills: [j === 0 ? "Event Management" : "Teaching"],
          location: org.location,
          startDate: new Date(Date.now() + 86400000 * (j * 5)), // Future dates
          endDate: new Date(Date.now() + 86400000 * (j * 5 + 30)),
          volunteersNeeded: 5 + j * 2,
          status: j === 0 ? "active" : i % 5 === 0 ? "completed" : "active", // Some completed
          category: ["education", "health", "community", "environment"][i % 4],
          duration: "1 Month",
        });
      }
    }

    const createdOpps = [];
    for (const opp of opportunities) {
      const newOpp = await Opportunity.create(opp);
      createdOpps.push(newOpp);
    }
    console.log(`${createdOpps.length} Opportunities Created`.green);

    // --- 5. APPLICATIONS (35) ---
    // Randomly assign voluneteers to opportunities
    for (let i = 0; i < 35; i++) {
      const volIndex = i % createdVols.length; // Cycle through volunteers (0-29)
      const oppIndex = i % createdOpps.length; // Cycle through opportunities

      await Application.create({
        volunteerId: createdVols[volIndex]._id,
        opportunityId: createdOpps[oppIndex]._id,
        organizationId: createdOpps[oppIndex].organizationId,
        status: ["pending", "accepted", "rejected"][i % 3],
        message: "I would love to join this project!",
        experience: "I have 2 years of experience.",
        skills: "Hardworking, Punctual",
      });
    }
    console.log(`35 Applications Created`.green);

    console.log("Database Seeded Successfully!".green.inverse);
    process.exit();
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
};

createDummyData();
