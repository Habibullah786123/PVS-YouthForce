# PVS YouthForce - Pakistan Volunteer Service

PVS YouthForce is a web-based platform designed to bridge the gap between young volunteers and Non-Governmental Organizations (NGOs) in Pakistan. It empowers youth to build skills and gain recognition while helping organizations find dedicated volunteers.

## 🚀 Features

- **For Volunteers**:
  - Create and manage detailed profiles with skills and interests.
  - Browse and filter volunteering opportunities.
  - Apply for projects and track application status.
  - **Smart Matching**: System recommends opportunities based on your category and interests.
  - Track impact hours and saved opportunities.

- **For Organizations (NGOs)**:
  - Post new volunteering opportunities.
  - Manage incoming applications (Accept/Reject).
  - Verify volunteer contributions.
  - Organization profile management.

- **For Admins**:
  - Dashboard with platform statistics (Volunteers, NGOs, hours).
  - Approve or Reject new Organization signups.
  - Manage platform content.

## 🛠️ Tech Stack

**Frontend:**

- **HTML5 & CSS3**
- **Bootstrap 5** (via CDN for responsive design)
- **Vanilla JavaScript** (ES6 Modules)
- **Structure**: Multi-page application with modular JS.

**Backend:**

- **Runtime**: Node.js
- **Framework**: Express.js
- **Database**: MongoDB (with Mongoose ODM)
- **Authentication**: JWT (JSON Web Tokens)
- **Security**: Password hashing (bcryptjs)

## 📂 Project Structure

```
PVS-Youth/
├── backend/                # Node.js API Server
│   ├── config/            # DB connection
│   ├── controllers/       # Logic for Users, Opportunities, etc.
│   ├── models/            # Mongoose Schemas
│   ├── routes/            # API Endpoints
│   └── server.js          # Entry point
├── frontend/               # Frontend assets and pages
│   ├── assets/            # CSS, JS, Images
│   └── *.html             # Application pages (login, register, etc.)
├── diagrams/               # Project documentation (System flows)
├── index.html             # Landing Page (Entry point)
└── README.md
```

## ⚙️ Installation & Setup

### Prerequisites

- [Node.js](https://nodejs.org/) (v14+)
- [MongoDB](https://www.mongodb.com/try/download/community) (Local application installed and running)

### 1. Backend Setup

The backend handles the API and database connections.

1.  Navigate to the backend folder:

    ```bash
    cd backend
    ```

2.  Install dependencies:

    ```bash
    npm install
    ```

3.  Configure Environment Variables:
    Create a `.env` file in the `backend` folder with the following contents:

    ```env
    PORT=5000
    MONGO_URI=mongodb://localhost:27017/pvs_db
    JWT_SECRET=your_jwt_secret_key_here
    ```

4.  Seed the Database (Optional but Recommended for testing):
    This command clears the DB and adds dummy users/opportunities.

    ```bash
    node seed.js      # Clears data
    node seedData.js  # Adds sample data
    ```

5.  Start the Server:
    ```bash
    npm start
    # OR for development with auto-reload:
    npm run dev
    ```
    _Server runs on `http://localhost:5000`_

### 2. Frontend Setup

The frontend is built with static HTML/JS files.

1.  **Simplest Method**: Go to the root folder (`PVS-Youth`) and double-click `index.html` to open it in your browser.
2.  **Recommended Method** (Live Server):
    - If using VS Code, install the "Live Server" extension.
    - Right-click `index.html` and select "Open with Live Server".

## 🧪 Testing Credentials

See `user.md` for a full list of login credentials.

- **Admin**: `admin@pvs.com` / `password123`
- **Organization**: `org1@example.com` / `password123`
- **Volunteer**: `volunteer1@example.com` / `password123`

## 🤝 Contribution

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request
