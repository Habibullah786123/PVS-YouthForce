﻿/* ========================================
   PVS YOUTHFORCE - CONSOLIDATED JAVASCRIPT
   All JS extracted from HTML files
   ======================================== */

document.addEventListener("DOMContentLoaded", function () {
  /* ========================================
     0. AUTHENTICATION GUARDS
     ======================================== */
  const currentPath = window.location.pathname;
  const token = localStorage.getItem("token");

  // Protected Routes Check
  if (currentPath.includes("/auth/") && !token) {
    window.location.href = "../login.html";
    return; // Stop execution
  }

  // Load Profile Data if on profile page or other volunteer pages
  if (
    currentPath.includes("profile-settings.html") ||
    currentPath.includes("organization-profile.html") ||
    currentPath.includes("add-qualification.html") ||
    currentPath.includes("my-applications.html") ||
    currentPath.includes("dashboard.html")
  ) {
    loadProfileVerificationData();
  }

  /* ========================================
     MOBILE MENU TOGGLE LOGIC (Global)
     ======================================== */
  const mobileToggle = document.getElementById("mobileMenuToggle");
  const sidebar = document.getElementById("sidebar");

  if (mobileToggle && sidebar) {
    console.log("Mobile Toggle & Sidebar Found");

    // Create overlay if not exists
    let overlay = document.querySelector(".sidebar-overlay");
    if (!overlay) {
      overlay = document.createElement("div");
      overlay.className = "sidebar-overlay";
      // Insert after sidebar for CSS '+' selector to work, OR just body append
      sidebar.parentNode.insertBefore(overlay, sidebar.nextSibling);
    }

    mobileToggle.addEventListener("click", function (e) {
      e.stopPropagation();
      sidebar.classList.toggle("show");
      console.log("Sidebar Show:", sidebar.classList.contains("show"));
    });

    // Close when clicking overlay
    overlay.addEventListener("click", function () {
      sidebar.classList.remove("show");
    });
  }

  async function loadProfileVerificationData() {
    try {
      const token = localStorage.getItem("token");
      const res = await fetch("http://localhost:5000/api/users/profile", {
        headers: { "x-auth-token": token },
      });

      if (!res.ok) {
        throw new Error(`Failed to fetch profile: ${res.statusText}`);
      }

      const user = await res.json();
      console.log("Fetched User Data:", user); // DEBUGGING LINE

      /* ========================================
         MOBILE MENU TOGGLE LOGIC - PREVIOUSLY NESTED, NOW REMOVED
         ======================================== */
      // Logic moved to global scope below

      // Update Sidebar Name if exists
      const sidebarName = document.getElementById("sidebarName");
      const sidebarOrgName = document.getElementById("sidebarOrgName");

      if (sidebarName) sidebarName.textContent = user.name || "Volunteer";
      if (sidebarOrgName)
        sidebarOrgName.textContent = user.name || "Organization";

      // Update Welcome Name on Dashboard
      const welcomeName = document.getElementById("welcomeName");
      console.log("Welcome Element found:", welcomeName); // Debug log
      if (welcomeName) welcomeName.textContent = user.name || "Volunteer";

      // Update Profile Picture in UI
      if (user.profilePicture) {
        const timestamp = new Date().getTime();
        const imageUrl = `http://localhost:5000${user.profilePicture}?t=${timestamp}`;
        document.querySelectorAll(".profile-avatar").forEach((img) => {
          img.src = imageUrl;
        });
      }

      // ACCESS CONTROL: Redirect if wrong page for role
      const currentPath = window.location.pathname;
      if (
        currentPath.includes("profile-settings.html") &&
        user.role === "organization"
      ) {
        window.location.href = "organization-profile.html";
        return;
      }
      if (
        currentPath.includes("organization-profile.html") &&
        user.role !== "organization"
      ) {
        window.location.href = "profile-settings.html";
        return;
      }

      // Populate Basic Fields
      if (document.getElementById("email"))
        document.getElementById("email").value = user.email;
      if (document.getElementById("orgEmail"))
        document.getElementById("orgEmail").value = user.email;

      if (document.getElementById("fullName"))
        document.getElementById("fullName").value = user.name;
      if (document.getElementById("orgName"))
        document.getElementById("orgName").value = user.name;

      if (document.getElementById("phone"))
        document.getElementById("phone").value = user.phone || "";
      if (document.getElementById("orgPhone"))
        document.getElementById("orgPhone").value = user.phone || "";

      // Populate Verification Fields
      const statusBadge = document.getElementById("verificationStatusBadge");
      const adminFeedback = document.getElementById("adminFeedback");

      if (statusBadge) {
        let badgeClass = "bg-secondary";
        if (user.verificationStatus === "approved") badgeClass = "bg-success";
        if (user.verificationStatus === "rejected") badgeClass = "bg-danger";
        if (user.verificationStatus === "changes_requested")
          badgeClass = "bg-warning";

        statusBadge.innerHTML = `<span class="badge ${badgeClass} fs-6">${user.verificationStatus
          .toUpperCase()
          .replace("_", " ")}</span>`;
      }

      // NEW: Update Header Badge (Profile Settings Page)
      const profileHeader = document.querySelector(".card-header h5");
      if (profileHeader) {
        let headerBadgeClass = "bg-secondary";
        if (user.verificationStatus === "approved")
          headerBadgeClass = "bg-success";
        if (user.verificationStatus === "rejected")
          headerBadgeClass = "bg-danger";
        if (user.verificationStatus === "changes_requested")
          headerBadgeClass = "bg-warning text-dark";
        if (user.verificationStatus === "pending")
          headerBadgeClass = "bg-warning text-dark";

        // Avoid duplicating if already appended
        if (!profileHeader.querySelector(".badge")) {
          profileHeader.innerHTML += ` <span class="badge ${headerBadgeClass} ms-2" style="font-size: 0.7em;">${user.verificationStatus
            .toUpperCase()
            .replace("_", " ")}</span>`;
        }
      }

      if (
        adminFeedback &&
        user.adminComments &&
        user.adminComments.length > 0
      ) {
        const lastComment = user.adminComments[user.adminComments.length - 1]; // Show latest
        adminFeedback.classList.remove("d-none");
        adminFeedback.innerHTML = `<strong>Admin Feedback:</strong> ${
          lastComment.comment
        } <small class="text-muted">(${new Date(
          lastComment.date
        ).toLocaleDateString()})</small>`;
      }

      // Pre-fill Root Fields
      if (document.getElementById("location"))
        document.getElementById("location").value = user.location || "";
      if (document.getElementById("orgLocation"))
        document.getElementById("orgLocation").value = user.location || "";
      if (document.getElementById("orgWebsite"))
        document.getElementById("orgWebsite").value = user.website || "";
      if (document.getElementById("bio"))
        document.getElementById("bio").value = user.bio || "";

      // Organization Fields (NEW: Direct fields on Organization model)
      if (user.role === "organization") {
        console.log("Organization data received:", user);
        if (document.getElementById("orgDescription"))
          document.getElementById("orgDescription").value =
            user.description || "";
        if (document.getElementById("orgDetailedDescription")) {
          console.log(
            "Setting orgDetailedDescription to:",
            user.detailedDescription
          );
          document.getElementById("orgDetailedDescription").value =
            user.detailedDescription || "";
        }
        if (document.getElementById("missionStatement"))
          document.getElementById("missionStatement").value =
            user.missionStatement || "";
        if (document.getElementById("idNumber"))
          document.getElementById("idNumber").value =
            user.registrationNumber || "";
      }

      // Volunteer Fields (NEW: Direct fields on Volunteer model)
      if (user.role === "volunteer") {
        if (document.getElementById("idNumber"))
          document.getElementById("idNumber").value = user.cnicNumber || "";
        if (document.getElementById("detailedBio"))
          document.getElementById("detailedBio").value = user.detailedBio || "";

        // Populate Gender
        if (document.getElementById("gender"))
          document.getElementById("gender").value = user.gender || "";

        // Populate Date of Birth (format YYYY-MM-DD for date input)
        if (document.getElementById("dateOfBirth") && user.dateOfBirth) {
          const dob = new Date(user.dateOfBirth);
          const yyyy = dob.getFullYear();
          const mm = String(dob.getMonth() + 1).padStart(2, "0");
          const dd = String(dob.getDate()).padStart(2, "0");
          document.getElementById("dateOfBirth").value = `${yyyy}-${mm}-${dd}`;
        }
      }

      // Populate Skills (if input exists)
      if (document.getElementById("skills") && user.skills) {
        document.getElementById("skills").value = user.skills.join(", ");
      }

      // Show Uploaded Documents
      if (user.documents && user.documents.length > 0) {
        const list = document.getElementById("uploadedDocumentsList");
        if (list) {
          list.innerHTML = '<ul class="list-group list-group-flush">';
          user.documents.forEach((doc) => {
            // Ensure URL is correct. If doc.url starts with /uploads, it maps to our static route.
            const docUrl = `http://localhost:5000${doc.url}`;
            list.innerHTML += `
              <li class="list-group-item d-flex justify-content-between align-items-center px-0 bg-transparent">
                  <div class="d-flex align-items-center">
                      <div class="me-3 text-secondary">
                        <i class="fas fa-file-pdf fa-lg"></i>
                      </div>
                      <div>
                        <a href="${docUrl}" target="_blank" class="text-decoration-none fw-medium text-dark stretched-link-not">${
              doc.name
            }</a>
                        <div class="small text-muted">${new Date(
                          doc.uploadedAt
                        ).toLocaleDateString()}</div>
                      </div>
                  </div>
                  <button type="button" class="btn btn-sm btn-outline-danger z-2" onclick="deleteDocument('${
                    doc._id
                  }')" title="Delete File">
                    <i class="fas fa-trash-alt"></i>
                  </button>
              </li>`;
          });
          list.innerHTML += "</ul>";
        }
      } else {
        const list = document.getElementById("uploadedDocumentsList");
        if (list)
          list.innerHTML =
            '<div class="text-muted small fst-italic">No documents uploaded yet.</div>';
      }

      // Profile Picture Preview
      if (user.profilePicture) {
        const profileImg = document.getElementById("profileImagePreview");
        // Update all avatars on the page (Sidebar + Main Profile)
        const allAvatars = document.querySelectorAll(".profile-avatar");

        const timestamp = new Date().getTime(); // Cache buster
        const imageUrl = `http://localhost:5000${user.profilePicture}?t=${timestamp}`;

        if (profileImg) {
          profileImg.src = imageUrl;
          profileImg.onerror = function () {
            this.src = "../assets/images/profile-placeholder.jpg";
          };
        }

        allAvatars.forEach((img) => {
          img.src = imageUrl;
          img.onerror = function () {
            this.src = "../assets/images/profile-placeholder.jpg";
          };
        });
      }

      // Wire up Profile Pic Preview on Change
      const picInput = document.getElementById("profilePicInput");
      if (picInput) {
        picInput.addEventListener("change", function (e) {
          if (this.files && this.files[0]) {
            const reader = new FileReader();
            reader.onload = function (e) {
              document.getElementById("profileImagePreview").src =
                e.target.result;
            };
            reader.readAsDataURL(this.files[0]);
          }
        });
      }

      // Expose delete function
      window.deleteDocument = async (docId) => {
        if (!confirm("Are you sure you want to delete this document?")) return;
        try {
          const token = localStorage.getItem("token");
          const res = await fetch(
            `http://localhost:5000/api/users/documents/${docId}`,
            {
              method: "DELETE",
              headers: { "x-auth-token": token },
            }
          );
          if (res.ok) {
            window.location.reload();
          } else {
            alert("Failed to delete document");
          }
        } catch (err) {
          console.error(err);
          alert("Error deleting document");
        }
      };

      // === Organization Profile Picture ===
      const orgProfilePicPreview = document.getElementById(
        "profilePicturePreview"
      );
      if (orgProfilePicPreview && user.profilePicture) {
        const timestamp = new Date().getTime();
        const picUrl = `http://localhost:5000${user.profilePicture}?t=${timestamp}`;
        orgProfilePicPreview.src = picUrl;
        orgProfilePicPreview.onerror = function () {
          this.src = "../assets/images/volunteer.jpg";
        };
      }

      // Preview on file select
      const orgPicInput = document.getElementById("profilePictureInput");
      if (orgPicInput) {
        orgPicInput.addEventListener("change", function (e) {
          if (this.files && this.files[0]) {
            const reader = new FileReader();
            reader.onload = function (e) {
              const preview = document.getElementById("profilePicturePreview");
              if (preview) preview.src = e.target.result;
            };
            reader.readAsDataURL(this.files[0]);
          }
        });
      }

      // Upload button handler
      const uploadPicBtn = document.getElementById("uploadProfilePictureBtn");
      if (uploadPicBtn) {
        uploadPicBtn.addEventListener("click", async function () {
          const fileInput = document.getElementById("profilePictureInput");
          if (!fileInput || !fileInput.files || !fileInput.files[0]) {
            alert("Please select an image first");
            return;
          }

          const formData = new FormData();
          formData.append("profilePicture", fileInput.files[0]);

          this.disabled = true;
          this.innerHTML =
            '<i class="fas fa-spinner fa-spin me-2"></i>Uploading...';

          try {
            const token = localStorage.getItem("token");
            const res = await fetch(
              "http://localhost:5000/api/users/upload-documents",
              {
                method: "POST",
                headers: { "x-auth-token": token },
                body: formData,
              }
            );

            if (res.ok) {
              const data = await res.json();
              alert("Profile picture updated successfully!");
              // Update all profile pictures on page
              if (data.user && data.user.profilePicture) {
                const timestamp = new Date().getTime();
                const newPicUrl = `http://localhost:5000${data.user.profilePicture}?t=${timestamp}`;
                document
                  .querySelectorAll(".profile-avatar, #profilePicturePreview")
                  .forEach((img) => {
                    img.src = newPicUrl;
                  });
              }
            } else {
              const errData = await res.json();
              alert(
                "Failed to upload: " + (errData.message || "Unknown error")
              );
            }
          } catch (err) {
            console.error("Upload error:", err);
            alert("Error uploading profile picture");
          } finally {
            this.disabled = false;
            this.innerHTML = '<i class="fas fa-upload me-2"></i>Upload Picture';
          }
        });
      }
    } catch (err) {
      console.error("Error loading profile:", err);
    }
  }

  // Handle Form Submission
  const profileForm =
    document.getElementById("profileSettingsForm") ||
    document.getElementById("orgProfileForm");
  if (profileForm) {
    profileForm.addEventListener("submit", async (e) => {
      e.preventDefault();

      // Create FormData
      const formData = new FormData();

      // Add Profile Data
      if (document.getElementById("fullName"))
        formData.append("name", document.getElementById("fullName").value);
      if (document.getElementById("orgName"))
        formData.append("name", document.getElementById("orgName").value);

      if (document.getElementById("phone"))
        formData.append("phone", document.getElementById("phone").value);
      if (document.getElementById("orgPhone"))
        formData.append("phone", document.getElementById("orgPhone").value);

      // Verification Data
      if (document.getElementById("idNumber"))
        formData.append("idNumber", document.getElementById("idNumber").value);

      // Common Fields
      if (document.getElementById("location"))
        formData.append("location", document.getElementById("location").value);
      if (document.getElementById("orgLocation"))
        formData.append(
          "location",
          document.getElementById("orgLocation").value
        );

      // Volunteer Fields
      if (document.getElementById("bio"))
        formData.append("bio", document.getElementById("bio").value);
      if (document.getElementById("detailedBio"))
        formData.append(
          "detailedBio",
          document.getElementById("detailedBio").value
        );

      if (document.getElementById("gender"))
        formData.append("gender", document.getElementById("gender").value);

      if (document.getElementById("dateOfBirth"))
        formData.append(
          "dateOfBirth",
          document.getElementById("dateOfBirth").value
        );

      if (document.getElementById("skills"))
        formData.append("skills", document.getElementById("skills").value);

      // Organization Fields
      if (document.getElementById("missionStatement")) {
        formData.append(
          "missionStatement",
          document.getElementById("missionStatement").value
        );
      }
      if (document.getElementById("orgDescription")) {
        formData.append(
          "description",
          document.getElementById("orgDescription").value
        );
      }
      if (document.getElementById("orgDetailedDescription")) {
        formData.append(
          "detailedDescription",
          document.getElementById("orgDetailedDescription").value
        );
      }
      if (document.getElementById("orgWebsite")) {
        formData.append("website", document.getElementById("orgWebsite").value);
      }

      // Files
      if (
        document.getElementById("documentUpload") &&
        document.getElementById("documentUpload").files.length > 0
      ) {
        const fileInput = document.getElementById("documentUpload");
        for (let i = 0; i < fileInput.files.length; i++) {
          formData.append("documents", fileInput.files[i]);
        }
      }

      if (
        document.getElementById("profilePicInput") &&
        document.getElementById("profilePicInput").files.length > 0
      ) {
        formData.append(
          "profilePicture",
          document.getElementById("profilePicInput").files[0]
        );
      }

      const submitBtn = profileForm.querySelector('button[type="submit"]');
      const originalText = submitBtn.textContent;
      submitBtn.disabled = true;
      submitBtn.textContent = "Saving...";

      try {
        const updateRes = await fetch(
          "http://localhost:5000/api/users/upload-documents",
          {
            // Reusing this endpoint as it handles profile details too
            method: "POST",
            headers: { "x-auth-token": token },
            body: formData,
          }
        );

        if (updateRes.ok) {
          alert("Profile and Verification details updated successfully!");
          window.location.reload();
        } else {
          const errData = await updateRes.json();
          alert(errData.message || "Failed to update profile");
        }
      } catch (err) {
        console.error(err);
        alert("Network Error");
      } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = originalText;
      }
    });
  }

  // Verification Check for Dashboards
  if (currentPath.includes("dashboard.html")) {
    checkVerificationStatus();
  }

  async function checkVerificationStatus() {
    try {
      const token = localStorage.getItem("token");
      const userStr = localStorage.getItem("user");
      const userObj = userStr ? JSON.parse(userStr) : {};

      // STRICT CHECK: IF ADMIN, DO NOT PROCEED
      if (userObj.role === "admin") return;

      const res = await fetch("http://localhost:5000/api/users/profile", {
        headers: { "x-auth-token": token },
      });
      const user = await res.json();

      if (
        user &&
        user.verificationStatus &&
        user.verificationStatus.toLowerCase() !== "approved"
      ) {
        const mainContent = document.querySelector(".main-content");
        // Remove existing alert if any
        const existingAlert = document.getElementById("verificationAlert");
        if (existingAlert) existingAlert.remove();

        const alertDiv = document.createElement("div");
        alertDiv.id = "verificationAlert";

        let alertClass = "alert-warning";
        let message =
          "Your account is pending verification. Some features may be limited.";
        const isOrg = user.role === "organization";
        const targetPage = isOrg
          ? "organization-profile.html"
          : "profile-settings.html";
        linkDetails = ` <a href="${targetPage}" class="alert-link">Check Status</a>`;

        if (user.verificationStatus === "rejected") {
          alertClass = "alert-danger";
          message =
            "Your account verification was rejected. Please review feedback.";
        } else if (user.verificationStatus === "changes_requested") {
          alertClass = "alert-danger";
          message = "Changes requested on your verification. Please update.";
        }

        alertDiv.className = `alert ${alertClass} m-4 d-flex justify-content-between align-items-center shadow-sm`;
        alertDiv.innerHTML = `
                <div><i class="fas fa-exclamation-triangle me-2"></i><strong>Verification Required:</strong> ${message} ${linkDetails}</div>
            `;

        // Insert after navbar
        const navbar = document.querySelector(".dashboard-navbar");
        if (navbar && navbar.nextSibling) {
          navbar.parentNode.insertBefore(alertDiv, navbar.nextSibling);
        } else {
          mainContent.prepend(alertDiv);
        }
      }
    } catch (err) {
      console.error("Error checking status:", err);
    }
  }

  // Prevent logged in users from visiting login/register
  if (
    (currentPath.includes("login.html") ||
      currentPath.includes("register.html")) &&
    token
  ) {
    const user = JSON.parse(localStorage.getItem("user") || "{}");
    if (user.role === "admin") {
      window.location.href = "auth/admin-dashboard.html"; // Admin Dashboard
    } else if (user.role === "organization") {
      window.location.href = "auth/organization-dashboard.html";
    } else {
      window.location.href = "auth/dashboard.html";
    }
    return;
  }

  /* ========================================
     0.1 LOGOUT FUNCTIONALITY
     ======================================== */
  const logoutBtn = document.getElementById("logoutBtn");
  if (logoutBtn) {
    logoutBtn.addEventListener("click", function (e) {
      e.preventDefault();
      logoutUser();
    });
  }

  function logoutUser() {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    // Redirect to main login page by default
    window.location.href = "../login.html";
  }

  /* ========================================
     1. NAVIGATION & SMOOTH SCROLLING
     ======================================== */
  // ... (keeping existing nav logic if needed, or skipping to relevant parts)

  // ... [Skipping unrelated sections for brevity, assuming they are unchanged] ...

  /* ========================================
     8. AUTHENTICATION (LOGIN/REGISTER)
     ======================================== */

  // Login Logic
  const loginForm = document.getElementById("loginForm");
  if (loginForm) {
    loginForm.addEventListener("submit", async function (e) {
      e.preventDefault();
      const email = document.getElementById("email");
      const password = document.getElementById("password");

      // Get selected role
      const selectedRole = document.querySelector(
        'input[name="loginRole"]:checked'
      ).value;

      try {
        await loginUser({
          email: email.value,
          password: password.value,
          role: selectedRole,
        });
      } catch (error) {
        console.error(error);
      }
    });
  }

  // Admin Login Logic
  const adminLoginForm = document.getElementById("adminLoginForm");
  if (adminLoginForm) {
    adminLoginForm.addEventListener("submit", async function (e) {
      e.preventDefault();
      const email = document.getElementById("adminEmail");
      const password = document.getElementById("adminPassword");

      if (!email.value || !password.value) {
        alert("Please fill in all fields");
        return;
      }

      const submitBtn = adminLoginForm.querySelector('button[type="submit"]');
      submitBtn.disabled = true;
      submitBtn.innerHTML =
        '<span class="spinner-border spinner-border-sm me-2"></span>Verifying...';

      try {
        await loginUser({
          email: email.value,
          password: password.value,
          role: "admin",
        });
      } catch (error) {
        console.error(error);
      } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML = "Login to Dashboard";
      }
    });
  }

  async function loginUser(loginData) {
    // Determine endpoint based on role
    const endpoint =
      loginData.role === "admin"
        ? "http://localhost:5000/api/auth/admin/login"
        : "http://localhost:5000/api/auth/login";

    const response = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email: loginData.email,
        password: loginData.password,
      }),
    });

    const data = await response.json();

    if (response.ok) {
      // Validate Role (Extra check)
      if (loginData.role && data.user.role !== loginData.role) {
        // Should not happen for admin since different endpoint, but good for safety
        alert(`Access Denied: Role mismatch.`);
        return;
      }

      localStorage.setItem("token", data.token);
      localStorage.setItem("user", JSON.stringify(data.user));

      // Redirect based on role
      if (data.user.role === "admin") {
        window.location.href = "auth/admin-dashboard.html";
      } else if (data.user.role === "organization") {
        window.location.href = "auth/organization-dashboard.html";
      } else {
        window.location.href = "auth/dashboard.html";
      }
    } else {
      alert(data.message || "Login failed");
    }
  }

  // ... (OTP Login remains same) ...

  /* ========================================
     9. ADMIN MANAGEMENT
     ======================================== */

  // Manage Admins Page Logic
  const adminsTableBody = document.getElementById("adminsTableBody");
  if (adminsTableBody) {
    loadAdmins();
  }

  async function loadAdmins() {
    try {
      const response = await fetch("http://localhost:5000/api/auth/admin/all", {
        headers: { "x-auth-token": localStorage.getItem("token") },
      });
      const admins = await response.json();

      if (response.ok) {
        adminsTableBody.innerHTML = admins
          .map(
            (admin) => `
                  <tr>
                      <td>
                          <div class="d-flex align-items-center">
                              <div class="bg-light rounded-circle p-2 me-3">
                                  <i class="fas fa-user-shield text-primary"></i>
                              </div>
                              <div>
                                  <h6 class="mb-0">${admin.name}</h6>
                                  <small class="text-muted">ID: ${admin._id.substring(
                                    0,
                                    8
                                  )}...</small>
                              </div>
                          </div>
                      </td>
                      <td>${admin.email}</td>
                      <td><span class="badge bg-danger">Admin</span></td>
                      <td>${new Date(admin.createdAt).toLocaleDateString()}</td>
                  </tr>
              `
          )
          .join("");
      }
    } catch (err) {
      console.error("Error loading admins:", err);
    }
  }

  // Create Admin Form (New Page)
  const createAdminPageForm = document.getElementById("createAdminPageForm");
  if (createAdminPageForm) {
    createAdminPageForm.addEventListener("submit", async function (e) {
      e.preventDefault();

      const name = document.getElementById("adminName").value;
      const email = document.getElementById("adminEmail").value;
      const password = document.getElementById("adminPassword").value;
      const confirmPassword = document.getElementById(
        "adminConfirmPassword"
      ).value;

      if (password !== confirmPassword) {
        alert("Passwords do not match");
        return;
      }

      const submitBtn = this.querySelector('button[type="submit"]');
      const originalText = submitBtn.textContent;
      submitBtn.disabled = true;
      submitBtn.innerHTML =
        '<span class="spinner-border spinner-border-sm me-2"></span>Creating...';

      try {
        const response = await fetch(
          "http://localhost:5000/api/auth/admin/register",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              // "x-auth-token": localStorage.getItem("token") // Optional: protect this endpoint
            },
            body: JSON.stringify({ name, email, password }),
          }
        );

        const data = await response.json();

        if (response.ok) {
          alert("Admin created successfully!");
          this.reset();
          // Refresh table if on same page
          if (adminsTableBody) loadAdmins();
        } else {
          alert(data.message || "Failed to create admin");
        }
      } catch (err) {
        console.error(err);
        alert("Network error");
      } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = originalText;
      }
    });
  }

  /* ========================================
     1. NAVIGATION & SMOOTH SCROLLING
     ======================================== */

  // Smooth scrolling for anchor links
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute("href"));
      if (target) {
        target.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });
      }
    });
  });

  /* ========================================
     1.1 PUBLIC OPPORTUNITIES SEARCH & FILTER
     ======================================== */
  const opportunitiesGrid = document.getElementById("opportunitiesGrid");
  if (opportunitiesGrid) {
    loadOpportunities();

    // Search Inputs
    const searchInput = document.getElementById("searchInput");
    const locationFilter = document.getElementById("locationFilter");
    const searchBtn = document.getElementById("searchBtn");
    const clearFiltersBtn = document.getElementById("clearFilters");
    const categoryCheckboxes = document.querySelectorAll(
      '.filters-sidebar input[type="checkbox"]'
    );

    // Event Listeners
    if (searchBtn) {
      searchBtn.addEventListener("click", () => loadOpportunities());
    }

    if (searchInput) {
      searchInput.addEventListener("keyup", (e) => {
        if (e.key === "Enter") loadOpportunities();
      });
    }

    if (locationFilter) {
      locationFilter.addEventListener("change", () => loadOpportunities());
    }

    if (clearFiltersBtn) {
      clearFiltersBtn.addEventListener("click", () => {
        if (searchInput) searchInput.value = "";
        if (locationFilter) locationFilter.value = "";
        categoryCheckboxes.forEach((cb) => (cb.checked = false));
        loadOpportunities();
      });
    }

    categoryCheckboxes.forEach((cb) => {
      cb.addEventListener("change", function () {
        // Behavior: behave like radio (uncheck others) for simplicity with backend
        if (this.checked) {
          categoryCheckboxes.forEach((other) => {
            if (other !== this) other.checked = false;
          });
        }
        loadOpportunities();
      });
    });
  }

  async function loadOpportunities() {
    if (!opportunitiesGrid) return;

    opportunitiesGrid.innerHTML = `
        <div class="col-12 text-center py-5">
          <div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Loading...</span>
          </div>
        </div>`;

    try {
      // Build Query
      const search = document.getElementById("searchInput")?.value || "";
      const location = document.getElementById("locationFilter")?.value || "";

      let category = "";
      document
        .querySelectorAll('.filters-sidebar input[type="checkbox"]:checked')
        .forEach((cb) => {
          category = cb.value; // Taking the last one if multiple (but we enforce single)
        });

      const params = new URLSearchParams();
      if (search) params.append("search", search);
      if (location) params.append("location", location);
      if (category) params.append("category", category);

      const response = await fetch(
        `http://localhost:5000/api/opportunities?${params.toString()}`
      );
      const data = await response.json();

      opportunitiesGrid.innerHTML = "";

      if (data.opportunities && data.opportunities.length > 0) {
        data.opportunities.forEach((opp) => {
          opportunitiesGrid.innerHTML += `
                    <div class="col-md-6 col-lg-4 mb-4">
                      <div class="card h-100 shadow-sm border-0 opportunity-card">
                        <div class="card-body">
                          <div class="d-flex justify-content-between align-items-start mb-3">
                            <span class="badge bg-primary rounded-pill">${
                              opp.category
                            }</span>
                            <small class="text-muted"><i class="far fa-clock me-1"></i>${new Date(
                              opp.createdAt
                            ).toLocaleDateString()}</small>
                          </div>
                          <h5 class="card-title fw-bold text-dark">${
                            opp.title
                          }</h5>
                          <p class="card-text text-muted mb-3">${
                            opp.organizationId?.name || "Organization"
                          }</p>
                          <div class="d-flex align-items-center mb-2 text-secondary">
                            <i class="fas fa-map-marker-alt me-2"></i> ${
                              opp.location
                            }
                          </div>
                          <div class="d-flex align-items-center mb-3 text-secondary">
                            <i class="fas fa-calendar-alt me-2"></i> ${new Date(
                              opp.startDate
                            ).toLocaleDateString()}
                          </div>
                          <p class="card-text text-muted small">${opp.description.substring(
                            0,
                            100
                          )}...</p>
                        </div>
                        <div class="card-footer bg-white border-top-0 pb-4">
                           <a href="opportunity-details.html?id=${
                             opp._id
                           }" class="btn btn-outline-primary w-100">View Details</a>
                        </div>
                      </div>
                    </div>
                  `;
        });
      } else {
        opportunitiesGrid.innerHTML = `
                <div class="col-12 text-center py-5">
                   <div class="text-muted">
                     <i class="fas fa-search fa-3x mb-3"></i>
                     <h5>No opportunities found matching your criteria.</h5>
                     <p>Try adjusting your filters or search terms.</p>
                   </div>
                </div>`;
      }
    } catch (err) {
      console.error("Error fetching opportunities:", err);
      opportunitiesGrid.innerHTML = `<div class="col-12 text-center text-danger">Error loading opportunities.</div>`;
    }
  }

  // Navbar background change on scroll
  // const navbar = document.querySelector('.navbar');
  // if (navbar) {
  //   window.addEventListener('scroll', function() {
  //     if (window.scrollY > 50) {
  //       navbar.classList.add('bg-white', 'shadow');
  //       navbar.classList.remove('bg-transparent');
  //     } else {
  //       navbar.classList.remove('bg-white', 'shadow');
  //       navbar.classList.add('bg-transparent');
  //     }
  //   });
  // }

  /* ========================================
     2. ANIMATION ON SCROLL
     ======================================== */

  const observerOptions = {
    threshold: 0.1,
    rootMargin: "0px 0px -50px 0px",
  };

  const observer = new IntersectionObserver(function (entries) {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("animate__animated", "animate__fadeInUp");
      }
    });
  }, observerOptions);

  document
    .querySelectorAll(
      ".card, .stat-card, .mission-card, .team-member, .stat-item"
    )
    .forEach((card) => {
      observer.observe(card);
    });

  /* ========================================
     3. CONTACT FORM HANDLING
     ======================================== */

  const contactForm = document.getElementById("contactForm");
  if (contactForm) {
    contactForm.addEventListener("submit", function (e) {
      e.preventDefault();

      const formData = {
        name: document.getElementById("name").value,
        email: document.getElementById("email").value,
        phone: document.getElementById("phone").value,
        subject: document.getElementById("subject").value,
        message: document.getElementById("message").value,
        newsletter: document.getElementById("newsletter")
          ? document.getElementById("newsletter").checked
          : false,
      };

      // Basic validation
      if (
        !formData.name ||
        !formData.email ||
        !formData.subject ||
        !formData.message
      ) {
        alert("Please fill in all required fields.");
        return;
      }

      // Email validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.email)) {
        alert("Please enter a valid email address.");
        return;
      }

      // Simulate form submission
      alert(
        "Thank you for your message! We'll get back to you within 24 hours."
      );
      this.reset();
    });
  }

  /* ========================================
     4. FAQ ACCORDION FUNCTIONALITY
     ======================================== */

  const faqItems = document.querySelectorAll(".faq-item");
  if (faqItems.length > 0) {
    faqItems.forEach((item) => {
      const question = item.querySelector(".faq-question");
      if (question) {
        question.addEventListener("click", function () {
          // Close all other FAQ items
          faqItems.forEach((otherItem) => {
            if (otherItem !== item) {
              otherItem.classList.remove("active");
            }
          });
          // Toggle current FAQ item
          item.classList.toggle("active");
        });
      }
    });
  }

  // FAQ Search functionality
  const searchInput = document.getElementById("faqSearch");
  if (searchInput) {
    const faqCategories = document.querySelectorAll(".faq-category");

    searchInput.addEventListener("input", function () {
      const searchTerm = this.value.toLowerCase();

      faqCategories.forEach((category) => {
        const faqItems = category.querySelectorAll(".faq-item");
        let categoryVisible = false;

        faqItems.forEach((item) => {
          const question = item
            .querySelector(".faq-question")
            .textContent.toLowerCase();
          const answer = item
            .querySelector(".faq-answer")
            .textContent.toLowerCase();

          if (question.includes(searchTerm) || answer.includes(searchTerm)) {
            item.style.display = "block";
            categoryVisible = true;
          } else {
            item.style.display = "none";
          }
        });

        category.style.display = categoryVisible ? "block" : "none";
      });
    });
  }

  // FAQ Category filtering
  const categoryTabs = document.querySelectorAll(".category-tab");
  if (categoryTabs.length > 0) {
    categoryTabs.forEach((tab) => {
      tab.addEventListener("click", function () {
        // Remove active class from all tabs
        categoryTabs.forEach((t) => t.classList.remove("active"));
        // Add active class to clicked tab
        this.classList.add("active");

        const selectedCategory = this.dataset.category;
        const faqCategories = document.querySelectorAll(".faq-category");

        faqCategories.forEach((category) => {
          if (
            selectedCategory === "all" ||
            category.dataset.category.includes(selectedCategory)
          ) {
            category.style.display = "block";
          } else {
            category.style.display = "none";
          }
        });
      });
    });
  }

  /* ========================================
     5. LOGIN PAGE FUNCTIONALITY
     ======================================== */

  // Tab switching for login methods
  const passwordTab = document.getElementById("passwordTab");
  const otpTab = document.getElementById("otpTab");
  const passwordForm = document.getElementById("passwordLoginForm");
  const otpForm = document.getElementById("otpLoginForm");

  if (passwordTab && otpTab) {
    passwordTab.addEventListener("click", function () {
      passwordTab.classList.add("active");
      otpTab.classList.remove("active");
      if (passwordForm) passwordForm.classList.add("active");
      if (otpForm) otpForm.classList.remove("active");
    });

    otpTab.addEventListener("click", function () {
      otpTab.classList.add("active");
      passwordTab.classList.remove("active");
      if (otpForm) otpForm.classList.add("active");
      if (passwordForm) passwordForm.classList.remove("active");
    });
  }

  // Password visibility toggle
  const togglePasswordBtn = document.getElementById("togglePassword");
  if (togglePasswordBtn) {
    togglePasswordBtn.addEventListener("click", function () {
      const password = document.getElementById("loginPassword");
      const icon = this.querySelector("i");
      if (password) {
        if (password.type === "password") {
          password.type = "text";
          icon.classList.remove("fa-eye");
          icon.classList.add("fa-eye-slash");
        } else {
          password.type = "password";
          icon.classList.remove("fa-eye-slash");
          icon.classList.add("fa-eye");
        }
      }
    });
  }

  // OTP input handling
  const otpInputs = document.querySelectorAll(".otp-input");
  if (otpInputs.length > 0) {
    otpInputs.forEach((input, index) => {
      input.addEventListener("input", function () {
        if (this.value.length === 1 && index < otpInputs.length - 1) {
          otpInputs[index + 1].focus();
        }
      });

      input.addEventListener("keydown", function (e) {
        if (e.key === "Backspace" && this.value === "" && index > 0) {
          otpInputs[index - 1].focus();
        }
      });
    });
  }

  // Send OTP
  const sendOTPBtn = document.getElementById("sendOTP");
  if (sendOTPBtn) {
    sendOTPBtn.addEventListener("click", function () {
      const email = document.getElementById("otpEmail");
      if (!email || !email.value) {
        alert("Please enter your email address.");
        return;
      }

      // Simulate sending OTP
      this.textContent = "Sending...";
      this.disabled = true;

      setTimeout(() => {
        this.textContent = "OTP Sent!";
        const otpSection = document.getElementById("otpSection");
        if (otpSection) {
          otpSection.classList.remove("d-none");
          otpSection.style.display = "block";
        }
        this.disabled = false;
      }, 2000);
    });
  }

  // Resend OTP
  const resendOTPBtn = document.getElementById("resendOTP");
  if (resendOTPBtn) {
    resendOTPBtn.addEventListener("click", function (e) {
      e.preventDefault();
      if (sendOTPBtn) sendOTPBtn.click();
    });
  }

  // Password login form submission
  if (passwordForm) {
    passwordForm.addEventListener("submit", async function (e) {
      e.preventDefault();
      const email = document.getElementById("loginEmail");
      const password = document.getElementById("loginPassword");

      if (!email || !email.value || !password || !password.value) {
        alert("Please fill in all fields.");
        return;
      }

      // Email validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email.value)) {
        alert("Please enter a valid email address.");
        return;
      }

      // Show loading state
      const submitBtn = passwordForm.querySelector('button[type="submit"]');
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML =
          '<span class="spinner-border spinner-border-sm me-2"></span>Signing In...';
      }

      // Get selected role
      const selectedRole = document.querySelector(
        'input[name="loginRole"]:checked'
      ).value;

      try {
        await loginUser({
          email: email.value,
          password: password.value,
          role: selectedRole, // Pass expected role to function for validation
        });
      } catch (error) {
        console.error("Login failed:", error);
      } finally {
        // Reset button state
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.innerHTML = "Sign In";
        }
      }
    });
  }

  // OTP login form submission
  if (otpForm) {
    otpForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const otp = Array.from(otpInputs)
        .map((input) => input.value)
        .join("");

      if (otp.length !== 6) {
        alert("Please enter the complete 6-digit OTP.");
        return;
      }

      // Simulate OTP verification
      alert("OTP verified! Login successful. Redirecting to dashboard...");
      window.location.href = "auth/dashboard.html";
    });
  }

  // Forgot password
  const forgotPasswordLink = document.getElementById("forgotPasswordLink");
  if (forgotPasswordLink) {
    forgotPasswordLink.addEventListener("click", function (e) {
      e.preventDefault();
      const email = document.getElementById("loginEmail");
      if (!email || !email.value) {
        alert("Please enter your email address first.");
        return;
      }
      alert("Password reset link sent to your email.");
    });
  }

  /* ========================================
      API INTEGRATION FUNCTIONS
      ======================================== */

  // Register User API Function
  async function registerUser(userData) {
    console.log("Registering user:", userData);
    try {
      const response = await fetch("http://localhost:5000/api/auth/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(userData),
      });

      const data = await response.json();
      console.log("Registration response:", data);

      if (response.ok) {
        // Store token and redirect
        localStorage.setItem("token", data.token);
        localStorage.setItem("user", JSON.stringify(data.user));
        console.log("Redirecting based on role:", data.user.role);
        if (data.user.role === "organization") {
          window.location.href = "auth/organization-dashboard.html";
        } else {
          window.location.href = "auth/dashboard.html";
        }
      } else {
        // Show error message
        console.error("Registration failed:", data.message);
        alert(data.message || "Registration failed");
      }
    } catch (error) {
      console.error("Registration error:", error);
      alert("Network error. Please try again.");
    }
  }

  /* ========================================
     6. REGISTRATION MULTI-STEP FORM
     ======================================== */

  let selectedRole = "";

  // Role selection
  const roleCards = document.querySelectorAll(".role-card");
  roleCards.forEach((card) => {
    card.addEventListener("click", function () {
      roleCards.forEach((c) => c.classList.remove("selected"));
      this.classList.add("selected");
      selectedRole = this.dataset.role;
    });
  });

  // Step navigation
  const nextToStep2Btn = document.getElementById("nextToStep2");
  if (nextToStep2Btn) {
    nextToStep2Btn.addEventListener("click", function () {
      console.log("Next to Step 2 clicked. Selected Role:", selectedRole);
      if (!selectedRole) {
        alert("Please select your role first.");
        return;
      }

      try {
        const step1Content = document.getElementById("step1-content");
        const step1Indicator = document.getElementById("step1");
        const step2Indicator = document.getElementById("step2");
        const volStep2 = document.getElementById("volunteer-step2");
        const orgStep2 = document.getElementById("organization-step2");

        if (step1Content) step1Content.classList.remove("active");
        if (step1Indicator) step1Indicator.classList.remove("active");
        if (step2Indicator) step2Indicator.classList.add("active");

        if (selectedRole === "volunteer") {
          if (volStep2) volStep2.classList.add("active");
        } else {
          if (orgStep2) orgStep2.classList.add("active");
        }
      } catch (err) {
        console.error("Error in Step 1->2 transition:", err);
        alert("An error occurred. Please refresh and try again.");
      }
    });
  }

  // Back to step 1
  const backToStep1Btns = document.querySelectorAll(
    "#backToStep1, #backToStep1Org"
  );
  backToStep1Btns.forEach((btn) => {
    if (btn) {
      btn.addEventListener("click", function () {
        document
          .querySelectorAll(".form-step")
          .forEach((step) => step.classList.remove("active"));
        document.getElementById("step1-content").classList.add("active");
        document.getElementById("step2").classList.remove("active");
        document.getElementById("step1").classList.add("active");
      });
    }
  });

  // Next to step 3
  const nextToStep3Btns = document.querySelectorAll(
    "#nextToStep3, #nextToStep3Org"
  );
  nextToStep3Btns.forEach((btn) => {
    if (btn) {
      btn.addEventListener("click", function () {
        console.log("Next to Step 3 clicked. Role:", selectedRole);
        try {
          let isValid = true;
          let email = "";
          let missingFields = [];

          if (selectedRole === "volunteer") {
            const fullName = document.getElementById("fullName");
            const fatherName = document.getElementById("fatherName");
            email = document.getElementById("email");
            const phone = document.getElementById("phone");
            const dob = document.getElementById("dob");
            const gender = document.getElementById("gender");
            const city = document.getElementById("city");

            if (!fullName?.value) missingFields.push("Full Name");
            if (!fatherName?.value) missingFields.push("Father Name");
            if (!email?.value) missingFields.push("Email");
            if (!phone?.value) missingFields.push("Phone");
            if (!dob?.value) missingFields.push("Date of Birth");
            if (!gender?.value) missingFields.push("Gender");
            if (!city?.value) missingFields.push("City");

            if (missingFields.length > 0) {
              console.log("Missing fields:", missingFields);
              isValid = false;
            }

            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (email?.value && !emailRegex.test(email.value)) {
              alert("Please enter a valid email address.");
              return;
            }

            // Phone validation
            const phoneRegex = /^03\d{2}-?\d{7}$/;
            if (phone?.value && !phoneRegex.test(phone.value)) {
              alert("Please enter a valid phone number (03XX-XXXXXXX).");
              return;
            }
          } else if (selectedRole === "organization") {
            const orgName = document.getElementById("orgName");
            const contactPerson = document.getElementById("contactPerson");
            const contactPhone = document.getElementById("contactPhone");
            email = document.getElementById("orgEmail");
            const orgType = document.getElementById("orgType");
            const orgCity = document.getElementById("orgCity");
            const orgDescription = document.getElementById("orgDescription");

            if (!orgName?.value) missingFields.push("Org Name");
            if (!contactPerson?.value) missingFields.push("Contact Person");
            if (!contactPhone?.value) missingFields.push("Contact Phone");
            if (!email?.value) missingFields.push("Email");
            if (!orgType?.value) missingFields.push("Org Type");
            if (!orgCity?.value) missingFields.push("City");
            if (!orgDescription?.value) missingFields.push("Description");

            if (missingFields.length > 0) {
              console.log("Missing fields:", missingFields);
              isValid = false;
            }

            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (email?.value && !emailRegex.test(email.value)) {
              alert("Please enter a valid email address.");
              return;
            }

            // Phone validation
            const phoneRegex = /^03\d{2}-?\d{7}$/;
            if (contactPhone?.value && !phoneRegex.test(contactPhone.value)) {
              alert("Please enter a valid phone number (03XX-XXXXXXX).");
              return;
            }
          }

          if (!isValid) {
            alert("Please fill in all required fields.");
            return;
          }

          document
            .querySelectorAll(".form-step")
            .forEach((step) => step.classList.remove("active"));

          const step3Content = document.getElementById("step3-content");
          const step2Indicator = document.getElementById("step2");
          const step3Indicator = document.getElementById("step3");

          if (step3Content) step3Content.classList.add("active");
          if (step2Indicator) step2Indicator.classList.remove("active");
          if (step3Indicator) step3Indicator.classList.add("active");

          // Pre-fill email in step 3
          const setupEmail = document.getElementById("setupEmail");
          if (setupEmail && email) setupEmail.value = email.value;
        } catch (err) {
          console.error("Error in Step 2->3 transition:", err);
          alert("An error occurred. Please check console and try again.");
        }
      });
    }
  });

  // Back to step 2
  const backToStep2Btn = document.getElementById("backToStep2");
  if (backToStep2Btn) {
    backToStep2Btn.addEventListener("click", function () {
      document
        .querySelectorAll(".form-step")
        .forEach((step) => step.classList.remove("active"));
      document.getElementById("step3").classList.remove("active");
      document.getElementById("step2").classList.add("active");

      if (selectedRole === "volunteer") {
        document.getElementById("volunteer-step2").classList.add("active");
      } else {
        document.getElementById("organization-step2").classList.add("active");
      }
    });
  }

  // Password strength indicator
  const passwordInput = document.getElementById("password");
  const passwordStrengthBar = document.getElementById("passwordStrength");

  if (passwordInput && passwordStrengthBar) {
    passwordInput.addEventListener("input", function () {
      const password = this.value;
      let strength = 0;

      if (password.length >= 8) strength += 25;
      if (password.match(/[a-z]/)) strength += 25;
      if (password.match(/[A-Z]/)) strength += 25;
      if (password.match(/[0-9]/)) strength += 25;

      passwordStrengthBar.style.width = strength + "%";

      if (strength < 50) {
        passwordStrengthBar.style.backgroundColor = "#dc2626";
      } else if (strength < 75) {
        passwordStrengthBar.style.backgroundColor = "#f59e0b";
      } else {
        passwordStrengthBar.style.backgroundColor = "#10b981";
      }
    });
  }

  // Password confirmation match
  const confirmPasswordInput = document.getElementById("confirmPassword");
  const passwordMatchDiv = document.getElementById("passwordMatch");

  if (confirmPasswordInput && passwordMatchDiv) {
    confirmPasswordInput.addEventListener("input", function () {
      const password = document.getElementById("password");
      if (password && this.value === password.value) {
        passwordMatchDiv.innerHTML =
          '<small class="text-success"><i class="fas fa-check"></i> Passwords match</small>';
      } else {
        passwordMatchDiv.innerHTML =
          '<small class="text-danger"><i class="fas fa-times"></i> Passwords do not match</small>';
      }
    });
  }

  // Toggle password visibility in registration
  const togglePasswordBtns = document.querySelectorAll(
    "#togglePassword, #toggleConfirmPassword"
  );
  togglePasswordBtns.forEach((btn) => {
    if (btn) {
      btn.addEventListener("click", function () {
        const targetId =
          this.id === "togglePassword" ? "password" : "confirmPassword";
        const input = document.getElementById(targetId);
        const icon = this.querySelector("i");

        if (input) {
          if (input.type === "password") {
            input.type = "text";
            icon.classList.remove("fa-eye");
            icon.classList.add("fa-eye-slash");
          } else {
            input.type = "password";
            icon.classList.remove("fa-eye-slash");
            icon.classList.add("fa-eye");
          }
        }
      });
    }
  });

  // Account setup form submission
  const accountSetupForm = document.getElementById("accountSetupForm");
  if (accountSetupForm) {
    accountSetupForm.addEventListener("submit", async function (e) {
      e.preventDefault();

      const password = document.getElementById("password");
      const confirmPassword = document.getElementById("confirmPassword");
      const acceptTerms = document.getElementById("acceptTerms");

      if (!password || !confirmPassword || !acceptTerms) {
        alert("Please fill in all required fields.");
        return;
      }

      if (password.value !== confirmPassword.value) {
        alert("Passwords do not match.");
        return;
      }

      if (!acceptTerms.checked) {
        alert("Please accept the Terms & Conditions.");
        return;
      }

      // Collect user data based on role
      let userData = {
        password: password.value,
        role: selectedRole,
      };

      if (selectedRole === "volunteer") {
        userData.name = document.getElementById("fullName").value;
        userData.email = document.getElementById("email").value;
        userData.phone = document.getElementById("phone").value;
        // Additional fields can be added if needed
      } else if (selectedRole === "organization") {
        userData.name = document.getElementById("orgName").value;
        userData.email = document.getElementById("orgEmail").value;
        userData.phone = document.getElementById("contactPhone").value;
        // Additional fields can be added if needed
      }

      // Basic validation
      if (
        !userData.name ||
        !userData.email ||
        !userData.phone ||
        !userData.password
      ) {
        alert("Please fill in all required fields.");
        return;
      }

      // Email validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(userData.email)) {
        alert("Please enter a valid email address.");
        return;
      }

      // Phone validation (Pakistani format)
      const phoneRegex = /^03\d{2}-?\d{7}$/;
      if (!phoneRegex.test(userData.phone)) {
        alert("Please enter a valid phone number (03XX-XXXXXXX).");
        return;
      }

      // Password validation
      if (userData.password.length < 8) {
        alert("Password must be at least 8 characters long.");
        return;
      }

      // Show loading state
      const registerBtn = document.getElementById("registerBtn");
      if (registerBtn) {
        registerBtn.disabled = true;
        registerBtn.innerHTML =
          '<span class="spinner-border spinner-border-sm me-2"></span>Creating Account...';
      }

      try {
        await registerUser(userData);
      } catch (error) {
        console.error("Registration failed:", error);
      } finally {
        // Reset button state
        if (registerBtn) {
          registerBtn.disabled = false;
          registerBtn.innerHTML = "Create Account";
        }
      }
    });
  }

  /* ========================================
     7. DASHBOARD FUNCTIONALITY
     ======================================== */

  // Mobile menu toggle - REMOVED (duplicate of global logic at top of file)

  // Profile picture upload
  window.changeProfilePicture = function () {
    const input = document.getElementById("profilePicInput");
    if (input) input.click();
  };

  window.updateProfilePicture = function (event) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = function (e) {
        const profilePic = document.getElementById("profilePic");
        if (profilePic) profilePic.src = e.target.result;
      };
      reader.readAsDataURL(file);
    }
  };

  // Certificate upload
  window.openFileManager = function () {
    const input = document.getElementById("certificate");
    if (input) input.click();
  };

  const certificateInput = document.getElementById("certificate");
  if (certificateInput) {
    certificateInput.addEventListener("change", function () {
      if (this.files.length > 0) {
        const file = this.files[0];
        const list = document.getElementById("certificateList");
        if (list) {
          list.innerHTML += `<div class="alert alert-success alert-dismissible fade show mt-2" role="alert">
            <i class="fas fa-file-alt me-2"></i>${file.name} uploaded successfully!
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
          </div>`;
        }
      }
    });
  }

  window.editProfile = function () {
    alert(
      "Edit profile functionality would open a modal or redirect to edit page."
    );
  };

  /* ========================================
     8. ORGANIZATION DASHBOARD
     ======================================== */

  // Post opportunity form submission
  // Post opportunity form submission
  const postOpportunityForm = document.getElementById("postOpportunityForm");
  if (postOpportunityForm) {
    postOpportunityForm.addEventListener("submit", async function (e) {
      e.preventDefault();

      // FEATURE RESTRICTION: Check verification before posting
      try {
        const token = localStorage.getItem("token");
        const res = await fetch("http://localhost:5000/api/users/profile/me", {
          headers: { "x-auth-token": token },
        });
        const user = await res.json();
        if (user.verificationStatus !== "approved") {
          alert(
            "Action Restricted: You must be a verified organization to post opportunities."
          );
          return;
        }
      } catch (err) {
        console.error(err);
      }

      const submitBtn = document.getElementById("postBtn");
      const originalBtnText = submitBtn
        ? submitBtn.innerHTML
        : "Post Opportunity";
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML =
          '<span class="spinner-border spinner-border-sm me-2"></span>Posting...';
      }

      const getVal = (id) => document.getElementById(id).value;

      const opportunityData = {
        title: getVal("title"),
        description: getVal("description"),
        category: getVal("category"),
        location: getVal("location"),
        startDate: getVal("startDate"),
        endDate: getVal("endDate"),
        volunteersNeeded: getVal("volunteersNeeded"),
        requiredSkills: getVal("skills")
          .split(",")
          .map((s) => s.trim())
          .filter((s) => s),
      };

      try {
        const token = localStorage.getItem("token");
        if (!token) {
          throw new Error("Please login to post an opportunity");
        }

        const response = await fetch(
          "http://localhost:5000/api/opportunities",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "x-auth-token": token,
            },
            body: JSON.stringify(opportunityData),
          }
        );

        const data = await response.json();

        if (response.ok) {
          alert("Opportunity posted successfully!");
          this.reset();
          window.location.href = "../opportunities.html";
        } else {
          throw new Error(data.message || "Failed to post opportunity");
        }
      } catch (err) {
        alert(err.message);
      } finally {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.innerHTML = originalBtnText;
        }
      }
    });
  }

  // Application actions (Accept/Reject)
  document.querySelectorAll(".btn-success").forEach((btn) => {
    btn.addEventListener("click", function () {
      if (
        this.textContent.trim() === "Accept" &&
        confirm("Accept this volunteer application?")
      ) {
        this.textContent = "Accepted";
        this.classList.remove("btn-success");
        this.classList.add("btn-secondary");
        this.disabled = true;
        const rejectBtn = this.parentElement.querySelector(
          ".btn-outline-danger"
        );
        if (rejectBtn) rejectBtn.style.display = "none";
      }
    });
  });

  document.querySelectorAll(".btn-outline-danger").forEach((btn) => {
    btn.addEventListener("click", function () {
      if (
        this.textContent.trim() === "Reject" &&
        confirm("Reject this volunteer application?")
      ) {
        this.textContent = "Rejected";
        this.classList.remove("btn-outline-danger");
        this.classList.add("btn-secondary");
        this.disabled = true;
        const acceptBtn = this.parentElement.querySelector(".btn-success");
        if (acceptBtn) acceptBtn.style.display = "none";
      }
    });
  });

  /* ========================================
     9. UTILITY FUNCTIONS
     ======================================== */

  // Initialize tooltips if Bootstrap is available
  if (typeof bootstrap !== "undefined") {
    const tooltipTriggerList = [].slice.call(
      document.querySelectorAll('[data-bs-toggle="tooltip"]')
    );
    tooltipTriggerList.map(function (tooltipTriggerEl) {
      return new bootstrap.Tooltip(tooltipTriggerEl);
    });
  }

  // Console log removal for production
  if (
    window.location.hostname !== "localhost" &&
    window.location.hostname !== "127.0.0.1"
  ) {
    console.log = function () {};
    console.warn = function () {};
    console.error = function () {};
  }

  /* ========================================
     11. APPLICATION SYSTEM
     ======================================== */

  // Opportunity Details Logic
  const oppTitleElement = document.getElementById("oppTitle");
  if (oppTitleElement) {
    fetchOpportunityDetails();
  }

  async function fetchOpportunityDetails() {
    const params = new URLSearchParams(window.location.search);
    const oppId = params.get("id");

    if (!oppId) return;

    try {
      const response = await fetch(
        `http://localhost:5000/api/opportunities/${oppId}`
      );
      const opportunity = await response.json();

      if (response.ok) {
        // Populate fields
        document.getElementById("oppTitle").textContent = opportunity.title;
        document.getElementById("oppDescriptionHero").textContent =
          opportunity.description.substring(0, 150) + "...";
        document.getElementById("oppCategory").textContent =
          opportunity.category;
        document.getElementById("oppStatus").textContent =
          opportunity.status === "active" ? "Active" : "Closed";
        document.getElementById("oppLocation").textContent =
          opportunity.location;
        document.getElementById("oppDuration").textContent = "3 Months"; // Hardcoded for simplified demo or fetch from data if available
        document.getElementById(
          "oppVolunteers"
        ).textContent = `${opportunity.volunteersNeeded} volunteers needed`;

        // Set hidden input for application
        const appOppId = document.getElementById("appOpportunityId");
        if (appOppId) appOppId.value = opportunity._id;
      } else {
        alert("Failed to load opportunity details");
      }
    } catch (err) {
      console.error(err);
    }
  }

  // Application Form Submission
  const applicationForm = document.getElementById("applicationForm");
  if (applicationForm) {
    applicationForm.addEventListener("submit", async function (e) {
      e.preventDefault();

      const submitBtn = this.querySelector('button[type="submit"]');
      const originalText = submitBtn.textContent;
      submitBtn.disabled = true;
      submitBtn.textContent = "Submitting...";

      const formData = {
        opportunityId: document.getElementById("appOpportunityId").value,
        message: document.getElementById("appMotivation").value,
      };

      try {
        const token = localStorage.getItem("token");
        if (!token) throw new Error("You must be logged in to apply");

        const response = await fetch("http://localhost:5000/api/applications", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-auth-token": token,
          },
          body: JSON.stringify(formData),
        });

        const data = await response.json();

        if (response.ok) {
          alert("Application submitted successfully!");
          // Close modal if Bootstrap is available
          if (typeof bootstrap !== "undefined") {
            const modal = document.getElementById("applicationModal");
            if (modal) {
              const bsModal = bootstrap.Modal.getInstance(modal);
              if (bsModal) bsModal.hide();
            }
          }
          this.reset();
        } else {
          throw new Error(data.message || "Application failed");
        }
      } catch (err) {
        alert(err.message);
      } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = originalText;
      }
    });
  }

  // Organization Dashboard: Recent Applications
  const recentApplicationsList = document.getElementById(
    "recentApplicationsList"
  );
  if (recentApplicationsList) {
    fetchOrganizationApplications();
  }

  async function fetchOrganizationApplications() {
    try {
      const token = localStorage.getItem("token");
      if (!token) return;

      const response = await fetch(
        "http://localhost:5000/api/applications/organization",
        {
          headers: { "x-auth-token": token },
        }
      );
      const applications = await response.json();

      recentApplicationsList.innerHTML = "";

      if (applications.length > 0) {
        applications.forEach((app) => {
          recentApplicationsList.innerHTML += `
              <div class="applicant-card mb-3 p-3 border rounded">
                <div class="row align-items-center">
                  <div class="col-md-2">
                     <i class="fas fa-user-circle fa-2x text-muted"></i>
                  </div>
                  <div class="col-md-4">
                    <h6 class="mb-1">${
                      app.volunteerId ? app.volunteerId.name : "Unknown User"
                    }</h6>
                    <small class="text-muted">${
                      app.opportunityId
                        ? app.opportunityId.title
                        : "Unknown Opportunity"
                    }</small>
                  </div>
                  <div class="col-md-3">
                    <small class="text-muted">Applied: ${new Date(
                      app.appliedAt
                    ).toLocaleDateString()}</small>
                  </div>
                  <div class="col-md-3 text-end">
                    ${
                      app.status === "pending"
                        ? `
                    <div class="d-flex gap-2 justify-content-end">
                      <button class="btn btn-sm btn-success" onclick="updateAppStatus('${app._id}', 'accepted')">Accept</button>
                      <button class="btn btn-sm btn-outline-danger" onclick="updateAppStatus('${app._id}', 'rejected')">Reject</button>
                    </div>`
                        : `
                    <span class="badge bg-${
                      app.status === "accepted" ? "success" : "danger"
                    }">${app.status.toUpperCase()}</span>
                    `
                    }
                  </div>
                </div>
              </div>
          `;
        });
      } else {
        recentApplicationsList.innerHTML =
          '<p class="text-center text-muted">No applications received yet.</p>';
      }
    } catch (err) {
      console.error(err);
      recentApplicationsList.innerHTML =
        '<p class="text-danger text-center">Error loading applications.</p>';
    }
  }

  window.updateAppStatus = async function (appId, status) {
    if (!confirm(`Are you sure you want to ${status} this application?`))
      return;

    try {
      const token = localStorage.getItem("token");
      const response = await fetch(
        `http://localhost:5000/api/applications/${appId}/status`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            "x-auth-token": token,
          },
          body: JSON.stringify({ status }),
        }
      );

      if (response.ok) {
        fetchOrganizationApplications(); // Refresh list
      } else {
        alert("Failed to update status");
      }
    } catch (err) {
      alert("Error updating status");
    }
  };

  // Volunteer Dashboard: My Applications
  const volunteerApplicationsList = document.getElementById(
    "volunteerApplicationsList"
  );
  if (volunteerApplicationsList) {
    fetchVolunteerApplications();
  }

  async function fetchVolunteerApplications() {
    try {
      const token = localStorage.getItem("token");
      if (!token) return;

      const response = await fetch(
        "http://localhost:5000/api/applications/volunteer",
        {
          headers: { "x-auth-token": token },
        }
      );
      const applications = await response.json();

      volunteerApplicationsList.innerHTML = "";

      if (applications.length > 0) {
        applications.forEach((app) => {
          let statusBadgeClass = "bg-secondary";
          if (app.status === "accepted") statusBadgeClass = "bg-success";
          else if (app.status === "rejected") statusBadgeClass = "bg-danger";
          else if (app.status === "pending")
            statusBadgeClass = "bg-warning text-dark";

          volunteerApplicationsList.innerHTML += `
              <div class="application-card mb-3 p-3 border rounded">
                <div class="row align-items-center">
                  <div class="col-md-2">
                    <img src="../assets/images/volunteer.jpg" alt="NGO" class="rounded ngo-logo" style="width:50px; height:50px; object-fit:cover;">
                  </div>
                  <div class="col-md-6">
                    <h6 class="mb-1">${
                      app.opportunityId
                        ? app.opportunityId.title
                        : "Unknown Opportunity"
                    }</h6>
                    <small class="text-muted">${
                      app.organizationId
                        ? app.organizationId.name
                        : "Unknown Org"
                    }</small>
                  </div>
                  <div class="col-md-2">
                    <span class="badge ${statusBadgeClass}">${app.status.toUpperCase()}</span>
                  </div>
                  <div class="col-md-2 text-end">
                    <small class="text-muted">${new Date(
                      app.appliedAt
                    ).toLocaleDateString()}</small>
                  </div>
                </div>
              </div>
          `;
        });
      } else {
        volunteerApplicationsList.innerHTML =
          '<p class="text-center text-muted">You haven\'t applied to any opportunities yet.</p>';
      }
    } catch (err) {
      console.error(err);
      volunteerApplicationsList.innerHTML =
        '<p class="text-danger text-center">Error loading applications.</p>';
    }
  }
  /* ========================================
     12. MY APPLICATIONS & PROFILE
     ======================================== */

  // My Applications Table (my-applications.html)
  const myApplicationsTableBody = document.getElementById(
    "myApplicationsTableBody"
  );
  if (myApplicationsTableBody) {
    fetchMyApplicationsTable();
  }

  async function fetchMyApplicationsTable() {
    try {
      const token = localStorage.getItem("token");
      if (!token) return;

      const response = await fetch(
        "http://localhost:5000/api/applications/volunteer",
        {
          headers: { "x-auth-token": token },
        }
      );
      const applications = await response.json();

      myApplicationsTableBody.innerHTML = "";

      if (applications.length > 0) {
        applications.forEach((app) => {
          let statusBadgeClass = "bg-secondary";
          if (app.status === "accepted") statusBadgeClass = "bg-success";
          else if (app.status === "rejected") statusBadgeClass = "bg-danger";
          else if (app.status === "pending")
            statusBadgeClass = "bg-warning text-dark";

          let withdrawBtn = "";
          if (app.status === "pending") {
            withdrawBtn = `<button class="btn btn-sm btn-outline-danger" onclick="withdrawApp('${app._id}')">Withdraw</button>`;
          } else {
            withdrawBtn = `<button class="btn btn-sm btn-outline-danger" disabled>Withdraw</button>`;
          }

          myApplicationsTableBody.innerHTML += `
              <tr>
                <td>${
                  app.opportunityId ? app.opportunityId.title : "Unknown"
                }</td>
                <td>${
                  app.organizationId ? app.organizationId.name : "Unknown"
                }</td>
                <td>${new Date(app.appliedAt).toLocaleDateString()}</td>
                <td><span class="badge ${statusBadgeClass}">${app.status.toUpperCase()}</span></td>
                <td>${withdrawBtn}</td>
              </tr>
          `;
        });
      } else {
        myApplicationsTableBody.innerHTML =
          '<tr><td colspan="5" class="text-center">No applications found.</td></tr>';
      }
    } catch (err) {
      console.error(err);
      myApplicationsTableBody.innerHTML =
        '<tr><td colspan="5" class="text-center text-danger">Error loading applications.</td></tr>';
    }
  }

  window.withdrawApp = async function (appId) {
    if (!confirm("Are you sure you want to withdraw this application?")) return;

    try {
      const token = localStorage.getItem("token");
      const response = await fetch(
        `http://localhost:5000/api/applications/${appId}`,
        {
          method: "DELETE",
          headers: { "x-auth-token": token },
        }
      );

      if (response.ok) {
        alert("Application withdrawn successfully");
        fetchMyApplicationsTable();
      } else {
        const data = await response.json();
        alert(data.message || "Failed to withdraw");
      }
    } catch (err) {
      console.error(err);
      alert("Error withdrawing application");
    }
  };

  // Profile Settings (profile-settings.html)
  const profileSettingsForm = document.getElementById("profileSettingsForm");
  if (profileSettingsForm) {
    fetchUserProfile();

    profileSettingsForm.addEventListener("submit", async function (e) {
      e.preventDefault();
      updateUserProfile();
    });
  }

  async function fetchUserProfile() {
    try {
      const token = localStorage.getItem("token");
      if (!token) return;

      const response = await fetch("http://localhost:5000/api/users/profile", {
        headers: { "x-auth-token": token },
      });
      const user = await response.json();

      if (response.ok) {
        if (document.getElementById("fullName"))
          document.getElementById("fullName").value = user.name || "";
        if (document.getElementById("email"))
          document.getElementById("email").value = user.email || "";
        if (document.getElementById("phone"))
          document.getElementById("phone").value = user.phone || "";
        if (document.getElementById("bio"))
          document.getElementById("bio").value = user.bio || "";

        // Handle location select
        const locSelect = document.getElementById("location");
        if (locSelect && user.location) {
          locSelect.value = user.location;
        }

        if (user.skills && document.getElementById("skills")) {
          document.getElementById("skills").value = user.skills.join(", ");
        }
      }
    } catch (err) {
      console.error("Error fetching profile:", err);
    }
  }

  async function updateUserProfile() {
    const submitBtn = profileSettingsForm.querySelector(
      'button[type="submit"]'
    );
    const originalText = submitBtn.textContent;
    submitBtn.disabled = true;
    submitBtn.textContent = "Saving...";

    let skillsArray = [];
    const skillsInput = document.getElementById("skills");
    if (skillsInput) {
      skillsArray = skillsInput.value
        .split(",")
        .map((s) => s.trim())
        .filter((s) => s);
    }

    const updateData = {
      name: document.getElementById("fullName")
        ? document.getElementById("fullName").value
        : "",
      phone: document.getElementById("phone")
        ? document.getElementById("phone").value
        : "",
      location: document.getElementById("location")
        ? document.getElementById("location").value
        : "",
      bio: document.getElementById("bio")
        ? document.getElementById("bio").value
        : "",
      skills: skillsArray,
      // Add verification fields
      idNumber: document.getElementById("idNumber")
        ? document.getElementById("idNumber").value
        : "",
      detailedBio: document.getElementById("detailedBio")
        ? document.getElementById("detailedBio").value
        : "",
    };

    try {
      const token = localStorage.getItem("token");

      // 1. Update Profile Data (JSON)
      const response = await fetch("http://localhost:5000/api/users/profile", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "x-auth-token": token,
        },
        body: JSON.stringify(updateData),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Update failed");
      }

      // 2. Upload Documents (if any)
      const docInput = document.getElementById("documentUpload");
      if (docInput && docInput.files.length > 0) {
        const formData = new FormData();
        for (let i = 0; i < docInput.files.length; i++) {
          formData.append("documents", docInput.files[i]);
        }

        const docResponse = await fetch(
          "http://localhost:5000/api/users/upload-documents",
          {
            method: "POST",
            headers: { "x-auth-token": token },
            body: formData,
          }
        );

        if (!docResponse.ok) {
          const docData = await docResponse.json();
          alert(
            "Profile saved, but document upload failed: " + docData.message
          );
        } else {
          // Refresh user data to get document URLs
          const newUserData = await docResponse.json();
          // Merge/Update local storage if needed, but page reload/alert is enough
        }
      }

      alert("Profile updated successfully");
      localStorage.setItem("user", JSON.stringify(data.user));
      // (End of updateUserProfile)
    } catch (err) {
      console.error(err);
      alert("Network error");
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = originalText;
    }
  }
  // Organization Profile (organization-profile.html)
  const orgProfileForm = document.getElementById("orgProfileForm");
  if (orgProfileForm) {
    fetchOrgProfile();

    orgProfileForm.addEventListener("submit", async function (e) {
      e.preventDefault();
      updateOrgProfile();
    });
  }

  async function fetchOrgProfile() {
    try {
      const token = localStorage.getItem("token");
      if (!token) return;

      const response = await fetch("http://localhost:5000/api/users/profile", {
        headers: { "x-auth-token": token },
      });
      const user = await response.json();

      if (response.ok) {
        if (document.getElementById("orgName"))
          document.getElementById("orgName").value = user.name || "";
        if (document.getElementById("orgEmail"))
          document.getElementById("orgEmail").value = user.email || "";
        if (document.getElementById("orgPhone"))
          document.getElementById("orgPhone").value = user.phone || "";
        if (document.getElementById("orgWebsite"))
          document.getElementById("orgWebsite").value = user.website || "";

        // Handle description (support both top-level and legacy nested)
        if (document.getElementById("orgDescription")) {
          document.getElementById("orgDescription").value =
            user.description ||
            (user.organizationInfo && user.organizationInfo.description) ||
            "";
        }

        const locSelect = document.getElementById("orgLocation");
        if (locSelect && user.location) {
          locSelect.value = user.location;
        }

        // Handle Established Year
        if (document.getElementById("orgEstablished") && user.established) {
          document.getElementById("orgEstablished").value = user.established;
        }
      }
    } catch (err) {
      console.error("Error fetching org profile:", err);
    }
  }

  async function updateOrgProfile() {
    const submitBtn = orgProfileForm.querySelector('button[type="submit"]');
    // const originalText = submitBtn.textContent; // Removed to avoid lint error if unused, or keep if needed
    submitBtn.disabled = true;
    submitBtn.textContent = "Saving...";

    const updateData = {
      name: document.getElementById("orgName").value,
      phone: document.getElementById("orgPhone").value,
      location: document.getElementById("orgLocation").value,
      website: document.getElementById("orgWebsite").value,
      description: document.getElementById("orgDescription").value,
      established: document.getElementById("orgEstablished").value,
    };

    try {
      const token = localStorage.getItem("token");
      const response = await fetch("http://localhost:5000/api/users/profile", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "x-auth-token": token,
        },
        body: JSON.stringify(updateData),
      });

      const data = await response.json();

      if (response.ok) {
        alert("Organization Profile updated successfully");
        if (document.getElementById("sidebarOrgName")) {
          document.getElementById("sidebarOrgName").textContent =
            data.user.name;
        }
        localStorage.setItem("user", JSON.stringify(data.user));
      } else {
        alert(data.message || "Update failed");
      }
    } catch (err) {
      console.error(err);
      alert("Network error");
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = originalText;
    }
  }
});

/* ========================================
   PVS YOUTHFORCE - CONSOLIDATED JAVASCRIPT
   ======================================== */

// Make functions available globally for debugging
window.debugApp = {
  log: function (msg, data) {
    console.log(
      `[PVS-DEBUG] ${msg} | Timestamp: ${new Date().toISOString()}`,
      data || ""
    );
  },
};

document.addEventListener("DOMContentLoaded", async function () {
  const currentPath = window.location.pathname;
  const token = localStorage.getItem("token");

  window.debugApp.log("App Initialized", { currentPath, hasToken: !!token });

  /* ========================================
     AUTHENTICATION GUARDS
     ======================================== */
  if (currentPath.includes("/auth/") && !token) {
    window.debugApp.log("No token, redirecting to login");
    window.location.href = "../login.html";
    return;
  }

  /* ========================================
     ROUTING LOGIC
     ======================================== */

  // 1. Profile Data Loading (Sidebar, Header, Profile Settings)
  // Run this on ALL auth pages to ensure sidebar/header is correct
  if (currentPath.includes("/auth/")) {
    await loadProfileVerificationData();
  }

  // 2. Specific Page Logic
  if (currentPath.includes("dashboard.html")) {
    window.debugApp.log("Running Dashboard Logic");
    loadDashboardOpportunities();
  } else if (currentPath.includes("add-qualification.html")) {
    window.debugApp.log("Running Add Qualification Logic");
    setupAddQualificationPage();
  } else if (currentPath.includes("my-applications.html")) {
    // any specific logic for applications
  }

  /* ========================================
     FUNCTIONS
     ======================================== */

  async function loadProfileVerificationData() {
    try {
      window.debugApp.log("Fetching Profile Data");
      const res = await fetch("http://localhost:5000/api/users/profile", {
        headers: { "x-auth-token": token },
      });

      if (!res.ok)
        throw new Error(`Failed to fetch profile: ${res.statusText}`);

      const user = await res.json();
      window.debugApp.log("User Data Received", user);

      // sidebarName
      const sidebarName = document.getElementById("sidebarName");
      const sidebarOrgName = document.getElementById("sidebarOrgName");

      if (sidebarName) {
        sidebarName.textContent = user.name || "Volunteer";
        window.debugApp.log("Updated sidebarName", sidebarName.textContent);
      }
      if (sidebarOrgName)
        sidebarOrgName.textContent = user.name || "Organization";

      // welcomeName (Dashboard)
      const welcomeName = document.getElementById("welcomeName");
      if (welcomeName) {
        welcomeName.textContent = user.name || "Volunteer";
        window.debugApp.log("Updated welcomeName", welcomeName.textContent);
      } else {
        window.debugApp.log("welcomeName element NOT found in DOM");
      }

      // Profile Picture
      if (user.profilePicture) {
        const timestamp = new Date().getTime();
        const imageUrl = `http://localhost:5000${user.profilePicture}?t=${timestamp}`;
        document.querySelectorAll(".profile-avatar").forEach((img) => {
          img.src = imageUrl;
        });
      }

      // Verification Status (Profile Settings)
      const statusBadge = document.getElementById("verificationStatusBadge");
      const alertContainer = document.getElementById("verificationAlert");

      if (statusBadge && user.verificationStatus) {
        // ... existing verification logic ...
        statusBadge.className = `badge bg-${getBadgeColor(
          user.verificationStatus
        )}`;
        statusBadge.textContent =
          user.verificationStatus.charAt(0).toUpperCase() +
          user.verificationStatus.slice(1);
      }

      // Pre-fill form if on profile settings
      const profileForm = document.getElementById("profileSettingsForm");
      if (profileForm) {
        document.getElementById("fullName").value = user.name || "";
        document.getElementById("email").value = user.email || "";
        document.getElementById("phone").value = user.phone || "";
        document.getElementById("location").value = user.location || "";
        document.getElementById("bio").value = user.bio || "";
        // ... populate other fields if needed
      }
    } catch (err) {
      console.error("Error loading profile:", err);
    }
  }

  async function loadDashboardOpportunities() {
    try {
      const listContainer = document.getElementById(
        "dashboardOpportunitiesList"
      );
      if (!listContainer) {
        window.debugApp.log("dashboardOpportunitiesList container NOT found");
        return;
      }

      listContainer.innerHTML =
        '<div class="text-center text-muted"><i class="fas fa-spinner fa-spin me-2"></i>Loading opportunities...</div>';

      const res = await fetch("http://localhost:5000/api/opportunities");
      if (!res.ok) throw new Error("Failed to fetch opportunities");

      const data = await res.json();
      window.debugApp.log("Opportunities loaded", data);

      const opportunities = data.opportunities || []; // Extract from data object

      if (opportunities.length === 0) {
        listContainer.innerHTML =
          '<div class="text-center text-muted">No opportunities available.</div>';
        return;
      }

      const recent = opportunities.slice(0, 3);
      listContainer.innerHTML = recent
        .map(
          (opp) => `
          <div class="d-flex align-items-center border-bottom py-3">
             <div class="flex-grow-1">
                <h6 class="mb-1 fw-bold text-dark">${
                  opp.title || "Untitled"
                }</h6>
                <small class="text-muted d-block mb-1"><i class="fas fa-building me-1"></i>${
                  opp.organization?.name || "Organization"
                }</small>
                <div>
                   <span class="badge bg-light text-dark border me-1">${
                     opp.category || "General"
                   }</span>
                   <small class="text-muted"><i class="fas fa-map-marker-alt me-1"></i>${
                     opp.location || "Remote"
                   }</small>
                </div>
             </div>
             <a href="../opportunity-details.html?id=${
               opp._id
             }" class="btn btn-sm btn-outline-primary ms-2">View</a>
          </div>
      `
        )
        .join("");
    } catch (err) {
      console.error("Error loading dashboard opportunities:", err);
      const listContainer = document.getElementById(
        "dashboardOpportunitiesList"
      );
      if (listContainer)
        listContainer.innerHTML =
          '<div class="text-center text-danger small">Unable to load opportunities.</div>';
    }
  }

  // === Dashboard Saved Opportunities ===
  if (currentPath.includes("dashboard.html")) {
    loadSavedOpportunities();
  }

  async function loadSavedOpportunities() {
    const listContainer = document.getElementById("savedOpportunitiesList");
    if (!listContainer) return;

    try {
      const token = localStorage.getItem("token");
      const res = await fetch(
        "http://localhost:5000/api/opportunities/user/saved",
        {
          headers: { "x-auth-token": token },
        }
      );

      if (!res.ok) throw new Error("Failed to load saved opportunities");
      const saved = await res.json();

      if (saved.length === 0) {
        listContainer.innerHTML =
          '<div class="text-center text-muted small py-3">No saved opportunities yet.</div>';
        return;
      }

      listContainer.innerHTML = saved
        .map(
          (opp) => `
            <div class="d-flex justify-content-between align-items-center border-bottom py-2">
                <div style="min-width: 0;">
                    <h6 class="mb-0 text-truncate" title="${opp.title}">${
            opp.title
          }</h6>
                    <small class="text-muted text-truncate d-block">${
                      opp.organizationId?.name || "Organization"
                    }</small>
                </div>
                <div class="ms-2 d-flex align-items-center">
                    <a href="../opportunity-details.html?id=${
                      opp._id
                    }" class="btn btn-xs btn-outline-primary me-1" style="padding: 0.15rem 0.4rem; font-size: 0.75rem;">View</a>
                    <button onclick="unsaveOpportunity('${
                      opp._id
                    }')" class="btn btn-xs btn-outline-danger" style="padding: 0.15rem 0.4rem; font-size: 0.75rem;"><i class="fas fa-times"></i></button>
                </div>
            </div>
        `
        )
        .join("");
    } catch (err) {
      console.error(err);
      listContainer.innerHTML =
        '<div class="text-center text-danger small">Error loading saved items.</div>';
    }
  }

  // Make unsave globally available
  window.unsaveOpportunity = async function (id) {
    if (!confirm("Remove from saved?")) return;
    try {
      const token = localStorage.getItem("token");
      const res = await fetch(
        `http://localhost:5000/api/opportunities/${id}/save`,
        {
          method: "DELETE",
          headers: { "x-auth-token": token },
        }
      );
      if (res.ok) {
        loadSavedOpportunities(); // Reload list
      } else {
        alert("Failed to remove");
      }
    } catch (e) {
      console.error(e);
    }
  };

  function setupAddQualificationPage() {
    // Load existing qualifications
    loadQualifications();

    const form = document.getElementById("qualificationForm");
    if (form) {
      form.removeEventListener("submit", handleQualificationSubmit); // Prevent duplicate listeners
      form.addEventListener("submit", handleQualificationSubmit);
    }
  }

  async function handleQualificationSubmit(e) {
    e.preventDefault();
    const submitBtn = this.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.disabled = true;
    submitBtn.innerHTML =
      '<i class="fas fa-spinner fa-spin me-2"></i>Adding...';

    try {
      const formData = new FormData();
      // ... gather fields ...
      const fields = [
        { id: "qualificationType", key: "type" },
        { id: "university", key: "university" },
        { id: "marks", key: "marks" },
        { id: "grade", key: "grade" },
        { id: "completionYear", key: "completionYear" },
      ];

      fields.forEach((field) => {
        const element = document.getElementById(field.id);
        if (element) {
          formData.append(field.key, element.value);
        }
      });

      const fileInput = document.getElementById("qualificationDocument");
      if (fileInput.files.length > 0) {
        formData.append("document", fileInput.files[0]); // matches upload.single('document')
      }

      const token = localStorage.getItem("token");
      const isUpdate = document.getElementById("qualificationId").value !== "";
      const url = isUpdate
        ? `http://localhost:5000/api/users/qualifications/${
            document.getElementById("qualificationId").value
          }`
        : "http://localhost:5000/api/users/qualifications";

      const method = isUpdate ? "PUT" : "POST";

      const res = await fetch(url, {
        method: method,
        headers: { "x-auth-token": token },
        body: formData,
      });

      if (res.ok) {
        alert(
          isUpdate
            ? "Qualification updated!"
            : "Qualification added successfully!"
        );
        this.reset();
        document.getElementById("qualificationId").value = ""; // Clear ID
        document.getElementById("formSubmitBtn").innerHTML =
          '<i class="fas fa-plus me-2"></i>Add Qualification'; // Reset text
        document.getElementById("cancelEditBtn").style.display = "none";
        loadQualifications(); // Reload list
      } else {
        const data = await res.json();
        alert(data.message || "Failed to save qualification");
      }
    } catch (err) {
      console.error(err);
      alert("An error occurred while saving qualification.");
    } finally {
      submitBtn.disabled = false;
      submitBtn.innerHTML = originalText;
    }
  }

  // Cancel Edit Handler
  const cancelBtn = document.getElementById("cancelEditBtn");
  if (cancelBtn) {
    cancelBtn.addEventListener("click", function () {
      document.getElementById("qualificationForm").reset();
      document.getElementById("qualificationId").value = "";
      document.getElementById("formSubmitBtn").innerHTML =
        '<i class="fas fa-plus me-2"></i>Add Qualification';
      this.style.display = "none";
    });
  }

  window.deleteQualification = async function (id) {
    if (!confirm("Are you sure you want to delete this qualification?")) return;
    try {
      const token = localStorage.getItem("token");
      const res = await fetch(
        `http://localhost:5000/api/users/qualifications/${id}`,
        {
          method: "DELETE",
          headers: { "x-auth-token": token },
        }
      );
      if (res.ok) {
        loadQualifications();
        alert("Deleted successfully");
      } else {
        alert("Failed to delete");
      }
    } catch (err) {
      console.error(err);
    }
  };

  window.editQualification = function (id, type, uni, marks, grade, year) {
    document.getElementById("qualificationId").value = id;
    document.getElementById("qualificationType").value = type;
    document.getElementById("university").value = uni;
    document.getElementById("marks").value = marks;
    document.getElementById("grade").value = grade || "";
    document.getElementById("completionYear").value = year;

    document.getElementById("formSubmitBtn").innerHTML =
      '<i class="fas fa-save me-2"></i>Update Qualification';
    document.getElementById("cancelEditBtn").style.display = "inline-block";

    // Scroll to form
    document
      .getElementById("qualificationForm")
      .scrollIntoView({ behavior: "smooth" });
  };

  async function loadQualifications() {
    const list = document.getElementById("qualificationsList");
    if (!list) return;

    try {
      const token = localStorage.getItem("token");
      const res = await fetch("http://localhost:5000/api/users/profile", {
        headers: { "x-auth-token": token },
      });
      const user = await res.json();

      if (user.qualifications && user.qualifications.length > 0) {
        list.innerHTML = user.qualifications
          .map(
            (qual) => `
            <div class="d-flex justify-content-between align-items-center border-bottom py-3">
               <div>
                  <h6 class="mb-1 text-primary text-capitalize fw-bold">${
                    qual.type
                  } <span class="text-dark fw-normal">- ${
              qual.university
            }</span></h6>
                  <div class="small text-muted">
                    <span class="me-3"><i class="fas fa-calendar me-1"></i>${
                      qual.completionYear
                    }</span>
                    <span class="me-3"><i class="fas fa-chart-line me-1"></i>${
                      qual.marks
                    }%</span>
                    ${
                      qual.grade
                        ? `<span class="me-3"><i class="fas fa-award me-1"></i>Grade: ${qual.grade}</span>`
                        : ""
                    }
                  </div>
                  ${
                    qual.documentUrl
                      ? `<a href="http://localhost:5000${qual.documentUrl}" target="_blank" class="small text-decoration-none mt-1 d-inline-block text-primary"><i class="fas fa-paperclip me-1"></i>View Document</a>`
                      : ""
                  }
               </div>
               <div>
                  <button class="btn btn-sm btn-outline-primary me-1" onclick="editQualification('${
                    qual._id
                  }', '${qual.type}', '${qual.university}', '${qual.marks}', '${
              qual.grade || ""
            }', '${qual.completionYear}')">
                    <i class="fas fa-edit"></i>
                  </button>
                  <button class="btn btn-sm btn-outline-danger" onclick="deleteQualification('${
                    qual._id
                  }')">
                    <i class="fas fa-trash"></i>
                  </button>
               </div>
            </div>
          `
          )
          .join("");
      } else {
        list.innerHTML =
          '<div class="text-center text-muted py-3">No qualifications added yet.</div>';
      }
    } catch (err) {
      console.error(err);
      list.innerHTML =
        '<div class="text-danger small">Failed to load qualifications.</div>';
    }
  }

  function getBadgeColor(status) {
    if (status === "approved") return "success";
    if (status === "rejected") return "danger";
    return "warning";
  }
});

/* ========================================
   10. GLOBAL HELPER FUNCTIONS
   ======================================== */

// Format date helper
function formatDate(date) {
  const options = { year: "numeric", month: "short", day: "numeric" };
  return new Date(date).toLocaleDateString("en-US", options);
}

// Validate email helper
function validateEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

// Validate phone helper
function validatePhone(phone) {
  const re = /^03\d{2}-?\d{7}$/;
  return re.test(phone);
}

// ==========================================
// 12. ORGANIZATION MANAGE OPPORTUNITIES
// ==========================================
// Router
if (
  window.location.pathname.includes("manage-opportunities.html") &&
  !window.location.pathname.includes("admin-")
) {
  document.addEventListener("DOMContentLoaded", loadOrgOpportunities);
}

async function loadOrgOpportunities() {
  const tableBody = document.getElementById("orgOpportunitiesTableBody");
  if (!tableBody) return; // specific to org view

  // Get current user to find orgId (stored in localStorage usually)
  const userStr = localStorage.getItem("user");
  if (!userStr) return;
  const user = JSON.parse(userStr);
  const orgId = user.id || user._id; // Handle both cases

  tableBody.innerHTML =
    '<tr><td colspan="5" class="text-center py-4"><div class="spinner-border text-primary"></div></td></tr>';

  try {
    const token = localStorage.getItem("token");
    // We use the public endpoint if orgId is known, OR a specific "my-opportunities" endpoint?
    // Let's use getOrganizationOpportunities controller: /api/opportunities/organization/:orgId
    const response = await fetch(
      `http://localhost:5000/api/opportunities/organization/${orgId}`,
      {
        headers: { "x-auth-token": token },
      }
    );

    if (!response.ok) throw new Error("Failed to fetch");

    const opportunities = await response.json();

    if (opportunities.length === 0) {
      tableBody.innerHTML =
        '<tr><td colspan="5" class="text-center">No opportunities posted yet.</td></tr>';
      return;
    }

    tableBody.innerHTML = opportunities
      .map((opp) => {
        // Admin Feedback: Comment + Lock Status
        let feedbackHtml = '<span class="text-muted small">No feedback</span>';
        if (opp.adminComments) {
          feedbackHtml = `<div class="text-warning small"><i class="fas fa-comment me-1"></i>${opp.adminComments}</div>`;
        }
        if (opp.isLockedByAdmin) {
          feedbackHtml += `<div class="text-danger small fw-bold mt-1"><i class="fas fa-lock me-1"></i>LOCKED</div>`;
        }
        if (opp.status === "rejected") {
          feedbackHtml =
            `<div class="text-danger small"><i class="fas fa-exclamation-circle me-1"></i>Rejected</div>` +
            feedbackHtml;
        }

        // Actions: Disable if Locked
        const isLocked = opp.isLockedByAdmin;
        const editBtn = `<a href="post-opportunity.html?edit=${
          opp._id
        }" class="btn btn-sm btn-outline-primary me-1 ${
          isLocked ? "disabled" : ""
        }" title="Edit"><i class="fas fa-edit"></i></a>`;
        const deleteBtn = `<button class="btn btn-sm btn-outline-danger" onclick="deleteOrgPost('${
          opp._id
        }')" ${
          isLocked ? "disabled" : ""
        } title="Delete"><i class="fas fa-trash"></i></button>`;

        return `
            <tr>
                <td>
                    <div class="fw-bold">${opp.title}</div>
                    <small class="text-muted"><i class="fas fa-map-marker-alt me-1"></i>${
                      opp.location
                    }</small>
                </td>
                <td>${new Date(opp.createdAt).toLocaleDateString()}</td>
                <td>
                    <span class="badge ${getStatusBadgeClass(
                      opp.status
                    )}">${opp.status.toUpperCase()}</span>
                </td>
                <td>
                    ${feedbackHtml}
                </td>
                <td>
                    ${editBtn}
                    ${deleteBtn}
                </td>
            </tr>
        `;
      })
      .join("");
  } catch (err) {
    console.error(err);
    tableBody.innerHTML =
      '<tr><td colspan="5" class="text-center text-danger">Error loading data.</td></tr>';
  }
}

// Reuse getStatusBadgeClass from admin.js or define it here if not polluting global scope differently
function getStatusBadgeClass(status) {
  switch (status) {
    case "active":
      return "bg-success";
    case "approved":
      return "bg-success";
    case "accepted":
      return "bg-success";
    case "completed":
      return "bg-primary";
    case "pending":
      return "bg-warning text-dark";
    case "draft":
      return "bg-secondary";
    case "inactive":
      return "bg-secondary";
    case "rejected":
      return "bg-danger";
    case "changes_requested":
      return "bg-info text-dark";
    default:
      return "bg-secondary";
  }
}

window.deleteOrgPost = async function (id) {
  if (!confirm("Are you sure you want to delete this post?")) return;

  try {
    const token = localStorage.getItem("token");
    const response = await fetch(
      `http://localhost:5000/api/opportunities/${id}`,
      {
        method: "DELETE",
        headers: { "x-auth-token": token },
      }
    );

    if (response.ok) {
      alert("Post deleted");
      loadOrgOpportunities();
    } else {
      const data = await response.json();
      alert(data.message || "Delete failed");
    }
  } catch (err) {
    console.error(err);
    alert("Server error");
  }
};
