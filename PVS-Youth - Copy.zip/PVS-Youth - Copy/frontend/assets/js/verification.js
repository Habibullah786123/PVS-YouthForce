document.addEventListener("DOMContentLoaded", async () => {
  const token = localStorage.getItem("token");
  if (!token) {
    window.location.href = "../login.html";
    return;
  }

  const user = JSON.parse(localStorage.getItem("user") || "{}");
  document.getElementById("userName").textContent = user.name || "User";

  // Role specific fields
  if (user.role === "organization") {
    document.getElementById("orgFields").classList.remove("d-none");
  } else {
    document.getElementById("volFields").classList.remove("d-none");
  }

  // Fetch Profile Data
  try {
    const res = await fetch("http://localhost:5000/api/users/profile/me", {
      headers: { "x-auth-token": token },
    });
    const currentUser = await res.json();

    // Update UI based on status
    const statusBadge = document.getElementById("statusBadge");
    if (currentUser.verificationStatus === "approved") {
      statusBadge.className = "badge bg-success";
      statusBadge.textContent = "Approved";
      document.getElementById("verificationForm").innerHTML =
        '<div class="text-center py-5"><i class="fas fa-check-circle text-success fa-3x mb-3"></i><h5>Your account is verified!</h5><a href="dashboard.html" class="btn btn-primary mt-3">Go to Dashboard</a></div>';
      return;
    } else if (currentUser.verificationStatus === "pending") {
      statusBadge.className = "badge bg-warning text-dark";
      statusBadge.textContent = "Pending Review";
    } else if (
      currentUser.verificationStatus === "changes_requested" ||
      currentUser.verificationStatus === "rejected"
    ) {
      statusBadge.className = "badge bg-danger";
      statusBadge.textContent = currentUser.verificationStatus
        .replace("_", " ")
        .toUpperCase();
    }

    // Show comments
    if (currentUser.adminComments && currentUser.adminComments.length > 0) {
      const list = document.getElementById("adminCommentsList");
      document
        .getElementById("adminCommentsSection")
        .classList.remove("d-none");
      currentUser.adminComments.forEach((c) => {
        const li = document.createElement("li");
        li.innerHTML = `<small class="text-muted">${new Date(
          c.date
        ).toLocaleDateString()}</small>: ${c.comment}`;
        list.appendChild(li);
      });
    }

    // Pre-fill fields
    if (currentUser.profileDetails) {
      if (currentUser.profileDetails.idNumber)
        document.getElementById("idNumber").value =
          currentUser.profileDetails.idNumber;
      if (currentUser.profileDetails.missionStatement)
        document.getElementById("missionStatement").value =
          currentUser.profileDetails.missionStatement;
      if (currentUser.profileDetails.detailedBio)
        document.getElementById("detailedBio").value =
          currentUser.profileDetails.detailedBio;
    }
  } catch (err) {
    console.error(err);
  }

  // Handle Form Submit
  document
    .getElementById("verificationForm")
    .addEventListener("submit", async (e) => {
      e.preventDefault();

      const btn = document.getElementById("submitVerificationBtn");
      const originalText = btn.innerHTML;
      btn.disabled = true;
      btn.innerHTML = "Uploading...";

      const formData = new FormData();
      formData.append("idNumber", document.getElementById("idNumber").value);

      if (user.role === "organization") {
        formData.append(
          "missionStatement",
          document.getElementById("missionStatement").value
        );
      } else {
        formData.append(
          "detailedBio",
          document.getElementById("detailedBio").value
        );
      }

      const files = document.getElementById("documentUpload").files;
      for (let i = 0; i < files.length; i++) {
        formData.append("documents", files[i]);
      }

      try {
        const res = await fetch(
          "http://localhost:5000/api/users/upload-documents",
          {
            method: "POST",
            headers: { "x-auth-token": token }, // Do NOT set Content-Type, browser sets it for FormData
            body: formData,
          }
        );

        if (res.ok) {
          alert("Documents submitted successfully!");
          window.location.reload();
        } else {
          const data = await res.json();
          alert(data.message || "Upload failed");
        }
      } catch (err) {
        console.error(err);
        alert("Error submitting form");
      } finally {
        btn.disabled = false;
        btn.innerHTML = originalText;
      }
    });

  // Logout
  document.getElementById("logoutBtn").addEventListener("click", (e) => {
    e.preventDefault();
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    window.location.href = "../login.html";
  });
});
