const API_URL = "http://localhost:5000/api";

// Check Admin Auth
function checkAdminAuth() {
  const token = localStorage.getItem("token");
  const user = JSON.parse(localStorage.getItem("user") || "{}");

  if (!token || user.role !== "admin") {
    window.location.href = "../../login.html";
    return null;
  }
  return token;
}

// ================= TOAST NOTIFICATIONS =================
function showToast(message, type = "success") {
  // Remove existing toast container if any
  let container = document.getElementById("toastContainer");
  if (!container) {
    container = document.createElement("div");
    container.id = "toastContainer";
    container.className = "toast-container position-fixed top-0 end-0 p-3";
    container.style.zIndex = "9999";
    document.body.appendChild(container);
  }

  const bgColors = {
    success: "bg-success",
    error: "bg-danger",
    warning: "bg-warning",
    info: "bg-info",
  };

  const icons = {
    success: "fa-check-circle",
    error: "fa-exclamation-circle",
    warning: "fa-exclamation-triangle",
    info: "fa-info-circle",
  };

  const toastEl = document.createElement("div");
  toastEl.className = `toast show align-items-center text-white ${
    bgColors[type] || bgColors.success
  } border-0`;
  toastEl.setAttribute("role", "alert");
  toastEl.innerHTML = `
    <div class="d-flex">
      <div class="toast-body">
        <i class="fas ${icons[type] || icons.success} me-2"></i>${message}
      </div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" onclick="this.parentElement.parentElement.remove()"></button>
    </div>
  `;

  container.appendChild(toastEl);

  // Auto-remove after 4 seconds
  setTimeout(() => {
    toastEl.classList.remove("show");
    setTimeout(() => toastEl.remove(), 300);
  }, 4000);
}

// ================= DASHBOARD STATS =================
function animateCounter(elementId, targetValue, duration = 800) {
  const element = document.getElementById(elementId);
  if (!element) return;

  const startValue = 0;
  const startTime = performance.now();

  function updateCounter(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const easeOutQuart = 1 - Math.pow(1 - progress, 4);
    const currentValue = Math.round(
      startValue + (targetValue - startValue) * easeOutQuart
    );
    element.textContent = currentValue.toLocaleString();
    if (progress < 1) requestAnimationFrame(updateCounter);
  }

  requestAnimationFrame(updateCounter);
}

async function loadDashboardStats() {
  const token = checkAdminAuth();
  if (!token) return;

  try {
    // Fetch all users count
    const usersRes = await fetch(`${API_URL}/users/admin/users`, {
      headers: { "x-auth-token": token },
    });
    if (usersRes.ok) {
      const users = await usersRes.json();
      animateCounter("statTotalUsers", users.length);

      // Count volunteers and orgs
      const volunteers = users.filter((u) => u.role === "volunteer").length;
      const orgs = users.filter((u) => u.role === "organization").length;
      const pending = users.filter(
        (u) => u.verificationStatus === "pending"
      ).length;

      // Update widget stats if they exist
      const volEl = document.getElementById("statVolunteers");
      const orgEl = document.getElementById("statOrganizations");
      const pendingEl = document.getElementById("statPendingVerifications");

      if (volEl) animateCounter("statVolunteers", volunteers);
      if (orgEl) animateCounter("statOrganizations", orgs);
      if (pendingEl) animateCounter("statPendingVerifications", pending);
    }

    // Fetch opportunities count
    const oppsRes = await fetch(`${API_URL}/opportunities/admin/all`, {
      headers: { "x-auth-token": token },
    });
    if (oppsRes.ok) {
      const opps = await oppsRes.json();
      animateCounter("statOpportunities", opps.length);
      const activeOpps = opps.filter((o) => o.status === "active").length;
      const trendEl = document.getElementById("statOppsTrend");
      if (trendEl) trendEl.textContent = `${activeOpps} active`;
    }

    // Fetch applications count
    const appsRes = await fetch(`${API_URL}/applications/admin/all`, {
      headers: { "x-auth-token": token },
    });
    if (appsRes.ok) {
      const apps = await appsRes.json();
      animateCounter("statApplications", apps.length);
      const pendingApps = apps.filter((a) => a.status === "pending").length;
      const trendEl = document.getElementById("statAppsTrend");
      if (trendEl) trendEl.textContent = `${pendingApps} pending`;
    }
  } catch (err) {
    console.error("Error loading dashboard stats:", err);
  }
}

// Initialize dashboard on load
if (window.location.pathname.includes("admin-dashboard.html")) {
  document.addEventListener("DOMContentLoaded", () => {
    loadDashboardStats();
    loadPendingVolunteersPreview();
    loadPendingOrganizationsPreview();
    loadRecentPostsPreview();
    loadRecentApplicationsPreview();
    loadSystemStatus();
    loadRecentActivity();
    // Refresh system status every 30 seconds
    setInterval(loadSystemStatus, 30000);
  });
}

// ================= RECENT ACTIVITY =================
async function loadRecentActivity() {
  const token = checkAdminAuth();
  if (!token) return;

  const container = document.getElementById("recentActivityContainer");
  const countBadge = document.getElementById("activityCount");
  if (!container) return;

  try {
    // Fetch recent data from multiple sources
    const [usersRes, appsRes, oppsRes] = await Promise.all([
      fetch(`${API_URL}/users/admin/users`, {
        headers: { "x-auth-token": token },
      }),
      fetch(`${API_URL}/applications/admin/all`, {
        headers: { "x-auth-token": token },
      }),
      fetch(`${API_URL}/opportunities/admin/all`, {
        headers: { "x-auth-token": token },
      }),
    ]);

    const users = usersRes.ok ? await usersRes.json() : [];
    const apps = appsRes.ok ? await appsRes.json() : [];
    const opps = oppsRes.ok ? await oppsRes.json() : [];

    // Build activity items
    const activities = [];

    // Add user registrations
    if (Array.isArray(users)) {
      users.slice(0, 5).forEach((u) => {
        activities.push({
          type: "user",
          icon: u.role === "organization" ? "fa-building" : "fa-user",
          color: u.role === "organization" ? "success" : "primary",
          text: `New ${u.role} registered: ${u.name}`,
          date: new Date(u.createdAt || Date.now()),
        });
      });
    }

    // Add recent applications
    if (Array.isArray(apps)) {
      apps.slice(0, 5).forEach((a) => {
        activities.push({
          type: "application",
          icon: "fa-file-alt",
          color:
            a.status === "accepted"
              ? "success"
              : a.status === "pending"
              ? "warning"
              : "info",
          text: `Application ${a.status}: ${
            a.volunteerId?.name || "Volunteer"
          } → ${a.opportunityId?.title || "Opportunity"}`,
          date: new Date(a.createdAt || Date.now()),
        });
      });
    }

    // Add recent opportunities
    if (Array.isArray(opps)) {
      opps.slice(0, 5).forEach((o) => {
        activities.push({
          type: "opportunity",
          icon: "fa-briefcase",
          color: o.status === "active" ? "success" : "warning",
          text: `Opportunity ${o.status}: ${o.title}`,
          date: new Date(o.createdAt || Date.now()),
        });
      });
    }

    // Sort by date (most recent first)
    activities.sort((a, b) => b.date - a.date);

    const displayItems = activities.slice(0, 6);

    if (countBadge) countBadge.textContent = `${displayItems.length} recent`;

    if (displayItems.length === 0) {
      container.innerHTML =
        '<div class="text-center text-muted py-4"><i class="fas fa-inbox fa-2x mb-2"></i><p class="mb-0">No recent activity</p></div>';
      return;
    }

    // Render activity items
    container.innerHTML = displayItems
      .map((item) => {
        const timeAgo = getTimeAgo(item.date);
        return `
        <div class="d-flex align-items-start p-3 border-bottom" style="transition: background 0.2s;" onmouseover="this.style.background='#f8fafc'" onmouseout="this.style.background='transparent'">
          <div class="bg-${item.color} bg-opacity-10 rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 36px; height: 36px; min-width: 36px;">
            <i class="fas ${item.icon} text-${item.color}" style="font-size: 0.85rem;"></i>
          </div>
          <div class="flex-grow-1">
            <p class="mb-0 small">${item.text}</p>
            <small class="text-muted">${timeAgo}</small>
          </div>
        </div>
      `;
      })
      .join("");
  } catch (err) {
    console.error("Error loading recent activity:", err);
    if (container) {
      container.innerHTML =
        '<div class="text-center text-muted py-4">Failed to load activity</div>';
    }
  }
}

// Helper function to format relative time
function getTimeAgo(date) {
  const now = new Date();
  const diff = now - date;
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);

  if (minutes < 1) return "Just now";
  if (minutes < 60) return `${minutes} min ago`;
  if (hours < 24) return `${hours} hour${hours > 1 ? "s" : ""} ago`;
  if (days < 7) return `${days} day${days > 1 ? "s" : ""} ago`;
  return date.toLocaleDateString();
}

// ================= SYSTEM STATUS =================
async function loadSystemStatus() {
  try {
    const startTime = Date.now();
    const res = await fetch(`${API_URL}/health`);
    const actualResponseTime = Date.now() - startTime;

    if (!res.ok) throw new Error("Health check failed");

    const data = await res.json();

    // Update status badge
    const statusBadge = document.getElementById("systemStatusBadge");
    if (statusBadge) {
      statusBadge.textContent =
        data.status === "operational" ? "Online" : "Issues";
      statusBadge.className = `badge bg-${
        data.status === "operational" ? "success" : "danger"
      }`;
    }

    // Update uptime
    const uptimeText = document.getElementById("uptimeText");
    const uptimeBar = document.getElementById("uptimeBar");
    if (uptimeText && uptimeBar) {
      uptimeText.textContent = data.uptime.formatted;
      uptimeBar.style.width = `${data.uptime.percent}%`;
    }

    // Update database status
    const dbStatusText = document.getElementById("dbStatusText");
    const dbStatusBar = document.getElementById("dbStatusBar");
    if (dbStatusText && dbStatusBar) {
      dbStatusText.textContent = data.database.healthy
        ? "Connected"
        : "Disconnected";
      dbStatusText.className = `text-${
        data.database.healthy ? "success" : "danger"
      }`;
      dbStatusBar.style.width = data.database.healthy ? "100%" : "0%";
      dbStatusBar.className = `progress-bar bg-${
        data.database.healthy ? "success" : "danger"
      }`;
    }

    // Update response time (use actual measured time)
    const responseTimeText = document.getElementById("responseTimeText");
    const responseTimeBar = document.getElementById("responseTimeBar");
    if (responseTimeText && responseTimeBar) {
      responseTimeText.textContent = `${actualResponseTime}ms`;
      // Scale: 0-50ms = green, 50-200ms = yellow, 200+ = red
      const rtPercent = Math.min(100, (actualResponseTime / 200) * 100);
      const rtColor =
        actualResponseTime < 50
          ? "success"
          : actualResponseTime < 200
          ? "warning"
          : "danger";
      responseTimeText.className = `text-${rtColor}`;
      responseTimeBar.style.width = `${100 - rtPercent}%`;
      responseTimeBar.className = `progress-bar bg-${rtColor}`;
    }

    // Update memory usage
    const memoryText = document.getElementById("memoryText");
    const memoryBar = document.getElementById("memoryBar");
    if (memoryText && memoryBar) {
      memoryText.textContent = `${data.memory.percent}%`;
      const memColor =
        data.memory.percent < 70
          ? "info"
          : data.memory.percent < 90
          ? "warning"
          : "danger";
      memoryText.className = `text-${memColor}`;
      memoryBar.style.width = `${data.memory.percent}%`;
      memoryBar.className = `progress-bar bg-${memColor}`;
    }

    // Update last updated time
    const lastUpdated = document.getElementById("lastUpdated");
    if (lastUpdated) {
      lastUpdated.textContent = `Last updated: ${new Date().toLocaleTimeString()}`;
    }
  } catch (err) {
    console.error("Error loading system status:", err);
    const statusBadge = document.getElementById("systemStatusBadge");
    if (statusBadge) {
      statusBadge.textContent = "Offline";
      statusBadge.className = "badge bg-danger";
    }
  }
}

// ================= DASHBOARD WIDGETS =================

// Load Pending Volunteers Preview
async function loadPendingVolunteersPreview() {
  const token = checkAdminAuth();
  if (!token) return;

  try {
    const res = await fetch(
      `${API_URL}/users/admin/users?status=pending&role=volunteer`,
      {
        headers: { "x-auth-token": token },
      }
    );
    const users = await res.json();
    const container = document.getElementById("pendingVolunteersPreview");
    if (!container) return;

    const volunteers = Array.isArray(users)
      ? users.filter((u) => u.role === "volunteer")
      : [];

    if (volunteers.length === 0) {
      container.innerHTML =
        '<div class="text-center text-muted py-4"><i class="fas fa-check-circle fa-2x mb-2"></i><p class="mb-0">No pending volunteer verifications</p></div>';
      return;
    }

    container.innerHTML = volunteers
      .slice(0, 3)
      .map(
        (user) => `
      <div class="d-flex align-items-center p-3 border-bottom" style="transition: background 0.2s;" onmouseover="this.style.background='#f8fafc'" onmouseout="this.style.background='transparent'">
        <div class="bg-primary bg-opacity-10 rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 45px; height: 45px;">
          <span class="fw-bold text-primary">${(user.name || "U")
            .charAt(0)
            .toUpperCase()}</span>
        </div>
        <div class="flex-grow-1">
          <h6 class="mb-0 fw-semibold">${user.name}</h6>
          <small class="text-muted">${user.email}</small>
        </div>
        <a href="user-details.html?id=${user._id}&role=${
          user.role
        }" class="btn btn-sm btn-outline-primary">Review</a>
      </div>
    `
      )
      .join("");
  } catch (err) {
    console.error("Error loading pending volunteers:", err);
  }
}

// Load Pending Organizations Preview
async function loadPendingOrganizationsPreview() {
  const token = checkAdminAuth();
  if (!token) return;

  try {
    const res = await fetch(
      `${API_URL}/users/admin/users?status=pending&role=organization`,
      {
        headers: { "x-auth-token": token },
      }
    );
    const users = await res.json();
    const container = document.getElementById("pendingOrganizationsPreview");
    if (!container) return;

    const orgs = Array.isArray(users)
      ? users.filter((u) => u.role === "organization")
      : [];

    if (orgs.length === 0) {
      container.innerHTML =
        '<div class="text-center text-muted py-4"><i class="fas fa-check-circle fa-2x mb-2"></i><p class="mb-0">No pending organization verifications</p></div>';
      return;
    }

    container.innerHTML = orgs
      .slice(0, 3)
      .map(
        (org) => `
      <div class="d-flex align-items-center p-3 border-bottom" style="transition: background 0.2s;" onmouseover="this.style.background='#f8fafc'" onmouseout="this.style.background='transparent'">
        <div class="bg-success bg-opacity-10 rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 45px; height: 45px;">
          <span class="fw-bold text-success">${(org.name || "O")
            .charAt(0)
            .toUpperCase()}</span>
        </div>
        <div class="flex-grow-1">
          <h6 class="mb-0 fw-semibold">${org.name}</h6>
          <small class="text-muted">${org.email}</small>
        </div>
        <a href="user-details.html?id=${org._id}&role=${
          org.role
        }" class="btn btn-sm btn-outline-success">Review</a>
      </div>
    `
      )
      .join("");
  } catch (err) {
    console.error("Error loading pending organizations:", err);
  }
}

// Load Recent Posts Preview
async function loadRecentPostsPreview() {
  const token = checkAdminAuth();
  if (!token) return;

  try {
    const res = await fetch(`${API_URL}/opportunities/admin/all`, {
      headers: { "x-auth-token": token },
    });
    const posts = await res.json();
    const container = document.getElementById("recentPostsPreview");
    if (!container) return;

    if (!posts || posts.length === 0) {
      container.innerHTML =
        '<div class="text-center text-muted py-4"><i class="fas fa-inbox fa-2x mb-2"></i><p class="mb-0">No posts found</p></div>';
      return;
    }

    const recent = posts.slice(0, 3);
    container.innerHTML = recent
      .map((post) => {
        const statusClass =
          post.status === "active"
            ? "success"
            : post.status === "pending"
            ? "warning"
            : "secondary";
        return `
        <div class="d-flex align-items-center p-3 border-bottom" style="transition: background 0.2s;" onmouseover="this.style.background='#f8fafc'" onmouseout="this.style.background='transparent'">
          <div class="flex-grow-1">
            <h6 class="mb-0 fw-semibold">${post.title}</h6>
            <small class="text-muted">${
              post.organization?.name || "Organization"
            } • ${post.category || "General"}</small>
          </div>
          <span class="badge bg-${statusClass} me-2">${post.status}</span>
        </div>
      `;
      })
      .join("");
  } catch (err) {
    console.error("Error loading recent posts:", err);
  }
}

// Load Recent Applications Preview
async function loadRecentApplicationsPreview() {
  const token = checkAdminAuth();
  if (!token) return;

  try {
    const res = await fetch(`${API_URL}/applications/admin/all`, {
      headers: { "x-auth-token": token },
    });
    const apps = await res.json();
    const container = document.getElementById("recentApplicationsPreview");
    if (!container) return;

    if (!apps || apps.length === 0) {
      container.innerHTML =
        '<div class="text-center text-muted py-4"><i class="fas fa-inbox fa-2x mb-2"></i><p class="mb-0">No applications found</p></div>';
      return;
    }

    const recent = apps.slice(0, 3);
    container.innerHTML = recent
      .map((app) => {
        const volunteer = app.volunteerId || {};
        const opportunity = app.opportunityId || {};
        const statusColors = {
          pending: "warning",
          accepted: "success",
          rejected: "danger",
        };
        const statusColor = statusColors[app.status] || "secondary";

        return `
        <div class="d-flex align-items-center p-3 border-bottom" style="transition: background 0.2s;" onmouseover="this.style.background='#f8fafc'" onmouseout="this.style.background='transparent'">
          <div class="bg-info bg-opacity-10 rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 45px; height: 45px;">
            <span class="fw-bold text-info">${(volunteer.name || "V")
              .charAt(0)
              .toUpperCase()}</span>
          </div>
          <div class="flex-grow-1">
            <h6 class="mb-0 fw-semibold">${volunteer.name || "Volunteer"}</h6>
            <small class="text-muted">${
              opportunity.title || "Opportunity"
            }</small>
          </div>
          <span class="badge bg-${statusColor}">${app.status}</span>
        </div>
      `;
      })
      .join("");
  } catch (err) {
    console.error("Error loading recent applications:", err);
  }
}

// ================= USER MANAGEMENT =================
// ================= USER MANAGEMENT =================
// ================= USER MANAGEMENT =================
async function loadUsers(roleFilter = null) {
  const token = checkAdminAuth();
  if (!token) return;

  try {
    // Determine Role Filter based on Page URL if not provided
    if (!roleFilter) {
      if (window.location.pathname.includes("manage-volunteers.html"))
        roleFilter = "volunteer";
      if (window.location.pathname.includes("manage-organizations.html"))
        roleFilter = "organization";
    }

    const res = await fetch(`${API_URL}/users/admin/users`, {
      headers: { "x-auth-token": token },
    });
    let users = await res.json();

    // Client-side filtering by role
    if (roleFilter) {
      users = users.filter((user) => user.role === roleFilter);
    }

    // Initialize piles
    const buckets = {
      approved: [],
      pending: [],
      rejected: [],
      changes_requested: [],
    };

    // Distribute users
    users.forEach((u) => {
      // Normalize status just in case
      const s = u.verificationStatus || "pending";
      if (buckets[s]) {
        buckets[s].push(u);
      } else {
        // Fallback for unexpected status
        buckets.pending.push(u);
      }
    });

    // Update Counts & Tables
    Object.keys(buckets).forEach((status) => {
      const list = buckets[status];

      // Update Count Badge
      const countBadge = document.getElementById(
        `count-${status.replace("_", "-")}`
      );
      if (countBadge) countBadge.textContent = list.length;

      // Populate Table
      const tbody = document.getElementById(
        `tbody-${status.replace("_", "-")}`
      );
      if (!tbody) return;

      tbody.innerHTML = "";
      if (list.length === 0) {
        tbody.innerHTML =
          '<tr><td colspan="4" class="text-center text-muted">No users in this category</td></tr>';
        return;
      }

      list.forEach((user) => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td>
                <div class="d-flex align-items-center">
                    <div class="bg-light rounded-circle p-2 me-3"><i class="fas fa-user"></i></div>
                    <div>
                        <h6 class="mb-0">${user.name}</h6>
                        <small class="text-muted">Joined: ${new Date(
                          user.createdAt
                        ).toLocaleDateString()}</small>
                    </div>
                </div>
            </td>
            <td>${user.email}</td>
            <td><span class="badge bg-${getStatusBadgeColor(
              user.verificationStatus
            )}">
                ${formatStatus(user.verificationStatus)}
            </span></td>
            <td>
                <a href="user-details.html?id=${user._id}&role=${user.role}" 
                   class="btn btn-sm btn-outline-primary">
                   View Details
                </a>
            </td>
        `;
        tbody.appendChild(tr);
      });
    });
  } catch (err) {
    console.error("Error loading users:", err);
  }
}

function getStatusBadgeColor(status) {
  switch (status) {
    case "approved":
      return "success";
    case "pending":
      return "warning";
    case "rejected":
      return "danger";
    case "changes_requested":
      return "info";
    default:
      return "secondary";
  }
}

function formatStatus(status) {
  return status
    ? status
        .split("_")
        .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
        .join(" ")
    : "Unknown";
}

// ================= USER DETAILS =================
async function loadUserDetails() {
  const token = checkAdminAuth();
  if (!token) return;

  const urlParams = new URLSearchParams(window.location.search);
  const userId = urlParams.get("id");

  if (!userId) return;

  try {
    const res = await fetch(`${API_URL}/users/admin/users/${userId}`, {
      headers: { "x-auth-token": token },
    });
    const user = await res.json();

    // Fill Basic Info
    document.getElementById("dName").textContent = user.name || "N/A";
    document.getElementById("dEmail").textContent = user.email || "N/A";
    document.getElementById("dPhone").textContent = user.phone || "N/A";
    document.getElementById("dLocation").textContent = user.location || "-";
    document.getElementById("dRole").textContent = user.role
      ? user.role.toUpperCase()
      : "UNKNOWN";
    document.getElementById("dJoined").textContent = user.createdAt
      ? new Date(user.createdAt).toLocaleDateString()
      : "-";

    // Status Badge
    const badge = document.getElementById("userStatusBadge");
    const status = user.verificationStatus || "pending";
    badge.textContent = status.toUpperCase();
    badge.className = `badge bg-${
      status === "approved" ? "success" : "warning"
    }`;

    // Extended Details & Conditional Rows
    if (user.role === "organization") {
      document.getElementById("rowWebsite").style.display = "table-row";
      document.getElementById("dWebsite").textContent = user.website || "-";

      document.getElementById("rowOrgDesc").style.display = "table-row";
      if (user.organizationInfo) {
        document.getElementById("dOrgDesc").textContent =
          user.organizationInfo.description || "-";
      }
    } else if (user.role === "volunteer") {
      document.getElementById("rowSkills").style.display = "table-row";
      document.getElementById("dSkills").textContent = user.skills
        ? user.skills.join(", ")
        : "-";

      document.getElementById("rowDetailedBio").style.display = "table-row";
    }

    // Profile Details
    if (user.profileDetails) {
      document.getElementById("dIdNumber").textContent =
        user.profileDetails.idNumber || "-";
      // Shared Bio/Mission Field
      document.getElementById("dBio").textContent =
        user.bio || user.profileDetails.missionStatement || "-";

      if (user.role === "volunteer") {
        document.getElementById("dDetailedBio").textContent =
          user.profileDetails.detailedBio || "-";
      }
    } else {
      document.getElementById("dBio").textContent = user.bio || "-";
    }

    // --- NEW: DISPLAY STATS ---
    const statsContainer = document.getElementById("userStatsContainer");
    if (statsContainer && user.stats) {
      statsContainer.innerHTML = ""; // Clear prev content
      if (user.role === "organization") {
        statsContainer.innerHTML = `
                <div class="col-md-6 mb-3">
                    <div class="card bg-light border-0">
                        <div class="card-body text-center">
                            <h3 class="mb-1">${
                              user.stats.opportunitiesPosted || 0
                            }</h3>
                            <small class="text-muted">Opportunities Posted</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-3">
                     <div class="card bg-light border-0">
                        <div class="card-body text-center">
                            <h3 class="mb-1">${
                              user.stats.volunteersWorkedWith || 0
                            }</h3>
                            <small class="text-muted">Volunteers Worked With</small>
                        </div>
                    </div>
                </div>
             `;
      } else if (user.role === "volunteer") {
        statsContainer.innerHTML = `
                <div class="col-md-12 mb-3">
                    <div class="card bg-light border-0">
                        <div class="card-body text-center">
                            <h3 class="mb-1">${
                              user.stats.applicationsSubmitted || 0
                            }</h3>
                            <small class="text-muted">Applications Submitted</small>
                        </div>
                    </div>
                </div>
             `;
      }
    }

    // --- NEW: BACK BUTTON LOGIC ---
    const backBtn = document.getElementById("backToUserListBtn");
    if (backBtn) {
      backBtn.onclick = (e) => {
        e.preventDefault();
        if (user.role === "organization") {
          window.location.href = "manage-organizations.html";
        } else {
          window.location.href = "manage-volunteers.html";
        }
      };
    }

    // Documents
    const docList = document.getElementById("documentsList");
    if (user.documents && user.documents.length > 0) {
      docList.innerHTML = "";
      user.documents.forEach((doc) => {
        const item = document.createElement("a");
        item.href = `http://localhost:5000${doc.url}`;
        item.target = "_blank";
        item.className =
          "list-group-item list-group-item-action d-flex justify-content-between align-items-center";
        item.innerHTML = `
                    <div><i class="fas fa-file-pdf text-danger me-2"></i> ${
                      doc.name
                    }</div>
                    <small class="text-muted">${new Date(
                      doc.uploadedAt
                    ).toLocaleDateString()}</small>
                `;
        docList.appendChild(item);
      });
    } else {
      docList.innerHTML =
        '<div class="alert alert-secondary">No documents uploaded yet.</div>';
    }

    // Comments History
    if (user.adminComments) {
      const history = document.getElementById("commentsHistory");
      user.adminComments.forEach((c) => {
        const li = document.createElement("li");
        li.className = "list-group-item";
        li.innerHTML = `<small class="text-muted">${new Date(
          c.date
        ).toLocaleString()}</small>: ${c.comment}`;
        history.appendChild(li);
      });
    }

    // Expose verify function globally so buttons can call it
    window.updateStatus = async (status) => {
      const comment = document.getElementById("adminComment").value;

      if (comment) {
        await fetch(`${API_URL}/users/admin/comment`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-auth-token": token,
          },
          body: JSON.stringify({ userId, comment }),
        });
      }

      const res = await fetch(`${API_URL}/users/admin/verify`, {
        method: "PUT",
        headers: { "Content-Type": "application/json", "x-auth-token": token },
        body: JSON.stringify({ userId, status }),
      });

      if (res.ok) {
        alert("Status Updated!");
        location.reload();
      } else {
        alert("Error updating status");
      }
    };
  } catch (err) {
    console.error(err);
  }
}

// Router
const curPath = window.location.pathname;

if (
  curPath.includes("user-management.html") ||
  curPath.includes("manage-volunteers.html") ||
  curPath.includes("manage-organizations.html")
) {
  document.addEventListener("DOMContentLoaded", () => loadUsers());
} else if (document.getElementById("pendingUsersPreview")) {
  // Dashboard check
  document.addEventListener("DOMContentLoaded", loadPendingUsersPreview);
} else if (curPath.includes("admin-manage-posts.html")) {
  document.addEventListener("DOMContentLoaded", () => {
    loadOpportunities();
    setupOppFilters();
  });
} else if (curPath.includes("manage-applications.html")) {
  document.addEventListener("DOMContentLoaded", () => {
    loadAllApplications();
    document
      .getElementById("appStatusFilter")
      .addEventListener("change", loadAllApplications);
  });
}

// --- Manage Opportunities (Admin) ---
let currentActionPostId = null;

async function loadOpportunities() {
  const tableBody = document.getElementById("opportunitiesTableBody");
  const statusFilter = document.getElementById("postStatusFilter").value;
  const search = document.getElementById("postSearch").value;

  tableBody.innerHTML =
    '<tr><td colspan="6" class="text-center py-4"><div class="spinner-border text-primary"></div></td></tr>';

  try {
    const token = localStorage.getItem("token");
    let url = "http://localhost:5000/api/opportunities/admin/all?";
    if (statusFilter) url += `status=${statusFilter}&`;
    if (search) url += `search=${search}`;

    const response = await fetch(url, {
      headers: { "x-auth-token": token },
    });

    if (response.status === 401 || response.status === 403) {
      window.location.href = "../../login.html";
      return;
    }

    const opportunities = await response.json();

    if (opportunities.length === 0) {
      tableBody.innerHTML =
        '<tr><td colspan="6" class="text-center">No opportunities found.</td></tr>';
      return;
    }

    tableBody.innerHTML = opportunities
      .map(
        (opp) => `
            <tr>
                <td>
                    <div class="fw-bold text-dark">${opp.title}</div>
                    <small class="text-muted"><i class="fas fa-map-marker-alt me-1"></i>${
                      opp.location
                    }</small>
                </td>
                <td>
                    <div class="d-flex align-items-center">
                        <div>
                            <div class="fw-bold">${
                              opp.organizationId?.name || "Unknown"
                            }</div>
                            <small class="text-muted">${
                              opp.organizationId?.email || ""
                            }</small>
                        </div>
                    </div>
                </td>
                <td>${new Date(opp.createdAt).toLocaleDateString()}</td>
                <td>
                    <span class="badge ${getStatusBadgeClass(
                      opp.status
                    )}">${opp.status.toUpperCase()}</span>
                </td>
                 <td>
                    ${
                      opp.isLockedByAdmin
                        ? '<span class="badge bg-danger"><i class="fas fa-lock me-1"></i>LOCKED</span>'
                        : '<span class="badge bg-secondary">Unlocked</span>'
                    }
                </td>
                <td>
                    <a href="../opportunity-details.html?id=${
                      opp._id
                    }" class="btn btn-sm btn-outline-primary me-1" target="_blank" title="View"><i class="fas fa-eye"></i></a>
                    <button class="btn btn-sm btn-outline-secondary" onclick="openPostActionModal('${
                      opp._id
                    }', '${opp.status}', ${
          opp.isLockedByAdmin || false
        })"><i class="fas fa-cog"></i></button>
                </td>
            </tr>
        `
      )
      .join("");
  } catch (err) {
    console.error(err);
    tableBody.innerHTML =
      '<tr><td colspan="6" class="text-center text-danger">Error loading data.</td></tr>';
  }
}

function setupOppFilters() {
  document
    .getElementById("postStatusFilter")
    .addEventListener("change", loadOpportunities);
  document
    .getElementById("postSearch")
    .addEventListener("input", debounce(loadOpportunities, 500));
}

window.openPostActionModal = function (id, status, isLocked) {
  currentActionPostId = id;
  document.getElementById("actionPostId").value = id;
  document.getElementById("actionStatus").value = status;
  document.getElementById("actionLock").checked = isLocked;
  document.getElementById("actionComment").value = "";

  const modalEl = document.getElementById("postActionModal");
  const modal = bootstrap.Modal.getOrCreateInstance(modalEl); // Correct usage
  modal.show();
};

window.savePostAction = async function () {
  if (!currentActionPostId) return;

  const status = document.getElementById("actionStatus").value;
  const isLocked = document.getElementById("actionLock").checked;
  const adminComments = document.getElementById("actionComment").value;

  try {
    const token = localStorage.getItem("token");
    const response = await fetch(
      `http://localhost:5000/api/opportunities/admin/${currentActionPostId}/status`,
      {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "x-auth-token": token,
        },
        body: JSON.stringify({
          status,
          isLockedByAdmin: isLocked,
          adminComments,
        }),
      }
    );

    if (response.ok) {
      alert("Post updated successfully");
      const modalEl = document.getElementById("postActionModal");
      const modal = bootstrap.Modal.getInstance(modalEl);
      modal.hide();
      loadOpportunities();
    } else {
      const data = await response.json();
      alert(data.message || "Update failed");
    }
  } catch (err) {
    console.error(err);
    alert("Server error");
  }
};

window.deletePost = async function () {
  if (
    !currentActionPostId ||
    !confirm("Are you sure you want to PERMANENTLY delete this post?")
  )
    return;

  try {
    const token = localStorage.getItem("token");
    const response = await fetch(
      `http://localhost:5000/api/opportunities/${currentActionPostId}`,
      {
        method: "DELETE",
        headers: { "x-auth-token": token },
      }
    );

    if (response.ok) {
      alert("Post deleted");
      const modalEl = document.getElementById("postActionModal");
      const modal = bootstrap.Modal.getInstance(modalEl);
      modal.hide();
      loadOpportunities();
    } else {
      const data = await response.json();
      alert(data.message || "Delete failed");
    }
  } catch (err) {
    console.error(err);
    alert("Server error");
  }
};

// --- Manage Applications (Admin) ---
async function loadAllApplications() {
  const tableBody = document.getElementById("applicationsTableBody");
  const status = document.getElementById("appStatusFilter").value;

  tableBody.innerHTML =
    '<tr><td colspan="5" class="text-center py-4"><div class="spinner-border text-primary"></div></td></tr>';

  try {
    const token = localStorage.getItem("token");
    let url = "http://localhost:5000/api/applications/admin/all?";
    if (status) url += `status=${status}`;

    const response = await fetch(url, {
      headers: { "x-auth-token": token },
    });

    if (response.status === 401 || response.status === 403) {
      window.location.href = "../../login.html";
      return;
    }

    const apps = await response.json();

    if (apps.length === 0) {
      tableBody.innerHTML =
        '<tr><td colspan="5" class="text-center">No applications found.</td></tr>';
      return;
    }

    tableBody.innerHTML = apps
      .map(
        (app) => `
            <tr>
                <td>
                    <div class="fw-bold">${
                      app.volunteerId?.name || "Unknown"
                    }</div>
                    <small class="text-muted">${
                      app.volunteerId?.email || ""
                    }</small>
                </td>
                <td>
                    <div class="fw-bold text-primary">${
                      app.opportunityId?.title || "Deleted Post"
                    }</div>
                </td>
                <td>
                    ${app.opportunityId?.organizationId?.name || "Unknown Org"}
                </td>
                <td>${new Date(app.appliedAt).toLocaleDateString()}</td>
                <td>
                    <span class="badge ${getStatusBadgeClass(
                      app.status
                    )}">${app.status.toUpperCase()}</span>
                </td>
            </tr>
        `
      )
      .join("");
  } catch (err) {
    console.error(err);
    tableBody.innerHTML =
      '<tr><td colspan="5" class="text-center text-danger">Error loading data.</td></tr>';
  }
}

function getStatusBadgeClass(status) {
  switch (status) {
    case "active":
      return "bg-success";
    case "approved":
      return "bg-success";
    case "accepted":
      return "bg-success";
    case "completed":
      return "bg-primary";
    case "pending":
      return "bg-warning text-dark";
    case "draft":
      return "bg-secondary";
    case "inactive":
      return "bg-secondary";
    case "rejected":
      return "bg-danger";
    case "changes_requested":
      return "bg-info text-dark";
    default:
      return "bg-secondary";
  }
}

function debounce(func, wait) {
  let timeout;
  return (...args) => {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

// ================= MANAGE VOLUNTEERS PAGE =================
if (window.location.pathname.includes("manage-volunteers.html")) {
  document.addEventListener("DOMContentLoaded", loadVolunteers);
}

async function loadVolunteers() {
  const token = checkAdminAuth();
  if (!token) return;

  try {
    const res = await fetch(`${API_URL}/users/admin/users?role=volunteer`, {
      headers: { "x-auth-token": token },
    });
    const users = await res.json();
    const volunteers = Array.isArray(users)
      ? users.filter((u) => u.role === "volunteer")
      : [];

    // Group by status
    const grouped = {
      approved: volunteers.filter((v) => v.verificationStatus === "approved"),
      pending: volunteers.filter((v) => v.verificationStatus === "pending"),
      changes_requested: volunteers.filter(
        (v) => v.verificationStatus === "changes_requested"
      ),
      rejected: volunteers.filter((v) => v.verificationStatus === "rejected"),
    };

    // Update counts
    document.getElementById("count-approved")?.textContent &&
      (document.getElementById("count-approved").textContent =
        grouped.approved.length);
    document.getElementById("count-pending")?.textContent &&
      (document.getElementById("count-pending").textContent =
        grouped.pending.length);
    document.getElementById("count-changes-requested")?.textContent &&
      (document.getElementById("count-changes-requested").textContent =
        grouped.changes_requested.length);
    document.getElementById("count-rejected")?.textContent &&
      (document.getElementById("count-rejected").textContent =
        grouped.rejected.length);

    // Populate tables
    Object.keys(grouped).forEach((status) => {
      const tbody = document.getElementById(
        `tbody-${status.replace("_", "-")}`
      );
      if (!tbody) return;

      if (grouped[status].length === 0) {
        tbody.innerHTML = `<tr><td colspan="4" class="text-center text-muted py-4">No ${status.replace(
          "_",
          " "
        )} volunteers</td></tr>`;
        return;
      }

      tbody.innerHTML = grouped[status]
        .map(
          (v) => `
        <tr>
          <td>
            <div class="d-flex align-items-center">
              <img src="${
                v.profilePicture
                  ? v.profilePicture.startsWith("http")
                    ? v.profilePicture
                    : "http://localhost:5000" + v.profilePicture
                  : "../assets/images/volunteer.jpg"
              }" 
                   class="rounded-circle me-2" style="width:40px;height:40px;object-fit:cover;">
              <div>
                <strong>${v.name}</strong><br>
                <small class="text-muted">${v.email}</small>
              </div>
            </div>
          </td>
          <td>${v.phone || "-"}</td>
          <td><span class="badge ${getStatusBadgeClass(
            v.verificationStatus
          )}">${(v.verificationStatus || "pending")
            .replace("_", " ")
            .toUpperCase()}</span></td>
          <td>
            <a href="user-details.html?id=${
              v._id
            }&role=volunteer" class="btn btn-sm btn-outline-primary">
              <i class="fas fa-eye me-1"></i>View Details
            </a>
          </td>
        </tr>
      `
        )
        .join("");
    });
  } catch (err) {
    console.error("Error loading volunteers:", err);
  }
}

// ================= MANAGE ORGANIZATIONS PAGE =================
if (window.location.pathname.includes("manage-organizations.html")) {
  document.addEventListener("DOMContentLoaded", loadOrganizations);
}

async function loadOrganizations() {
  const token = checkAdminAuth();
  if (!token) return;

  try {
    const res = await fetch(`${API_URL}/users/admin/users?role=organization`, {
      headers: { "x-auth-token": token },
    });
    const users = await res.json();
    const orgs = Array.isArray(users)
      ? users.filter((u) => u.role === "organization")
      : [];

    // Group by status
    const grouped = {
      approved: orgs.filter((o) => o.verificationStatus === "approved"),
      pending: orgs.filter((o) => o.verificationStatus === "pending"),
      changes_requested: orgs.filter(
        (o) => o.verificationStatus === "changes_requested"
      ),
      rejected: orgs.filter((o) => o.verificationStatus === "rejected"),
    };

    // Update counts
    document.getElementById("count-approved")?.textContent &&
      (document.getElementById("count-approved").textContent =
        grouped.approved.length);
    document.getElementById("count-pending")?.textContent &&
      (document.getElementById("count-pending").textContent =
        grouped.pending.length);
    document.getElementById("count-changes-requested")?.textContent &&
      (document.getElementById("count-changes-requested").textContent =
        grouped.changes_requested.length);
    document.getElementById("count-rejected")?.textContent &&
      (document.getElementById("count-rejected").textContent =
        grouped.rejected.length);

    // Populate tables
    Object.keys(grouped).forEach((status) => {
      const tbody = document.getElementById(
        `tbody-${status.replace("_", "-")}`
      );
      if (!tbody) return;

      if (grouped[status].length === 0) {
        tbody.innerHTML = `<tr><td colspan="4" class="text-center text-muted py-4">No ${status.replace(
          "_",
          " "
        )} organizations</td></tr>`;
        return;
      }

      tbody.innerHTML = grouped[status]
        .map(
          (o) => `
        <tr>
          <td>
            <div class="d-flex align-items-center">
              <img src="${
                o.profilePicture
                  ? o.profilePicture.startsWith("http")
                    ? o.profilePicture
                    : "http://localhost:5000" + o.profilePicture
                  : "../assets/images/volunteer.jpg"
              }" 
                   class="rounded-circle me-2" style="width:40px;height:40px;object-fit:cover;">
              <div>
                <strong>${o.name}</strong><br>
                <small class="text-muted">${o.email}</small>
              </div>
            </div>
          </td>
          <td>${o.phone || "-"}</td>
          <td><span class="badge ${getStatusBadgeClass(
            o.verificationStatus
          )}">${(o.verificationStatus || "pending")
            .replace("_", " ")
            .toUpperCase()}</span></td>
          <td>
            <a href="user-details.html?id=${
              o._id
            }&role=organization" class="btn btn-sm btn-outline-primary">
              <i class="fas fa-eye me-1"></i>View Details
            </a>
          </td>
        </tr>
      `
        )
        .join("");
    });
  } catch (err) {
    console.error("Error loading organizations:", err);
  }
}

// ================= MESSAGES & INQUIRIES =================
let allMessages = []; // Store fetched messages

async function loadMessages() {
  const token = checkAdminAuth();
  if (!token) return;

  const tableBody = document.getElementById("messagesTableBody");
  if (!tableBody) return;

  try {
    tableBody.innerHTML =
      '<tr><td colspan="5" class="text-center p-4"><span class="spinner-border text-primary" role="status"></span> Loading...</td></tr>';

    const res = await fetch(`${API_URL}/contact`, {
      headers: { "x-auth-token": token },
    });

    if (!res.ok) throw new Error("Failed to fetch messages");

    const responseData = await res.json();
    allMessages = responseData.data || [];

    if (allMessages.length === 0) {
      tableBody.innerHTML =
        '<tr><td colspan="5" class="text-center p-4 text-muted">No messages found</td></tr>';
      return;
    }

    renderMessagesTable(allMessages);
  } catch (err) {
    console.error("Error loading messages:", err);
    tableBody.innerHTML =
      '<tr><td colspan="5" class="text-center p-4 text-danger">Failed to load messages</td></tr>';
  }
}

function renderMessagesTable(messages) {
  const tableBody = document.getElementById("messagesTableBody");
  if (!tableBody) return;

  tableBody.innerHTML = messages
    .map((msg) => {
      const date =
        new Date(msg.createdAt).toLocaleDateString() +
        " " +
        new Date(msg.createdAt).toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        });
      const statusColors = {
        New: "primary",
        Read: "secondary",
        "In Progress": "warning",
        Resolved: "success",
      };
      const badgeColor = statusColors[msg.status] || "secondary";

      return `
        <tr class="${
          msg.status === "New" ? "fw-bold" : ""
        }" style="cursor: pointer;" onclick="openMessageModal('${msg._id}')">
            <td>${date}</td>
            <td>${msg.name}<br><small class="text-muted">${
        msg.email
      }</small></td>
            <td>${msg.subject}</td>
            <td><span class="badge bg-${badgeColor}">${msg.status}</span></td>
            <td>
                <button class="btn btn-sm btn-outline-primary" onclick="event.stopPropagation(); openMessageModal('${
                  msg._id
                }')">
                    Analyze
                </button>
            </td>
        </tr>
        `;
    })
    .join("");
}

function openMessageModal(id) {
  const msg = allMessages.find((m) => m._id === id);
  if (!msg) return;

  // Populate Modal
  document.getElementById("modalMsgId").value = msg._id;
  document.getElementById("modalMsgName").textContent = msg.name;
  document.getElementById("modalMsgEmail").textContent = msg.email;
  document.getElementById("modalMsgPhone").textContent = msg.phone || "N/A";
  document.getElementById("modalMsgDate").textContent = new Date(
    msg.createdAt
  ).toLocaleString();
  document.getElementById("modalMsgSubject").textContent = msg.subject;
  document.getElementById("modalMsgContent").textContent = msg.message;

  // Status Badge
  const statusBadges = {
    New: "bg-primary",
    Read: "bg-secondary",
    "In Progress": "bg-warning text-dark",
    Resolved: "bg-success",
  };
  const badge = document.getElementById("modalMsgStatusBadge");
  badge.className = `badge ${statusBadges[msg.status] || "bg-secondary"}`;
  badge.textContent = msg.status;

  // Action Form
  document.getElementById("modalMsgStatus").value = msg.status;
  document.getElementById("modalMsgNotes").value = msg.adminNotes || "";

  // Show Modal
  const modal = new bootstrap.Modal(document.getElementById("messageModal"));
  modal.show();
}

async function saveMessageAction() {
  const token = checkAdminAuth();
  if (!token) return;

  const id = document.getElementById("modalMsgId").value;
  const status = document.getElementById("modalMsgStatus").value;
  const adminNotes = document.getElementById("modalMsgNotes").value;
  const btn = document.querySelector("#messageModal .btn-primary");

  try {
    const originalText = btn.innerHTML;
    btn.innerHTML =
      '<span class="spinner-border spinner-border-sm"></span> Saving...';
    btn.disabled = true;

    const res = await fetch(`${API_URL}/contact/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        "x-auth-token": token,
      },
      body: JSON.stringify({ status, adminNotes }),
    });

    if (res.ok) {
      const updatedMsg = await res.json();
      showToast("Message updated successfully", "success");

      // Update local state
      const index = allMessages.findIndex((m) => m._id === id);
      if (index !== -1) {
        // Determine if backend returns the updated doc inside `data` or directly
        // Based on controller it returns { success: true, data: contact, message: ... }
        allMessages[index] = updatedMsg.data;
      }

      renderMessagesTable(allMessages);

      // Hide Modal
      const modalEl = document.getElementById("messageModal");
      const modal = bootstrap.Modal.getInstance(modalEl);
      modal.hide();
    } else {
      throw new Error("Failed to update message");
    }
  } catch (err) {
    console.error("Error updating message:", err);
    showToast(err.message || "Failed to update", "error");
  } finally {
    btn.innerHTML = "Save Changes";
    btn.disabled = false;
  }
}

async function deleteMessage() {
  if (
    !confirm(
      "Are you sure you want to delete this message? This action cannot be undone."
    )
  )
    return;

  const token = checkAdminAuth();
  if (!token) return;

  const id = document.getElementById("modalMsgId").value;

  try {
    const res = await fetch(`${API_URL}/contact/${id}`, {
      method: "DELETE",
      headers: { "x-auth-token": token },
    });

    if (res.ok) {
      showToast("Message deleted successfully", "success");

      // Remove from local state
      allMessages = allMessages.filter((m) => m._id !== id);
      renderMessagesTable(allMessages);

      // Hide Modal
      const modalEl = document.getElementById("messageModal");
      const modal = bootstrap.Modal.getInstance(modalEl);
      modal.hide();
    } else {
      throw new Error("Failed to delete message");
    }
  } catch (err) {
    console.error("Error deleting message:", err);
    showToast("Failed to delete message", "error");
  }
}

// Init messages page
if (window.location.pathname.includes("admin-messages.html")) {
  document.addEventListener("DOMContentLoaded", loadMessages);
}
