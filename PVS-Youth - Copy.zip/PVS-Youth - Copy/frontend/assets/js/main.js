import {
  checkAuthGuards,
  initLogout,
  initLogin,
  initRegister,
  initAdminLogin,
} from "./modules/auth.js";
import {
  initSmoothScroll,
  initAnimations,
  initTooltips,
  initFAQ,
  initContactForm,
  initStats,
} from "./modules/utils.js";
import {
  initOpportunities,
  fetchOpportunityDetails,
  loadFeaturedOpportunities,
} from "./modules/opportunities.js";
import { initApplicationForm } from "./modules/applications.js";
import {
  initDashboard,
  fetchOrganizationApplications,
  fetchOrganizationOpportunities,
  fetchAllApplications,
  fetchVolunteerApplications,
  loadEditOpportunity,
  fetchSavedOpportunities,
} from "./modules/dashboard.js";

document.addEventListener("DOMContentLoaded", function () {
  // 1. Auth Guards & Logout
  checkAuthGuards();
  initLogout();

  // 2. Auth Pages
  initLogin();
  initAdminLogin();
  initRegister();

  // 3. UI Utils
  initSmoothScroll();
  initAnimations();
  initTooltips();
  initFAQ();
  initContactForm();
  initStats();

  // 4. Opportunities
  initOpportunities();
  if (document.getElementById("oppTitle")) {
    fetchOpportunityDetails();
  }
  loadFeaturedOpportunities();

  // 5. Applications
  initApplicationForm();

  // 6. Dashboard
  initDashboard();
  if (document.getElementById("recentApplicationsList")) {
    fetchOrganizationApplications();
  }
  if (document.getElementById("opportunitiesTableBody")) {
    fetchOrganizationOpportunities();
  }
  if (
    document.getElementById("applicationsContainer") ||
    document.getElementById("applicationsTableBody")
  ) {
    fetchAllApplications();
  }
  if (document.getElementById("volunteerApplicationsList")) {
    fetchVolunteerApplications();
  }
  if (document.getElementById("savedOpportunitiesList")) {
    fetchSavedOpportunities();
  }

  // 7. Load opportunity for editing if edit param exists
  if (document.getElementById("postOpportunityForm")) {
    loadEditOpportunity();
  }
});
