document.addEventListener("DOMContentLoaded", function () {
  function loadComponent(elementId, componentPath) {
    fetch(componentPath)
      .then((response) => {
        if (!response.ok) throw new Error(`Failed to load ${componentPath}`);
        return response.text();
      })
      .then((data) => {
        const container = document.getElementById(elementId);
        if (container) {
          container.innerHTML = data;

          // If we just loaded the header, update auth UI
          if (elementId === "app-header") {
            const currentPath = window.location.pathname;

            // Highlight active link
            const navLinks = container.querySelectorAll(".nav-link");
            navLinks.forEach((link) => {
              if (
                link.getAttribute("href") === currentPath ||
                (currentPath === "/" && link.getAttribute("href") === "/")
              ) {
                link.classList.add("active");
              }
            });

            updateAuthUI();
          }
        }
      })
      .catch((err) => console.error(`Error loading ${elementId}:`, err));
  }

  loadComponent("app-header", "/frontend/components/header.html");
  loadComponent("app-footer", "/frontend/components/footer.html");

  function updateAuthUI() {
    const token = localStorage.getItem("token");
    const authButtons = document.getElementById("authButtons");

    if (token && authButtons) {
      const user = JSON.parse(localStorage.getItem("user") || "{}");
      let dashboardLink = "/frontend/auth/dashboard.html";

      if (user.role === "admin")
        dashboardLink = "/frontend/auth/admin-dashboard.html";
      if (user.role === "organization")
        dashboardLink = "/frontend/auth/organization-dashboard.html";

      authButtons.innerHTML = `
        <a href="${dashboardLink}" class="btn btn-outline-primary me-2">Dashboard</a>
        <button id="logoutBtn" class="btn btn-danger">Logout</button>
      `;

      // Re-attach logout listener
      // Re-attach logout listener
      // Use document body delegation or direct check to ensure it works even if element was just added
      setTimeout(() => {
        const logoutBtn = document.getElementById("logoutBtn");
        if (logoutBtn) {
          // Remove old listener to avoid duplicates if called multiple times
          const newBtn = logoutBtn.cloneNode(true);
          logoutBtn.parentNode.replaceChild(newBtn, logoutBtn);

          newBtn.addEventListener("click", function (e) {
            e.preventDefault();
            localStorage.removeItem("token");
            localStorage.removeItem("user");
            window.location.href = "/frontend/login.html";
          });
        }
      }, 100);
    }
  }
});
