import { API_BASE_URL, getAuthHeaders } from "./config.js";

export function initApplicationForm() {
  const applicationForm = document.getElementById("applicationForm");
  if (applicationForm) {
    // Populate user profile info when modal opens
    const appModal = document.getElementById("applicationModal");
    if (appModal) {
      appModal.addEventListener("show.bs.modal", populateUserProfile);
    }

    applicationForm.addEventListener("submit", async function (e) {
      e.preventDefault();

      // FEATURE RESTRICTION: Check verification before applying
      try {
        const token = localStorage.getItem("token");
        const res = await fetch("http://localhost:5000/api/users/profile", {
          headers: { "x-auth-token": token },
        });
        const user = await res.json();
        if (user.verificationStatus !== "approved") {
          alert(
            "Action Restricted: You must be a verified volunteer to apply for opportunities."
          );
          return;
        }
      } catch (err) {
        console.error(err);
      }

      // Find submit button (either inside form or with form attribute)
      const submitBtn =
        this.querySelector('button[type="submit"]') ||
        document.querySelector('button[form="applicationForm"]');
      const originalText = submitBtn ? submitBtn.innerHTML : "Submit";
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML =
          '<span class="spinner-border spinner-border-sm me-2"></span>Submitting...';
      }

      const formData = {
        opportunityId: document.getElementById("appOpportunityId").value,
        experience: document.getElementById("appExperience")?.value || "",
        skills: document.getElementById("appSkills")?.value || "",
      };

      try {
        const token = localStorage.getItem("token");
        if (!token) throw new Error("You must be logged in to apply");

        const response = await fetch(`${API_BASE_URL}/applications`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-auth-token": token,
          },
          body: JSON.stringify(formData),
        });

        const data = await response.json();

        if (response.ok) {
          alert("Application submitted successfully!");
          // Close modal
          const modal = bootstrap.Modal.getInstance(
            document.getElementById("applicationModal")
          );
          if (modal) modal.hide();
          this.reset();
        } else {
          throw new Error(data.message || "Application failed");
        }
      } catch (err) {
        alert(err.message);
      } finally {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.innerHTML = originalText;
        }
      }
    });
  }
}

// Populate user profile info in application form
function populateUserProfile() {
  try {
    const userStr = localStorage.getItem("user");
    if (!userStr) return;

    const user = JSON.parse(userStr);

    const nameEl = document.getElementById("appUserName");
    const emailEl = document.getElementById("appUserEmail");
    const phoneEl = document.getElementById("appUserPhone");
    const locationEl = document.getElementById("appUserLocation");

    if (nameEl) nameEl.textContent = user.name || "-";
    if (emailEl) emailEl.textContent = user.email || "-";
    if (phoneEl) phoneEl.textContent = user.phone || "-";
    if (locationEl) locationEl.textContent = user.location || "-";

    // CHECK VERIFICATION STATUS
    const submitBtn =
      document.querySelector('button[form="applicationForm"]') ||
      document.querySelector('#applicationForm button[type="submit"]');
    const modalBody =
      document.querySelector("#applicationForm .modal-body") ||
      document.querySelector("#applicationForm");

    // Remove existing warning if any
    const existingWarning = document.getElementById("appVerificationWarning");
    if (existingWarning) existingWarning.remove();

    if (user.verificationStatus !== "approved") {
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.title = "Verification Required";
      }

      const warning = document.createElement("div");
      warning.id = "appVerificationWarning";
      warning.className = "alert alert-warning mt-3";
      warning.innerHTML =
        '<i class="fas fa-lock me-2"></i><strong>Restricted:</strong> You must complete your account verification before applying.';

      // Insert before the form fields or at top of body
      if (modalBody) modalBody.insertBefore(warning, modalBody.firstChild);
    } else {
      // If approved, ensure button is enabled (in case it was disabled previously)
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.title = "";
      }
    }
  } catch (err) {
    console.error("Error populating user profile:", err);
  }
}

// Save opportunity for later
export async function saveForLater(opportunityId) {
  try {
    const token = localStorage.getItem("token");
    if (!token) {
      alert("You must be logged in to save opportunities");
      return;
    }

    const response = await fetch(
      `${API_BASE_URL}/opportunities/${opportunityId}/save`,
      {
        method: "POST",
        headers: { "x-auth-token": token },
      }
    );

    const data = await response.json();

    if (response.ok) {
      alert(data.message || "Opportunity saved!");
    } else {
      alert(data.message || "Failed to save opportunity");
    }
  } catch (err) {
    alert("Error saving opportunity");
  }
}

// Make saveForLater available globally
window.saveForLater = saveForLater;
