import { API_BASE_URL, getAuthHeaders } from "./config.js";

export function initDashboard() {
  // Mobile menu toggle - REMOVED (handled globally in script.js)

  // Verification Check for Volunteer Dashboard (ported logic)
  // Only run on dashboard pages to avoid crashing login/other pages
  if (window.location.pathname.includes("dashboard")) {
    checkVerificationStatus();
  }

  async function checkVerificationStatus() {
    try {
      const token = localStorage.getItem("token");
      const userStr = localStorage.getItem("user");
      const userObj = userStr ? JSON.parse(userStr) : {};

      if (userObj.role === "admin") return;

      const res = await fetch("http://localhost:5000/api/users/profile", {
        headers: { "x-auth-token": token },
      });

      if (res.ok) {
        const user = await res.json();
        // Update localStorage with fresh data to ensure consistent ID and Status
        localStorage.setItem(
          "user",
          JSON.stringify({
            ...user,
            id: user._id || user.id, // Ensure standardized 'id'
          })
        );

        // Update Sidebar & Header UI
        if (user.name) {
          const sidebarName =
            document.getElementById("sidebarName") ||
            document.getElementById("sidebarOrgName");
          if (sidebarName) sidebarName.textContent = user.name;
        }
        if (user.profilePicture) {
          const timestamp = new Date().getTime();
          const imageUrl = `http://localhost:5000${user.profilePicture}?t=${timestamp}`;
          document.querySelectorAll(".profile-avatar").forEach((img) => {
            img.src = imageUrl;
          });
        }

        if (
          user &&
          user.verificationStatus &&
          user.verificationStatus.toLowerCase() !== "approved"
        ) {
          const mainContent = document.querySelector(".main-content");
          const existingAlert = document.getElementById("verificationAlert");
          if (existingAlert) existingAlert.remove();

          const alertDiv = document.createElement("div");
          alertDiv.id = "verificationAlert";
          let alertClass = "alert-warning";
          let message =
            "Your account is pending verification. Some features may be limited.";

          const isOrg = user.role === "organization";
          const targetPage = isOrg
            ? "organization-profile.html"
            : "profile-settings.html";
          let linkDetails = ` <a href="${targetPage}" class="alert-link">Check Status</a>`;

          if (user.verificationStatus === "rejected") {
            alertClass = "alert-danger";
            message =
              "Your account verification was rejected. Please review feedback.";
          } else if (user.verificationStatus === "changes_requested") {
            alertClass = "alert-danger";
            message = "Changes requested on your verification. Please update.";
          }

          alertDiv.className = `alert ${alertClass} m-4 d-flex justify-content-between align-items-center shadow-sm`;
          alertDiv.innerHTML = `<div><i class="fas fa-exclamation-triangle me-2"></i><strong>Verification Required:</strong> ${message} ${linkDetails}</div>`;

          const navbar = document.querySelector(".dashboard-navbar");
          if (navbar && navbar.nextSibling) {
            navbar.parentNode.insertBefore(alertDiv, navbar.nextSibling);
          } else {
            mainContent.prepend(alertDiv);
          }

          disableRestrictedActions(user);
        }
      }
    } catch (err) {
      console.error(err);
    }
  }

  function disableRestrictedActions(user) {
    if (user.role === "organization") {
      const postBtns = document.querySelectorAll(
        'a[href="post-opportunity.html"], a[href="post-opportunity.html?mode=new"]'
      );
      postBtns.forEach((btn) => {
        btn.classList.add("disabled", "opacity-50");
        btn.style.pointerEvents = "none";
        btn.title = "Verification Required";
      });
    }
  }

  // Profile picture upload wrappers
  window.changeProfilePicture = function () {
    const input = document.getElementById("profilePicInput");
    if (input) input.click();
  };

  window.updateProfilePicture = function (event) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = function (e) {
        const profilePic = document.getElementById("profilePic");
        if (profilePic) profilePic.src = e.target.result;
      };
      reader.readAsDataURL(file);
    }
  };

  // Certificate upload
  window.openFileManager = function () {
    const input = document.getElementById("certificate");
    if (input) input.click();
  };

  const certificateInput = document.getElementById("certificate");
  if (certificateInput) {
    certificateInput.addEventListener("change", function () {
      if (this.files.length > 0) {
        const file = this.files[0];
        const list = document.getElementById("certificateList");
        if (list) {
          list.innerHTML += `<div class="alert alert-success alert-dismissible fade show mt-2" role="alert">
            <i class="fas fa-file-alt me-2"></i>${file.name} uploaded successfully!
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
          </div>`;
        }
      }
    });
  }

  window.editProfile = function () {
    alert(
      "Edit profile functionality would open a modal or redirect to edit page."
    );
  };

  // Organization Dashboard: Post Opportunity
  const postOpportunityForm = document.getElementById("postOpportunityForm");
  const saveDraftBtn = document.getElementById("saveDraftBtn");

  if (saveDraftBtn && postOpportunityForm) {
    saveDraftBtn.addEventListener("click", function () {
      const statusSelect = document.getElementById("status");
      if (statusSelect) statusSelect.value = "draft";
      postOpportunityForm.requestSubmit();
    });
  }

  if (postOpportunityForm) {
    postOpportunityForm.addEventListener("submit", async function (e) {
      e.preventDefault();

      // FEATURE RESTRICTION: Check verification before posting
      try {
        const token = localStorage.getItem("token");
        const res = await fetch("http://localhost:5000/api/users/profile", {
          headers: { "x-auth-token": token },
        });
        const user = await res.json();
        if (user.verificationStatus !== "approved") {
          alert(
            "Action Restricted: You must be a verified organization to post opportunities."
          );
          return;
        }
      } catch (err) {
        console.error(err);
      }

      const submitBtn = document.getElementById("postBtn");
      const originalBtnText = submitBtn
        ? submitBtn.innerHTML
        : "Post Opportunity";
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML =
          '<span class="spinner-border spinner-border-sm me-2"></span>Posting...';
      }

      const getVal = (id) => document.getElementById(id).value;

      const opportunityData = {
        title: getVal("title"),
        description: getVal("description"),
        detailedDescription: getVal("detailedDescription"),
        category: getVal("category"),
        location: getVal("location"),
        startDate: getVal("startDate"),
        endDate: getVal("endDate"),
        volunteersNeeded: getVal("volunteersNeeded"),
        duration: getVal("duration"),
        timeCommitment: getVal("hours"),
        status: getVal("status"),
        requiredSkills: getVal("skills")
          .split(",")
          .map((s) => s.trim())
          .filter((s) => s),
        responsibilities: getVal("responsibilities")
          .split("\n")
          .map((s) => s.trim())
          .filter((s) => s),
        requirements: getVal("requirements")
          .split("\n")
          .map((s) => s.trim())
          .filter((s) => s),
      };

      try {
        const token = localStorage.getItem("token");
        if (!token) {
          throw new Error("Please login to post an opportunity");
        }

        const isEdit = this.dataset.mode === "edit";
        const url = isEdit
          ? `${API_BASE_URL}/opportunities/${this.dataset.editId}`
          : `${API_BASE_URL}/opportunities`;
        const method = isEdit ? "PUT" : "POST";

        const response = await fetch(url, {
          method: method,
          headers: {
            "Content-Type": "application/json",
            "x-auth-token": token,
          },
          body: JSON.stringify(opportunityData),
        });

        const data = await response.json();

        if (response.ok) {
          alert(
            isEdit
              ? "Opportunity updated successfully!"
              : "Opportunity posted successfully!"
          );
          this.reset();

          // Reset edit state
          this.dataset.mode = "";
          this.dataset.editId = "";
          if (submitBtn) submitBtn.innerHTML = "Post Opportunity";

          // If edited, maybe stay here? But usually user wants to see list
          // Let's redirect to content manager tab if edit, or list page if new?
          // For now, let's just go to content manager tab since we have one
          const manageTabBtn = document.getElementById("manage-tab");
          if (manageTabBtn) {
            const tab = new bootstrap.Tab(manageTabBtn);
            tab.show();
            const { fetchOrganizationOpportunities } = await import(
              "./dashboard.js"
            );
            fetchOrganizationOpportunities();
          }
        } else {
          throw new Error(data.message || "Failed to post opportunity");
        }
      } catch (err) {
        alert(err.message);
      } finally {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.innerHTML = originalBtnText;
        }
      }
    });
  }
}

// Organization Dashboard: Fetch Recent Applications
export async function fetchOrganizationApplications() {
  const recentApplicationsList = document.getElementById(
    "recentApplicationsList"
  );
  if (!recentApplicationsList) return;

  try {
    const token = localStorage.getItem("token");
    if (!token) return;

    const response = await fetch(`${API_BASE_URL}/applications/organization`, {
      headers: { "x-auth-token": token },
    });
    const applications = await response.json();

    recentApplicationsList.innerHTML = "";

    if (applications.length > 0) {
      applications.forEach((app) => {
        recentApplicationsList.innerHTML += `
              <div class="applicant-card mb-3 p-3 border rounded">
                <div class="row align-items-center">
                  <div class="col-md-2">
                     <i class="fas fa-user-circle fa-2x text-muted"></i>
                  </div>
                  <div class="col-md-4">
                    <h6 class="mb-1">${
                      app.volunteerId ? app.volunteerId.name : "Unknown User"
                    }</h6>
                    <small class="text-muted">${
                      app.opportunityId
                        ? app.opportunityId.title
                        : "Unknown Opportunity"
                    }</small>
                  </div>
                  <div class="col-md-3">
                    <small class="text-muted">Applied: ${new Date(
                      app.appliedAt
                    ).toLocaleDateString()}</small>
                  </div>
                  <div class="col-md-3 text-end">
                    ${
                      app.status === "pending"
                        ? `
                    <div class="d-flex gap-2 justify-content-end">
                      <button class="btn btn-sm btn-success" onclick="updateAppStatus('${app._id}', 'accepted')">Accept</button>
                      <button class="btn btn-sm btn-outline-danger" onclick="updateAppStatus('${app._id}', 'rejected')">Reject</button>
                    </div>`
                        : `
                    <span class="badge bg-${
                      app.status === "accepted" ? "success" : "danger"
                    }">${app.status.toUpperCase()}</span>
                    `
                    }
                  </div>
                </div>
              </div>
          `;
      });
    } else {
      recentApplicationsList.innerHTML =
        '<p class="text-center text-muted">No applications received yet.</p>';
    }
  } catch (err) {
    console.error(err);
    recentApplicationsList.innerHTML =
      '<p class="text-danger text-center">Error loading applications.</p>';
  }
}

// Global helper for onclick handlers in HTML string
window.updateAppStatus = async function (appId, status) {
  if (!confirm(`Are you sure you want to ${status} this application?`)) return;

  try {
    const token = localStorage.getItem("token");
    const response = await fetch(
      `${API_BASE_URL}/applications/${appId}/status`,
      {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "x-auth-token": token,
        },
        body: JSON.stringify({ status }),
      }
    );

    if (response.ok) {
      // Refresh list
      const { fetchOrganizationApplications } = await import("./dashboard.js");
      fetchOrganizationApplications();
    } else {
      alert("Failed to update status");
    }
  } catch (err) {
    alert("Error updating status");
  }
};

// Organization Dashboard: Fetch Posted Opportunities for "Content Manager"
export async function fetchOrganizationOpportunities() {
  const tableBody = document.getElementById("opportunitiesTableBody");
  if (!tableBody) return;

  try {
    const token = localStorage.getItem("token");
    const userStr = localStorage.getItem("user");
    if (!token || !userStr) return;

    const user = JSON.parse(userStr);
    const response = await fetch(
      `${API_BASE_URL}/opportunities/organization/${user.id}`,
      {
        headers: { "x-auth-token": token },
      }
    );

    const opportunities = await response.json();

    tableBody.innerHTML = "";

    if (opportunities.length > 0) {
      opportunities.forEach((opp) => {
        const isActive = opp.status === "active";
        const statusBadge = isActive
          ? "bg-success-subtle text-success"
          : opp.status === "draft"
          ? "bg-warning-subtle text-warning"
          : "bg-secondary-subtle text-secondary";

        tableBody.innerHTML += `
                  <tr>
                        <td class="ps-4">
                          <div class="fw-bold">${opp.title}</div>
                          <small class="text-muted"><i class="fas fa-map-marker-alt me-1"></i>${
                            opp.location
                          }</small>
                        </td>
                        <td><span class="badge bg-light text-dark border">${
                          opp.category
                        }</span></td>
                        <td>${new Date(opp.createdAt).toLocaleDateString()}</td>
                        <td>
                           <div class="d-flex align-items-center">
                             <small class="text-muted">--</small>
                           </div>
                        </td>
                        <td><span class="badge ${statusBadge}">${opp.status.toUpperCase()}</span></td>
                        <td class="text-end pe-4">
                          <button class="btn btn-sm btn-outline-primary me-1" onclick="editOpportunity('${
                            opp._id
                          }')" title="Edit"><i class="fas fa-edit"></i></button>
                          
                          ${
                            isActive
                              ? `<button class="btn btn-sm btn-outline-warning me-1" onclick="updateOpportunityStatus('${opp._id}', 'draft')" title="Unpost (Draft)"><i class="fas fa-archive"></i></button>`
                              : `<button class="btn btn-sm btn-outline-success me-1" onclick="updateOpportunityStatus('${opp._id}', 'active')" title="Publish"><i class="fas fa-upload"></i></button>`
                          }
                          
                          <a href="../opportunity-details.html?id=${
                            opp._id
                          }" class="btn btn-sm btn-outline-secondary me-1" title="View"><i class="fas fa-eye"></i></a>
                          <button class="btn btn-sm btn-outline-danger" onclick="deleteOpportunity('${
                            opp._id
                          }')" title="Delete"><i class="fas fa-trash-alt"></i></button>
                        </td>
                      </tr>
                `;
      });
    } else {
      tableBody.innerHTML = `<tr><td colspan="6" class="text-center py-4">No opportunities posted yet.</td></tr>`;
    }
  } catch (err) {
    console.error("Error fetching my opportunities:", err);
    tableBody.innerHTML = `<tr><td colspan="6" class="text-center text-danger">Error loading opportunities.</td></tr>`;
  }
}

// Global Edit function - redirects to post-opportunity page with edit param
window.editOpportunity = async function (id) {
  // Redirect to post-opportunity page with edit param
  window.location.href = `post-opportunity.html?edit=${id}`;
};

// Load opportunity for editing (called on post-opportunity.html if edit param exists)
export async function loadEditOpportunity() {
  const params = new URLSearchParams(window.location.search);
  const editId = params.get("edit");

  if (!editId) return;

  try {
    const response = await fetch(`${API_BASE_URL}/opportunities/${editId}`);
    const opp = await response.json();

    if (!response.ok) throw new Error("Failed to fetch details");

    // Populate Form
    document.getElementById("title").value = opp.title;
    document.getElementById("category").value = opp.category;
    document.getElementById("description").value = opp.description;
    document.getElementById("detailedDescription").value =
      opp.detailedDescription || "";
    document.getElementById("responsibilities").value = opp.responsibilities
      ? opp.responsibilities.join("\n")
      : "";
    document.getElementById("skills").value = opp.requiredSkills
      ? opp.requiredSkills.join(", ")
      : "";
    document.getElementById("requirements").value = opp.requirements
      ? opp.requirements.join("\n")
      : "";
    document.getElementById("location").value = opp.location;
    document.getElementById("volunteersNeeded").value = opp.volunteersNeeded;
    document.getElementById("status").value = opp.status;
    document.getElementById("startDate").value = opp.startDate
      ? opp.startDate.split("T")[0]
      : "";
    document.getElementById("endDate").value = opp.endDate
      ? opp.endDate.split("T")[0]
      : "";
    document.getElementById("duration").value = opp.duration || "";
    document.getElementById("hours").value = opp.timeCommitment || "";

    // Change Button State
    const submitBtn = document.getElementById("postBtn");
    if (submitBtn) {
      submitBtn.innerHTML = "Update Opportunity";
    }

    // Store ID in form dataset for update logic
    const form = document.getElementById("postOpportunityForm");
    if (form) {
      form.dataset.editId = editId;
      form.dataset.mode = "edit";
    }
  } catch (err) {
    console.error(err);
    alert("Error loading opportunity for editing.");
  }
}

// Global Status Update function
window.updateOpportunityStatus = async function (id, status) {
  try {
    const token = localStorage.getItem("token");
    const response = await fetch(`${API_BASE_URL}/opportunities/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        "x-auth-token": token,
      },
      body: JSON.stringify({ status }),
    });

    if (response.ok) {
      const { fetchOrganizationOpportunities } = await import("./dashboard.js");
      fetchOrganizationOpportunities();
    } else {
      alert("Failed to update status.");
    }
  } catch (e) {
    alert("Error updating status.");
  }
};

// Global delete function
window.deleteOpportunity = async function (id) {
  if (!confirm("Are you sure you want to delete this opportunity?")) return;

  try {
    const token = localStorage.getItem("token");
    const response = await fetch(`${API_BASE_URL}/opportunities/${id}`, {
      method: "DELETE",
      headers: { "x-auth-token": token },
    });

    if (response.ok) {
      // refresh
      const { fetchOrganizationOpportunities } = await import("./dashboard.js");
      fetchOrganizationOpportunities();
    } else {
      alert("Failed to delete.");
    }
  } catch (e) {
    console.error(e);
    alert("Error deleting opportunity.");
  }
};

// Fetch ALL applications for organization (Applications Tab) - Mobile Optimized Cards
export async function fetchAllApplications() {
  const container = document.getElementById("applicationsContainer");
  // Also support old table-based layout for backwards compatibility
  const tableBody = document.getElementById("applicationsTableBody");
  const targetElement = container || tableBody;

  if (!targetElement) return;

  try {
    const token = localStorage.getItem("token");
    if (!token) return;

    const response = await fetch(`${API_BASE_URL}/applications/organization`, {
      headers: { "x-auth-token": token },
    });

    let applications = await response.json();

    // Apply filter if exists
    const filterSelect = document.getElementById("applicationStatusFilter");
    const filterValue = filterSelect ? filterSelect.value : "";

    if (filterValue) {
      applications = applications.filter((app) => app.status === filterValue);
    }

    targetElement.innerHTML = "";

    if (applications.length > 0) {
      applications.forEach((app) => {
        const statusClass =
          app.status === "accepted"
            ? "bg-success"
            : app.status === "rejected"
            ? "bg-danger"
            : "bg-warning text-dark";

        const statusIcon =
          app.status === "accepted"
            ? "fa-check-circle"
            : app.status === "rejected"
            ? "fa-times-circle"
            : "fa-clock";

        const volunteerData = JSON.stringify({
          id: app.volunteerId?._id || app.volunteerId?.id,
          name: app.volunteerId?.name || "Unknown",
          email: app.volunteerId?.email || "-",
          phone: app.volunteerId?.phone || "-",
          location: app.volunteerId?.location || "-",
          bio: app.volunteerId?.bio || "No bio provided",
          skills: app.volunteerId?.skills || [],
          experience: app.experience || "Not provided",
          appSkills: app.skills || "Not provided",
          opportunity: app.opportunityId?.title || "Unknown",
        }).replace(/'/g, "\\'");

        targetElement.innerHTML += `
          <div class="card border-0 shadow-sm mb-3" style="border-radius: 12px; overflow: hidden;">
            <div class="card-body p-0">
              <!-- Header with status -->
              <div class="d-flex align-items-center justify-content-between p-3 border-bottom" style="background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);">
                <div class="d-flex align-items-center">
                  <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 45px; height: 45px; font-size: 1.1rem;">
                    ${(app.volunteerId?.name || "U").charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <h6 class="mb-0 fw-bold">${
                      app.volunteerId?.name || "Unknown"
                    }</h6>
                    <small class="text-muted">${
                      app.volunteerId?.email || ""
                    }</small>
                  </div>
                </div>
                <span class="badge ${statusClass} px-3 py-2" style="border-radius: 20px;">
                  <i class="fas ${statusIcon} me-1"></i>${app.status.toUpperCase()}
                </span>
              </div>
              
              <!-- Body -->
              <div class="p-3">
                <div class="row g-2 mb-3">
                  <div class="col-12">
                    <div class="d-flex align-items-start">
                      <i class="fas fa-briefcase text-primary me-2 mt-1"></i>
                      <div>
                        <small class="text-muted d-block">Applied For</small>
                        <span class="fw-semibold">${
                          app.opportunityId?.title || "Unknown Opportunity"
                        }</span>
                      </div>
                    </div>
                  </div>
                  <div class="col-6">
                    <div class="d-flex align-items-center">
                      <i class="fas fa-calendar-alt text-secondary me-2"></i>
                      <div>
                        <small class="text-muted d-block">Applied On</small>
                        <span>${new Date(
                          app.appliedAt
                        ).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <!-- Action Buttons -->
                <div class="d-flex gap-2 flex-wrap">
                  <button class="btn btn-primary btn-sm flex-fill" style="border-radius: 8px;" onclick='viewVolunteerDetails(${volunteerData})'>
                    <i class="fas fa-eye me-1"></i> View Details
                  </button>
                  ${
                    app.status === "pending"
                      ? `
                      <button class="btn btn-success btn-sm" style="border-radius: 8px; min-width: 50px;" onclick="updateAppStatusRefresh('${app._id}', 'accepted')" title="Accept">
                        <i class="fas fa-check"></i>
                      </button>
                      <button class="btn btn-danger btn-sm" style="border-radius: 8px; min-width: 50px;" onclick="updateAppStatusRefresh('${app._id}', 'rejected')" title="Reject">
                        <i class="fas fa-times"></i>
                      </button>
                    `
                      : `
                      <button class="btn btn-outline-secondary btn-sm" style="border-radius: 8px;" onclick="updateAppStatusRefresh('${app._id}', 'pending')" title="Reset to Pending">
                        <i class="fas fa-undo me-1"></i> Reset
                      </button>
                    `
                  }
                </div>
              </div>
            </div>
          </div>
        `;
      });
    } else {
      targetElement.innerHTML = `
        <div class="text-center py-5">
          <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
          <p class="text-muted mb-0">No applications ${
            filterValue ? 'with status "' + filterValue + '"' : "received yet"
          }.</p>
        </div>
      `;
    }

    // Add filter listener if not already added
    if (filterSelect && !filterSelect.dataset.listenerAdded) {
      filterSelect.addEventListener("change", () => {
        fetchAllApplications();
      });
      filterSelect.dataset.listenerAdded = "true";
    }
  } catch (err) {
    console.error("Error fetching applications:", err);
    targetElement.innerHTML = `
      <div class="text-center py-4 text-danger">
        <i class="fas fa-exclamation-circle fa-2x mb-2"></i>
        <p class="mb-0">Error loading applications.</p>
      </div>
    `;
  }
}

// Global function for Applications Tab status update
window.updateAppStatusRefresh = async function (appId, status) {
  if (!confirm(`Are you sure you want to ${status} this application?`)) return;

  try {
    const token = localStorage.getItem("token");
    const response = await fetch(
      `${API_BASE_URL}/applications/${appId}/status`,
      {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "x-auth-token": token,
        },
        body: JSON.stringify({ status }),
      }
    );

    if (response.ok) {
      // Refresh both lists
      const { fetchAllApplications, fetchOrganizationApplications } =
        await import("./dashboard.js");
      fetchAllApplications();
      fetchOrganizationApplications();
    } else {
      alert("Failed to update status");
    }
  } catch (err) {
    alert("Error updating status");
  }
};

// Fetch Volunteer's own applications (Volunteer Dashboard)
export async function fetchVolunteerApplications() {
  const listContainer = document.getElementById("volunteerApplicationsList");
  if (!listContainer) return;

  try {
    const token = localStorage.getItem("token");
    const userStr = localStorage.getItem("user");
    if (!token || !userStr) return;

    const user = JSON.parse(userStr);
    const userId = user._id || user.id; // Support both id formats
    const response = await fetch(
      `${API_BASE_URL}/applications/volunteer/${userId}`,
      {
        headers: { "x-auth-token": token },
      }
    );

    const applications = await response.json();
    listContainer.innerHTML = "";

    if (applications.length > 0) {
      applications.forEach((app) => {
        const statusBadge =
          app.status === "accepted"
            ? "bg-success"
            : app.status === "rejected"
            ? "bg-danger"
            : "bg-warning text-dark";

        listContainer.innerHTML += `
          <div class="card mb-3 border-0 shadow-sm">
            <div class="card-body">
              <div class="d-flex justify-content-between align-items-start">
                <div>
                  <h6 class="mb-1">${
                    app.opportunityId?.title || "Unknown Opportunity"
                  }</h6>
                  <small class="text-muted">${
                    app.organizationId?.name || "Unknown Organization"
                  }</small>
                  <div class="mt-2">
                    <span class="badge ${statusBadge}">${app.status.toUpperCase()}</span>
                    <small class="text-muted ms-2">Applied ${new Date(
                      app.appliedAt
                    ).toLocaleDateString()}</small>
                  </div>
                </div>
                <div>
                  ${
                    app.status === "pending"
                      ? `<button class="btn btn-sm btn-outline-danger" onclick="cancelMyApplication('${app._id}')">
                          <i class="fas fa-times me-1"></i>Cancel
                        </button>`
                      : app.status === "accepted"
                      ? `<a href="../opportunity-details.html?id=${app.opportunityId?._id}" class="btn btn-sm btn-success">
                          <i class="fas fa-eye me-1"></i>View Details
                        </a>`
                      : ""
                  }
                </div>
              </div>
            </div>
          </div>
        `;
      });
    } else {
      listContainer.innerHTML = `<p class="text-center text-muted">You haven't applied to any opportunities yet.</p>`;
    }
  } catch (err) {
    console.error("Error fetching volunteer applications:", err);
    listContainer.innerHTML = `<p class="text-center text-danger">Error loading applications.</p>`;
  }
}

// Cancel/Withdraw application
window.cancelMyApplication = async function (appId) {
  if (!confirm("Are you sure you want to withdraw this application?")) return;

  try {
    const token = localStorage.getItem("token");
    const response = await fetch(`${API_BASE_URL}/applications/${appId}`, {
      method: "DELETE",
      headers: { "x-auth-token": token },
    });

    if (response.ok) {
      alert("Application withdrawn successfully.");
      const { fetchVolunteerApplications } = await import("./dashboard.js");
      fetchVolunteerApplications();
    } else {
      const data = await response.json();
      alert(data.message || "Failed to withdraw application.");
    }
  } catch (err) {
    alert("Error withdrawing application.");
  }
};

// View volunteer details modal (for organizations) - Full Profile with API fetch
window.viewVolunteerDetails = async function (basicInfo) {
  // Remove existing modal and backdrops completely
  const existingModal = document.getElementById("volunteerDetailsModal");
  if (existingModal) {
    const bsModal = bootstrap.Modal.getInstance(existingModal);
    if (bsModal) bsModal.dispose();
    existingModal.remove();
  }
  document.querySelectorAll(".modal-backdrop").forEach((el) => el.remove());
  document.body.classList.remove("modal-open");
  document.body.style.overflow = "";
  document.body.style.paddingRight = "";

  // Create modal with updateable content area
  const modalHtml = `
    <div class="modal fade" id="volunteerDetailsModal" tabindex="-1">
      <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content border-0 shadow-lg" style="border-radius: 16px; overflow: hidden; max-height: 90vh;">
          <div id="volunteerModalInner" style="display: flex; flex-direction: column; max-height: 85vh; overflow-y: auto;">
            <div class="modal-body text-center py-5">
              <div class="spinner-border text-primary mb-3" role="status"></div>
              <p class="mb-0">Loading volunteer profile...</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;

  document.body.insertAdjacentHTML("beforeend", modalHtml);
  const modalEl = document.getElementById("volunteerDetailsModal");
  const modal = new bootstrap.Modal(modalEl);
  modal.show();

  try {
    // Fetch full volunteer data from API
    const token = localStorage.getItem("token");
    const response = await fetch(
      `${API_BASE_URL}/users/volunteer/${basicInfo.id}/full`,
      {
        headers: { "x-auth-token": token },
      }
    );

    if (!response.ok) {
      throw new Error("Failed to fetch volunteer data");
    }

    const volunteer = await response.json();

    // Build skills HTML
    const skillsHtml =
      Array.isArray(volunteer.skills) && volunteer.skills.length > 0
        ? volunteer.skills
            .map(
              (s) =>
                `<span class="badge bg-primary-subtle text-primary me-1 mb-1">${s}</span>`
            )
            .join("")
        : '<span class="text-muted">None listed</span>';

    // Build qualifications HTML
    let qualificationsHtml =
      '<p class="text-muted mb-0">No qualifications added</p>';
    if (volunteer.qualifications && volunteer.qualifications.length > 0) {
      qualificationsHtml = volunteer.qualifications
        .map(
          (q) => `
        <div class="bg-white border rounded-3 p-3 mb-2">
          <div class="d-flex justify-content-between align-items-start">
            <div>
              <h6 class="mb-1">${q.type || "Qualification"}</h6>
              <small class="text-muted">${q.university} • ${
            q.completionYear
          }</small>
            </div>
            <span class="badge bg-info-subtle text-info">${q.marks}${
            q.grade ? " (" + q.grade + ")" : ""
          }</span>
          </div>
          ${
            q.documentUrl
              ? `<a href="${q.documentUrl}" target="_blank" class="btn btn-sm btn-outline-primary mt-2"><i class="fas fa-file-alt me-1"></i>View Certificate</a>`
              : ""
          }
        </div>
      `
        )
        .join("");
    }

    // Build documents HTML
    let documentsHtml = '<p class="text-muted mb-0">No documents uploaded</p>';
    if (volunteer.documents && volunteer.documents.length > 0) {
      documentsHtml = volunteer.documents
        .map(
          (doc) => `
        <a href="${doc.url}" target="_blank" class="d-flex align-items-center bg-light rounded-3 p-2 mb-2 text-decoration-none text-dark">
          <i class="fas fa-file-pdf text-danger me-2"></i>
          <span class="text-truncate flex-grow-1">${doc.name}</span>
          <i class="fas fa-external-link-alt text-muted"></i>
        </a>
      `
        )
        .join("");
    }

    // Build inner content only (no outer modal wrapper)
    const contentHtml = `
      <!-- Gradient Header -->
      <div class="modal-header border-0 text-white py-3" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
        <div class="d-flex align-items-center">
                ${
                  volunteer.profilePicture
                    ? `<img src="${volunteer.profilePicture}" class="rounded-circle me-3" style="width: 60px; height: 60px; object-fit: cover; border: 3px solid white;">`
                    : `<div class="bg-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 60px; height: 60px;">
                      <span class="fw-bold" style="font-size: 1.5rem; color: #667eea;">${(
                        volunteer.name || "U"
                      )
                        .charAt(0)
                        .toUpperCase()}</span>
                    </div>`
                }
                <div>
                  <h5 class="modal-title mb-1 fw-bold">${volunteer.name}</h5>
                  <div class="d-flex gap-2">
                    ${
                      volunteer.isVerified
                        ? '<span class="badge bg-success"><i class="fas fa-check-circle me-1"></i>Verified</span>'
                        : '<span class="badge bg-secondary">Unverified</span>'
                    }
                    ${
                      volunteer.stats
                        ? `<span class="badge bg-light text-dark">${
                            volunteer.stats.acceptedApplications || 0
                          } projects completed</span>`
                        : ""
                    }
                  </div>
                </div>
              </div>
              <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            
            <div class="modal-body p-0">
              <!-- Contact Info Cards -->
              <div class="p-3 bg-light border-bottom">
                <div class="row g-2">
                  <div class="col-6 col-md-3">
                    <div class="bg-white rounded-3 p-2 text-center h-100">
                      <i class="fas fa-envelope text-primary mb-1" style="font-size: 1rem;"></i>
                      <div class="small text-muted">Email</div>
                      <div class="fw-semibold text-break" style="font-size: 0.75rem;">${
                        volunteer.email || "-"
                      }</div>
                    </div>
                  </div>
                  <div class="col-6 col-md-3">
                    <div class="bg-white rounded-3 p-2 text-center h-100">
                      <i class="fas fa-phone text-success mb-1" style="font-size: 1rem;"></i>
                      <div class="small text-muted">Phone</div>
                      <div class="fw-semibold" style="font-size: 0.75rem;">${
                        volunteer.phone || "-"
                      }</div>
                    </div>
                  </div>
                  <div class="col-6 col-md-3">
                    <div class="bg-white rounded-3 p-2 text-center h-100">
                      <i class="fas fa-map-marker-alt text-danger mb-1" style="font-size: 1rem;"></i>
                      <div class="small text-muted">Location</div>
                      <div class="fw-semibold" style="font-size: 0.75rem;">${
                        volunteer.location || "-"
                      }</div>
                    </div>
                  </div>
                  <div class="col-6 col-md-3">
                    <div class="bg-white rounded-3 p-2 text-center h-100">
                      <i class="fas fa-id-card text-info mb-1" style="font-size: 1rem;"></i>
                      <div class="small text-muted">CNIC</div>
                      <div class="fw-semibold" style="font-size: 0.75rem;">${
                        volunteer.cnicNumber || "-"
                      }</div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div class="p-3">
                <!-- Bio -->
                <div class="mb-4">
                  <h6 class="text-dark mb-2"><i class="fas fa-user-circle me-2 text-primary"></i>About</h6>
                  <p class="mb-0 text-secondary bg-light rounded-3 p-3" style="font-size: 0.9rem;">${
                    volunteer.bio || "No bio provided"
                  }</p>
                </div>
                
                <!-- Detailed Bio -->
                ${
                  volunteer.detailedBio
                    ? `
                  <div class="mb-4">
                    <h6 class="text-dark mb-2"><i class="fas fa-book-open me-2 text-info"></i>Detailed Bio</h6>
                    <p class="mb-0 text-secondary bg-light rounded-3 p-3" style="font-size: 0.9rem;">${volunteer.detailedBio}</p>
                  </div>
                `
                    : ""
                }
                
                <!-- Skills -->
                <div class="mb-4">
                  <h6 class="text-dark mb-2"><i class="fas fa-star me-2 text-warning"></i>Skills</h6>
                  <div>${skillsHtml}</div>
                </div>
                
                <!-- Qualifications -->
                <div class="mb-4">
                  <h6 class="text-dark mb-2"><i class="fas fa-graduation-cap me-2 text-success"></i>Qualifications</h6>
                  <div class="bg-light rounded-3 p-2">
                    ${qualificationsHtml}
                  </div>
                </div>
                
                <!-- Documents -->
                <div class="mb-4">
                  <h6 class="text-dark mb-2"><i class="fas fa-folder-open me-2 text-danger"></i>Uploaded Documents</h6>
                  <div class="bg-light rounded-3 p-2">
                    ${documentsHtml}
                  </div>
                </div>
                
                <!-- Application Details (from original data) -->
                ${
                  basicInfo.opportunity
                    ? `
                  <div class="border-top pt-3 mt-3">
                    <h6 class="text-dark mb-3"><i class="fas fa-file-alt me-2 text-success"></i>Application for: ${
                      basicInfo.opportunity
                    }</h6>
                    
                    <div class="mb-3">
                      <div class="small text-muted mb-1"><i class="fas fa-briefcase me-1"></i>Relevant Experience</div>
                      <div class="bg-success bg-opacity-10 rounded-3 p-3 text-dark" style="font-size: 0.9rem;">${
                        basicInfo.experience || "Not provided"
                      }</div>
                    </div>
                    
                    <div>
                      <div class="small text-muted mb-1"><i class="fas fa-tools me-1"></i>Skills Offered</div>
                      <div class="bg-primary bg-opacity-10 rounded-3 p-3 text-dark" style="font-size: 0.9rem;">${
                        basicInfo.appSkills || "Not provided"
                      }</div>
                    </div>
                  </div>
                `
                    : ""
                }
              </div>
            </div>
            
            <div class="modal-footer border-0 bg-light py-2">
              <button type="button" class="btn btn-secondary btn-sm px-4" data-bs-dismiss="modal">
                <i class="fas fa-times me-1"></i>Close
              </button>
            </div>
    `;

    // Simply update the inner content - no modal swapping needed
    const innerContainer = document.getElementById("volunteerModalInner");
    if (innerContainer) {
      innerContainer.innerHTML = contentHtml;
    }
  } catch (err) {
    console.error("Error fetching volunteer details:", err);
    const innerContainer = document.getElementById("volunteerModalInner");
    if (innerContainer) {
      innerContainer.innerHTML = `
        <div class="modal-body text-center py-5">
          <i class="fas fa-exclamation-circle text-danger fa-3x mb-3"></i>
          <p class="mb-3">Failed to load volunteer profile.</p>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div>
      `;
    }
  }
};

// Fetch saved opportunities for volunteer dashboard
export async function fetchSavedOpportunities() {
  const container = document.getElementById("savedOpportunitiesList");
  if (!container) return;

  try {
    const token = localStorage.getItem("token");
    if (!token) return;

    const response = await fetch(`${API_BASE_URL}/opportunities/user/saved`, {
      headers: { "x-auth-token": token },
    });

    const saved = await response.json();
    container.innerHTML = "";

    if (saved && saved.length > 0) {
      saved.forEach((opp) => {
        container.innerHTML += `
          <div class="card mb-2 border-0 shadow-sm">
            <div class="card-body py-2">
              <div class="d-flex justify-content-between align-items-center">
                <div>
                  <h6 class="mb-0">${opp.title}</h6>
                  <small class="text-muted">${
                    opp.organizationId?.name || "Unknown Org"
                  } • ${opp.location}</small>
                </div>
                <div>
                  <a href="../opportunity-details.html?id=${
                    opp._id
                  }" class="btn btn-sm btn-primary me-1">View</a>
                  <button class="btn btn-sm btn-outline-danger" onclick="unsaveOpportunity('${
                    opp._id
                  }')">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>
        `;
      });
    } else {
      container.innerHTML = `<p class="text-center text-muted">No saved opportunities.</p>`;
    }
  } catch (err) {
    console.error("Error fetching saved opportunities:", err);
    container.innerHTML = `<p class="text-center text-danger">Error loading saved opportunities.</p>`;
  }
}

// Unsave opportunity
window.unsaveOpportunity = async function (oppId) {
  try {
    const token = localStorage.getItem("token");
    const response = await fetch(
      `${API_BASE_URL}/opportunities/${oppId}/save`,
      {
        method: "DELETE",
        headers: { "x-auth-token": token },
      }
    );

    if (response.ok) {
      const { fetchSavedOpportunities } = await import("./dashboard.js");
      fetchSavedOpportunities();
    } else {
      alert("Failed to unsave opportunity");
    }
  } catch (err) {
    alert("Error unsaving opportunity");
  }
};
