import { API_BASE_URL } from "./config.js";

// Pagination state
let currentPage = 1;
const ITEMS_PER_PAGE = 10;
let totalPages = 1;
let totalOpportunities = 0;

export async function loadOpportunities(page = 1) {
  const opportunitiesGrid = document.getElementById("opportunitiesGrid");
  if (!opportunitiesGrid) return;

  currentPage = page;

  opportunitiesGrid.innerHTML = `
        <div class="col-12 text-center py-5">
          <div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Loading...</span>
          </div>
        </div>`;

  try {
    // Build Query
    const search = document.getElementById("searchInput")?.value || "";
    const location = document.getElementById("locationFilter")?.value || "";

    const params = new URLSearchParams();
    if (search) params.append("search", search);
    if (location) params.append("location", location);
    params.append("page", page);
    params.append("limit", ITEMS_PER_PAGE);

    const response = await fetch(
      `${API_BASE_URL}/opportunities?${params.toString()}`
    );
    const data = await response.json();

    opportunitiesGrid.innerHTML = "";
    totalOpportunities = data.total || 0;
    totalPages = data.totalPages || 1;

    // Update total count display
    const countEl = document.getElementById("totalOpportunitiesCount");
    if (countEl) countEl.textContent = totalOpportunities;

    if (data.opportunities && data.opportunities.length > 0) {
      data.opportunities.forEach((opp) => {
        opportunitiesGrid.innerHTML += `
                    <div class="col-md-6 col-lg-4 mb-4">
                      <div class="card h-100 shadow-sm border-0 opportunity-card">
                        <div class="card-body">
                          <div class="d-flex justify-content-between align-items-start mb-3">
                            <span class="badge bg-primary rounded-pill">${
                              opp.category
                            }</span>
                            <small class="text-muted"><i class="far fa-clock me-1"></i>${new Date(
                              opp.createdAt
                            ).toLocaleDateString()}</small>
                          </div>
                          <h5 class="card-title fw-bold text-dark">${
                            opp.title
                          }</h5>
                          <p class="card-text text-muted mb-3">${
                            opp.organizationId?.name || "Organization"
                          }</p>
                          <div class="d-flex align-items-center mb-2 text-secondary">
                            <i class="fas fa-map-marker-alt me-2"></i> ${
                              opp.location
                            }
                          </div>
                          <div class="d-flex align-items-center mb-3 text-secondary">
                            <i class="fas fa-calendar-alt me-2"></i> ${new Date(
                              opp.startDate
                            ).toLocaleDateString()}
                          </div>
                          <p class="card-text text-muted small">${opp.description.substring(
                            0,
                            100
                          )}...</p>
                        </div>
                        <div class="card-footer bg-white border-top-0 pb-4">
                           <a href="opportunity-details.html?id=${
                             opp._id
                           }" class="btn btn-outline-primary w-100">View Details</a>
                        </div>
                      </div>
                    </div>
                  `;
      });
    } else {
      opportunitiesGrid.innerHTML = `
                <div class="col-12 text-center py-5">
                   <div class="text-muted">
                     <i class="fas fa-search fa-3x mb-3"></i>
                     <h5>No opportunities found matching your criteria.</h5>
                     <p>Try adjusting your search terms.</p>
                   </div>
                </div>`;
    }

    // Update pagination
    updatePagination();
  } catch (err) {
    console.error("Error fetching opportunities:", err);
    document.getElementById(
      "opportunitiesGrid"
    ).innerHTML = `<div class="col-12 text-center text-danger">Error loading opportunities.</div>`;
  }
}

function updatePagination() {
  const paginationNav = document.getElementById("paginationNav");
  const prevPageItem = document.getElementById("prevPageItem");
  const nextPageItem = document.getElementById("nextPageItem");
  const pageInfo = document.getElementById("pageInfo");

  if (!paginationNav) return;

  // Only show pagination if more than 10 opportunities
  if (totalOpportunities > ITEMS_PER_PAGE) {
    paginationNav.style.display = "block";

    // Update page info
    if (pageInfo) pageInfo.textContent = `Page ${currentPage} of ${totalPages}`;

    // Update prev button
    if (prevPageItem) {
      if (currentPage <= 1) {
        prevPageItem.classList.add("disabled");
      } else {
        prevPageItem.classList.remove("disabled");
      }
    }

    // Update next button
    if (nextPageItem) {
      if (currentPage >= totalPages) {
        nextPageItem.classList.add("disabled");
      } else {
        nextPageItem.classList.remove("disabled");
      }
    }
  } else {
    paginationNav.style.display = "none";
  }
}

// Load featured opportunities for homepage
export async function loadFeaturedOpportunities() {
  const container = document.getElementById("featuredOpportunities");
  if (!container) return;

  try {
    const response = await fetch(
      `${API_BASE_URL}/opportunities?limit=3&sort=-views`
    );
    const data = await response.json();

    container.innerHTML = "";

    if (data.opportunities && data.opportunities.length > 0) {
      data.opportunities.forEach((opp) => {
        container.innerHTML += `
        <div class="col-lg-4 col-md-6">
          <div class="card h-100 opportunity-card">
            <div class="card-body">
              <div class="d-flex align-items-center mb-3">
                <span class="badge bg-primary rounded-pill me-2">${
                  opp.category
                }</span>
                <small class="text-muted ms-auto">${opp.location}</small>
              </div>
              <h5 class="card-title fw-bold">${opp.title}</h5>
              <p class="card-text text-muted small mb-3">${opp.description.substring(
                0,
                100
              )}...</p>
              
              <div class="d-flex justify-content-between align-items-center mt-auto">
                <div class="d-flex align-items-center">
                   ${
                     opp.organizationId && opp.organizationId.profilePicture
                       ? `<img src="${
                           opp.organizationId.profilePicture.startsWith("/")
                             ? API_BASE_URL.replace("/api", "") +
                               opp.organizationId.profilePicture
                             : opp.organizationId.profilePicture
                         }" class="rounded-circle me-2" width="24" height="24">`
                       : '<i class="fas fa-building text-muted me-2"></i>'
                   }
                   <small class="text-muted text-truncate" style="max-width: 120px;">${
                     opp.organizationId?.name || "Organization"
                   }</small>
                </div>
                <small class="text-primary fw-bold">${opp.duration}</small>
              </div>
            </div>
            <div class="card-footer bg-white border-top-0 pt-0 pb-3">
              <a href="frontend/opportunity-details.html?id=${
                opp._id
              }" class="btn btn-outline-primary w-100">View Details</a>
            </div>
          </div>
        </div>
        `;
      });
    } else {
      container.innerHTML = `
        <div class="col-12 text-center text-muted">
          <p>No featured opportunities available at the moment.</p>
        </div>
      `;
    }
  } catch (error) {
    console.error("Error loading featured opportunities:", error);
    container.innerHTML = `
      <div class="col-12 text-center text-danger">
        <p>Failed to load opportunities.</p>
      </div>
    `;
  }
}

export function initOpportunities() {
  const opportunitiesGrid = document.getElementById("opportunitiesGrid");
  if (opportunitiesGrid) {
    loadOpportunities(1);

    const searchBtn = document.getElementById("searchBtn");
    if (searchBtn)
      searchBtn.addEventListener("click", () => loadOpportunities(1));

    const searchInput = document.getElementById("searchInput");
    if (searchInput) {
      searchInput.addEventListener("keyup", (e) => {
        if (e.key === "Enter") loadOpportunities(1);
      });
    }

    // Pagination button handlers
    const prevBtn = document.getElementById("prevPageBtn");
    const nextBtn = document.getElementById("nextPageBtn");

    if (prevBtn) {
      prevBtn.addEventListener("click", (e) => {
        e.preventDefault();
        if (currentPage > 1) {
          loadOpportunities(currentPage - 1);
          window.scrollTo({ top: 200, behavior: "smooth" });
        }
      });
    }

    if (nextBtn) {
      nextBtn.addEventListener("click", (e) => {
        e.preventDefault();
        if (currentPage < totalPages) {
          loadOpportunities(currentPage + 1);
          window.scrollTo({ top: 200, behavior: "smooth" });
        }
      });
    }
  }
}

export async function fetchOpportunityDetails() {
  const params = new URLSearchParams(window.location.search);
  const oppId = params.get("id");

  if (!oppId) return;

  try {
    const response = await fetch(`${API_BASE_URL}/opportunities/${oppId}`);
    const opportunity = await response.json();

    if (response.ok) {
      document.getElementById("oppTitle").textContent = opportunity.title;
      document.getElementById("oppDescriptionHero").textContent =
        opportunity.description;
      document.getElementById("oppDetailedDescription").textContent =
        opportunity.detailedDescription || opportunity.description; // Fallback to short desc if detailed is missing
      document.getElementById("oppCategory").textContent =
        opportunity.category.charAt(0).toUpperCase() +
        opportunity.category.slice(1);

      const statusSpan = document.getElementById("oppStatus");
      statusSpan.textContent =
        opportunity.status === "active" ? "Active" : "Closed";
      statusSpan.className = `urgency-badge ms-2 ${
        opportunity.status === "active" ? "bg-success" : "bg-secondary"
      }`;

      document.getElementById("oppLocation").textContent = opportunity.location;
      document.getElementById("oppDuration").textContent =
        opportunity.duration || "N/A";
      document.getElementById(
        "oppVolunteers"
      ).textContent = `${opportunity.volunteersNeeded} Volunteers Needed`;

      // Render Lists (Responsibilities)
      const respContainer = document.getElementById("oppResponsibilities");
      if (
        respContainer &&
        opportunity.responsibilities &&
        opportunity.responsibilities.length > 0
      ) {
        respContainer.innerHTML = opportunity.responsibilities
          .map((r) => `<li>${r}</li>`)
          .join("");
      } else if (respContainer) {
        respContainer.innerHTML = "<li>Contact organization for details.</li>";
      }

      // Render Lists (Requirements)
      const reqContainer = document.getElementById("oppRequirements");
      if (
        reqContainer &&
        opportunity.requirements &&
        opportunity.requirements.length > 0
      ) {
        reqContainer.innerHTML = opportunity.requirements
          .map(
            (r) =>
              `<div class="requirement-item d-flex align-items-start mb-2"><i class="fas fa-check-circle text-success mt-1 me-2"></i><span>${r}</span></div>`
          )
          .join("");
      }

      // Render Required Skills
      const skillsContainer = document.getElementById("oppSkillsTags");
      if (
        skillsContainer &&
        opportunity.requiredSkills &&
        opportunity.requiredSkills.length > 0
      ) {
        skillsContainer.innerHTML = opportunity.requiredSkills
          .map(
            (s) =>
              `<span class="badge bg-primary-subtle text-primary border me-1 mb-1 px-3 py-2">${s}</span>`
          )
          .join("");
      }

      // Render Timeline
      const timelineContainer = document.getElementById("oppTimeline");
      if (timelineContainer) {
        let timelineHTML = "";

        // Add overall duration at top if dates exist
        if (opportunity.startDate && opportunity.endDate) {
          const startFormatted = new Date(
            opportunity.startDate
          ).toLocaleDateString("en-US", {
            month: "short",
            day: "numeric",
            year: "numeric",
          });
          const endFormatted = new Date(opportunity.endDate).toLocaleDateString(
            "en-US",
            { month: "short", day: "numeric", year: "numeric" }
          );
          timelineHTML += `
                <div class="alert alert-info d-flex align-items-center mb-3">
                    <i class="fas fa-calendar-check me-2"></i>
                    <strong>Program Duration:</strong>&nbsp;${startFormatted} - ${endFormatted}
                </div>
            `;
        }

        // Add detailed timeline items
        if (
          opportunity.programTimeline &&
          opportunity.programTimeline.length > 0
        ) {
          timelineHTML += opportunity.programTimeline
            .map(
              (t) => `
              <div class="timeline-item position-relative pb-4 ps-4 border-start border-2 border-light">
                <i class="fas fa-dot-circle text-primary position-absolute top-0 start-0 translate-middle bg-white" style="margin-top: 2px;"></i>
                <div class="d-flex justify-content-between align-items-center mb-1">
                    <h6 class="fw-bold mb-0 text-dark">${t.title}</h6>
                    ${
                      t.date
                        ? `<span class="badge bg-light text-dark border">${t.date}</span>`
                        : ""
                    }
                </div>
                <p class="text-muted small mb-0">${t.description}</p>
              </div>
          `
            )
            .join("");
        } else {
          timelineHTML += `<div class="p-3 bg-light rounded text-center text-muted">Detailed timeline to be announced.</div>`;
        }

        timelineContainer.innerHTML = timelineHTML;
      }

      // Render Logistics
      const locationList = document.getElementById("oppLocationList");
      if (locationList) {
        let locs = [
          `<li class="mb-2 d-flex align-items-center"><i class="fas fa-map-marker-alt text-danger me-2 fa-fw"></i>${opportunity.location}</li>`,
        ];
        if (
          opportunity.location.toLowerCase().includes("hybrid") ||
          opportunity.location.toLowerCase().includes("remote")
        ) {
          locs.push(
            `<li class="mb-2 d-flex align-items-center"><i class="fas fa-laptop text-info me-2 fa-fw"></i>Virtual participation available</li>`
          );
        }
        // Add seeded locations logic or generic placeholders if needed, but primarily use DB data
        locationList.innerHTML = locs.join("");
        locationList.classList.add("list-unstyled", "mb-0");
      }

      const scheduleList = document.getElementById("oppScheduleList");
      if (scheduleList) {
        scheduleList.innerHTML = `
            <li class="mb-2 d-flex align-items-center"><i class="fas fa-calendar-alt text-primary me-2 fa-fw"></i>Start: ${new Date(
              opportunity.startDate
            ).toLocaleDateString()}</li>
            <li class="mb-2 d-flex align-items-center"><i class="fas fa-hourglass-half text-warning me-2 fa-fw"></i>Duration: ${
              opportunity.duration || "Flexible"
            }</li>
             <li class="mb-2 d-flex align-items-center"><i class="fas fa-clock text-success me-2 fa-fw"></i>${
               opportunity.timeCommitment || "Flexible hours"
             }</li>
          `;
        scheduleList.classList.add("list-unstyled", "mb-0");
      }

      document.getElementById("appOpportunityId").value = opportunity._id;

      // ===== POPULATE ORGANIZATION INFO =====
      const org = opportunity.organizationId;
      if (org) {
        const orgNameEl = document.getElementById("orgName");
        if (orgNameEl) orgNameEl.textContent = org.name || "Organization";

        const orgDescEl = document.getElementById("orgDescription");
        if (orgDescEl)
          orgDescEl.textContent =
            org.description ||
            org.missionStatement ||
            "No description available";

        const orgPicEl = document.getElementById("orgProfilePicture");
        if (orgPicEl && org.profilePicture) {
          orgPicEl.src = org.profilePicture.startsWith("/")
            ? `${API_BASE_URL.replace("/api", "")}${org.profilePicture}`
            : org.profilePicture;
        }

        const orgEstEl = document.getElementById("orgEstablished");
        if (orgEstEl) orgEstEl.textContent = org.established || "-";

        const orgLocEl = document.getElementById("orgLocation");
        if (orgLocEl) orgLocEl.textContent = org.location || "-";

        const orgEmailEl = document.getElementById("orgEmail");
        if (orgEmailEl) {
          orgEmailEl.textContent = org.email || "-";
          orgEmailEl.href = `mailto:${org.email}`;
        }

        const orgWebEl = document.getElementById("orgWebsite");
        if (orgWebEl && org.website) {
          orgWebEl.textContent = org.website.replace(/https?:\/\//, "");
          orgWebEl.href = org.website.startsWith("http")
            ? org.website
            : `https://${org.website}`;
        }

        const viewOrgBtn = document.getElementById("viewOrgProfileBtn");
        if (viewOrgBtn) {
          viewOrgBtn.href = `organization-profile-public.html?id=${org._id}`;
        }
      }

      // ===== POPULATE OPPORTUNITY STATS =====
      if (opportunity.stats) {
        const stats = opportunity.stats;

        const viewsEl = document.getElementById("statViews");
        if (viewsEl) viewsEl.textContent = stats.views || 0;

        const approvedEl = document.getElementById("statApproved");
        if (approvedEl)
          approvedEl.textContent = stats.approvedApplications || 0;

        const remainingEl = document.getElementById("statRemaining");
        if (remainingEl) remainingEl.textContent = stats.remainingSeats || 0;

        const seatsTextEl = document.getElementById("statSeatsText");
        if (seatsTextEl)
          seatsTextEl.textContent = `${stats.approvedApplications}/${stats.totalNeeded}`;

        const progressEl = document.getElementById("statSeatsProgress");
        if (progressEl) {
          const percentage =
            stats.totalNeeded > 0
              ? (stats.approvedApplications / stats.totalNeeded) * 100
              : 0;
          progressEl.style.width = `${Math.min(100, percentage)}%`;
          if (percentage >= 100) {
            progressEl.classList.remove("bg-success");
            progressEl.classList.add("bg-danger");
          }
        }

        // Show warning if seats are full
        const seatsFullEl = document.getElementById("seatsFull");
        if (seatsFullEl && stats.isFull) {
          seatsFullEl.classList.remove("d-none");
          // Disable apply button
          const applyBtns = document.querySelectorAll(
            '[data-bs-target="#applicationModal"]'
          );
          applyBtns.forEach((btn) => {
            btn.disabled = true;
            btn.classList.add("disabled");
            btn.innerHTML = '<i class="fas fa-ban me-2"></i>No Seats Available';
          });
        }
      }

      // ===== POPULATE SIMILAR OPPORTUNITIES =====
      const similarContainer = document.getElementById(
        "similarOpportunitiesContainer"
      );
      if (similarContainer && opportunity.similarOpportunities) {
        if (opportunity.similarOpportunities.length > 0) {
          const categoryIcons = {
            education: "fa-graduation-cap",
            environment: "fa-leaf",
            health: "fa-heartbeat",
            community: "fa-users",
            animals: "fa-paw",
            "disaster-relief": "fa-hands-helping",
            other: "fa-star",
          };

          similarContainer.innerHTML = opportunity.similarOpportunities
            .map((sim) => {
              const icon =
                categoryIcons[sim.category] || "fa-hand-holding-heart";
              const orgName = sim.organizationId?.name || "Organization";
              return `
              <div class="similar-opportunity mb-3">
                <div class="p-3 border rounded bg-light">
                  <div class="d-flex align-items-start">
                    <i class="fas ${icon} text-primary me-3 mt-1"></i>
                    <div>
                      <h6 class="mb-1">${sim.title}</h6>
                      <small class="text-muted d-block">${orgName} • ${sim.location}</small>
                      <a href="opportunity-details.html?id=${sim._id}" class="btn btn-sm btn-outline-primary mt-2">View Details</a>
                    </div>
                  </div>
                </div>
              </div>
            `;
            })
            .join("");
        } else {
          similarContainer.innerHTML = `
            <div class="text-center text-muted py-3">
              <i class="fas fa-search"></i>
              <p class="mb-0 small">No similar opportunities found</p>
            </div>
          `;
        }
      }

      // Add save for later button handler
      const saveBtn = document.getElementById("saveOpportunity");
      if (saveBtn) {
        saveBtn.addEventListener("click", async function () {
          const token = localStorage.getItem("token");
          if (!token) {
            alert("Please login to save opportunities");
            return;
          }

          this.disabled = true;
          this.innerHTML =
            '<span class="spinner-border spinner-border-sm me-2"></span>Saving...';

          try {
            const response = await fetch(
              `${API_BASE_URL}/opportunities/${opportunity._id}/save`,
              {
                method: "POST",
                headers: { "x-auth-token": token },
              }
            );

            const data = await response.json();
            if (response.ok) {
              this.innerHTML = '<i class="fas fa-check me-2"></i>Saved!';
              this.classList.remove("btn-outline-light");
              this.classList.add("btn-success");
            } else {
              alert(data.message || "Failed to save");
              this.innerHTML =
                '<i class="fas fa-bookmark me-2"></i>Save for Later';
            }
          } catch (err) {
            alert("Error saving opportunity");
            this.innerHTML =
              '<i class="fas fa-bookmark me-2"></i>Save for Later';
          } finally {
            this.disabled = false;
          }
        });
      }
    }
  } catch (err) {
    console.error(err);
  }
}
