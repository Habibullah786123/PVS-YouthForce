export function initSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      // Get the current href value at click time (may have been dynamically changed)
      const href = this.getAttribute("href");
      // Only handle if it's still an anchor link (starts with # and has no path)
      if (href && href.startsWith("#") && !href.includes(".html")) {
        e.preventDefault();
        const target = document.querySelector(href);
        if (target) {
          target.scrollIntoView({
            behavior: "smooth",
            block: "start",
          });
        }
      }
      // If href was changed to a page URL, let the browser handle navigation normally
    });
  });
}

export function initAnimations() {
  const observerOptions = {
    threshold: 0.1,
    rootMargin: "0px 0px -50px 0px",
  };

  const observer = new IntersectionObserver(function (entries) {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("animate__animated", "animate__fadeInUp");
      }
    });
  }, observerOptions);

  document
    .querySelectorAll(
      ".card, .stat-card, .mission-card, .team-member, .stat-item"
    )
    .forEach((card) => {
      observer.observe(card);
    });
}

export function initTooltips() {
  if (typeof bootstrap !== "undefined") {
    const tooltipTriggerList = [].slice.call(
      document.querySelectorAll('[data-bs-toggle="tooltip"]')
    );
    tooltipTriggerList.map(function (tooltipTriggerEl) {
      return new bootstrap.Tooltip(tooltipTriggerEl);
    });
  }
}

export function initFAQ() {
  const faqItems = document.querySelectorAll(".faq-item");
  if (faqItems.length > 0) {
    faqItems.forEach((item) => {
      const question = item.querySelector(".faq-question");
      if (question) {
        question.addEventListener("click", function () {
          faqItems.forEach((otherItem) => {
            if (otherItem !== item) {
              otherItem.classList.remove("active");
            }
          });
          item.classList.toggle("active");
        });
      }
    });
  }

  // FAQ Search functionality
  const searchInput = document.getElementById("faqSearch");
  if (searchInput) {
    const faqCategories = document.querySelectorAll(".faq-category");

    searchInput.addEventListener("input", function () {
      const searchTerm = this.value.toLowerCase();

      faqCategories.forEach((category) => {
        const faqItems = category.querySelectorAll(".faq-item");
        let categoryVisible = false;

        faqItems.forEach((item) => {
          const question = item
            .querySelector(".faq-question")
            .textContent.toLowerCase();
          const answer = item
            .querySelector(".faq-answer")
            .textContent.toLowerCase();

          if (question.includes(searchTerm) || answer.includes(searchTerm)) {
            item.style.display = "block";
            categoryVisible = true;
          } else {
            item.style.display = "none";
          }
        });

        category.style.display = categoryVisible ? "block" : "none";
      });
    });
  }

  // FAQ Category filtering
  const categoryTabs = document.querySelectorAll(".category-tab");
  if (categoryTabs.length > 0) {
    categoryTabs.forEach((tab) => {
      tab.addEventListener("click", function () {
        // Remove active class from all tabs
        categoryTabs.forEach((t) => t.classList.remove("active"));
        // Add active class to clicked tab
        this.classList.add("active");

        const selectedCategory = this.dataset.category;
        const faqCategories = document.querySelectorAll(".faq-category");

        faqCategories.forEach((category) => {
          if (
            selectedCategory === "all" ||
            category.dataset.category.includes(selectedCategory)
          ) {
            category.style.display = "block";
          } else {
            category.style.display = "none";
          }
        });
      });
    });
  }
}

export function initContactForm() {
  const contactForm = document.getElementById("contactForm");
  if (contactForm) {
    contactForm.addEventListener("submit", async function (e) {
      e.preventDefault();

      const submitBtn = this.querySelector('button[type="submit"]');
      const originalBtnText = submitBtn.innerHTML;
      submitBtn.innerHTML =
        '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Sending...';
      submitBtn.disabled = true;

      const formData = {
        name: document.getElementById("name").value,
        email: document.getElementById("email").value,
        phone: document.getElementById("phone").value,
        subject: document.getElementById("subject").value,
        message: document.getElementById("message").value,
        newsletter: document.getElementById("newsletter")
          ? document.getElementById("newsletter").checked
          : false,
      };

      if (
        !formData.name ||
        !formData.email ||
        !formData.subject ||
        !formData.message
      ) {
        alert("Please fill in all required fields.");
        submitBtn.innerHTML = originalBtnText;
        submitBtn.disabled = false;
        return;
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.email)) {
        alert("Please enter a valid email address.");
        submitBtn.innerHTML = originalBtnText;
        submitBtn.disabled = false;
        return;
      }

      try {
        const response = await fetch("/api/contact", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(formData),
        });

        const data = await response.json();

        if (response.ok) {
          alert(
            "Thank you for your message! We'll get back to you within 24 hours."
          );
          this.reset();
        } else {
          throw new Error(data.message || "Something went wrong");
        }
      } catch (error) {
        console.error("Error submitting contact form:", error);
        alert(error.message || "Failed to send message. Please try again.");
      } finally {
        submitBtn.innerHTML = originalBtnText;
        submitBtn.disabled = false;
      }
    });
  }
}

export function initStats() {
  const statsSection = document.querySelector(".stats-section");
  if (!statsSection) return;

  const observer = new IntersectionObserver(
    (entries, observer) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          loadStats();
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.2 }
  );

  observer.observe(statsSection);
}

async function loadStats() {
  try {
    const response = await fetch("/api/stats");
    const data = await response.json();

    if (response.ok) {
      animateValue("statVolunteers", 0, data.volunteers, 2000);
      animateValue("statNGOs", 0, data.organizations, 2000);
      animateValue("statHours", 0, data.hours, 2000, "+");
      animateValue("statProjects", 0, data.projects, 2000, "+");
    }
  } catch (error) {
    console.error("Error loading stats:", error);
  }
}

function animateValue(id, start, end, duration, suffix = "") {
  const obj = document.getElementById(id);
  if (!obj) return;

  let startTimestamp = null;
  const step = (timestamp) => {
    if (!startTimestamp) startTimestamp = timestamp;
    const progress = Math.min((timestamp - startTimestamp) / duration, 1);
    const value = Math.floor(progress * (end - start) + start);
    obj.innerHTML = value.toLocaleString() + suffix;
    if (progress < 1) {
      window.requestAnimationFrame(step);
    }
  };
  window.requestAnimationFrame(step);
}
