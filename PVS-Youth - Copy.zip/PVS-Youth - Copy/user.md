# User Guide & Test Credentials

## Prerequisites

Before running the project, ensure you have the following installed:

- **Node.js**: v14.0.0 or higher check with `node -v`
- **npm**: (comes with Node.js) check with `npm -v`
- **MongoDB**: Locally installed and running, or a valid cloud MongoDB URI.

## How to Run the Project

1.  **Start the Server**:
    Open a terminal in the `backend` directory and run:

    ```bash
    node server.js
    ```

    The server will start on `http://localhost:5000`.

2.  **Access the App**:
    Open your browser and go to `http://localhost:5000`.

## Database Seeding

To reset the database and populate it with fresh dummy data for testing:

1.  **Clear Database** (WARNING: Deletes all data):

    ```bash
    cd backend
    node seed.js
    ```

2.  **Populate Dummy Data**:
    ```bash
    cd backend
    node seedData.js
    ```

## Test Credentials

### Admins

| Role              | Email             | Password      |
| :---------------- | :---------------- | :------------ |
| **Super Admin**   | `admin@pvs.com`   | `password123` |
| **Content Admin** | `content@pvs.com` | `password123` |

### Organizations (25 Generated)

| Role       | Email               | Password      |
| :--------- | :------------------ | :------------ |
| **Org 1**  | `org1@example.com`  | `password123` |
| **Org 2**  | `org2@example.com`  | `password123` |
| ...        | ...                 | ...           |
| **Org 25** | `org25@example.com` | `password123` |

### Volunteers (30 Generated)

| Role             | Email                     | Password      |
| :--------------- | :------------------------ | :------------ |
| **Volunteer 1**  | `volunteer1@example.com`  | `password123` |
| **Volunteer 2**  | `volunteer2@example.com`  | `password123` |
| ...              | ...                       | ...           |
| **Volunteer 30** | `volunteer30@example.com` | `password123` |

All passwords are set to `password123` for simplicity in testing.
